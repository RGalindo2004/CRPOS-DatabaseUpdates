SET NOCOUNT ON;
GO

DECLARE @Definicion NVARCHAR(MAX) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.POS_Factura_Finalizar'));

IF @Definicion IS NULL
    THROW 51000, 'No existe dbo.POS_Factura_Finalizar.', 1;

IF CHARINDEX(N'@Redondear', @Definicion) = 0
BEGIN
    IF CHARINDEX(N'@Cambio DECIMAL(18, 2)', @Definicion) = 0
        THROW 51000, 'No se encontro el parametro @Cambio esperado en POS_Factura_Finalizar.', 1;

    IF CHARINDEX(N'SET @VDTotal = @VDSubtotal + @VDImp;', @Definicion) = 0
        THROW 51000, 'No se encontro el calculo de total esperado en POS_Factura_Finalizar.', 1;

    SET @Definicion = REPLACE(
        @Definicion,
        N'@Cambio DECIMAL(18, 2)',
        N'@Cambio DECIMAL(18, 2),' + CHAR(13) + CHAR(10) + N'    @Redondear BIT = 0');

    SET @Definicion = REPLACE(
        @Definicion,
        N'SET @VDTotal = @VDSubtotal + @VDImp;',
        N'SET @VDTotal = @VDSubtotal + @VDImp;' + CHAR(13) + CHAR(10) +
        N'        IF @Redondear = 1' + CHAR(13) + CHAR(10) +
        N'            SELECT @VDTotal = CEILING(ROUND(d.PrecioUnitario * (1 + (d.ValorISV / 100.00)), 2)) * d.Cantidad' + CHAR(13) + CHAR(10) +
        N'            FROM dbo.POS_DetalleFactura d' + CHAR(13) + CHAR(10) +
        N'            WHERE d.IdDetalleFactura = @IdDetalleFactura;');
END;

SET @Definicion = REPLACE(
    @Definicion,
    N'SET @VDTotal = CEILING(@VDTotal);',
    N'SELECT @VDTotal = CEILING(ROUND(d.PrecioUnitario * (1 + (d.ValorISV / 100.00)), 2)) * d.Cantidad' + CHAR(13) + CHAR(10) +
    N'            FROM dbo.POS_DetalleFactura d' + CHAR(13) + CHAR(10) +
    N'            WHERE d.IdDetalleFactura = @IdDetalleFactura;');

IF CHARINDEX(N'CEILING(ROUND(d.PrecioUnitario', @Definicion) = 0
    THROW 51000, 'No se pudo agregar el redondeo de Precio Impuesto.', 1;

SET @Definicion = REPLACE(@Definicion, N'CREATE PROCEDURE', N'ALTER PROCEDURE');
EXEC sys.sp_executesql @Definicion;

IF NOT EXISTS (
    SELECT 1
    FROM sys.parameters
    WHERE object_id = OBJECT_ID(N'dbo.POS_Factura_Finalizar')
      AND name = N'@Redondear')
    THROW 51000, 'No se pudo agregar @Redondear a POS_Factura_Finalizar.', 1;
GO
