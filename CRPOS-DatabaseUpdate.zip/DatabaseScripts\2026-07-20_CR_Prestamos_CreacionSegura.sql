/*
    Endurece la creación de préstamos sin cambiar las firmas usadas por los TableAdapters.
    Reglas principales:
      - un préstamo adicional exige estar al día, capacidad de pago y autorización;
      - encabezado y cuotas se guardan en una única transacción;
      - las fechas del encabezado salen del calendario realmente generado;
      - capital, intereses y límites se validan en SQL Server.
*/
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.Cr_Afiliados_CboActivos', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.Cr_Afiliados_CboActivos AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE [dbo].[Cr_Afiliados_CboActivos]
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT afiliado.IdAfiliado,
           afiliado.CodigoAfiliado,
           afiliado.Nombres + ' ' + afiliado.Apellidos AS NombreAfiliado,
           afiliado.NumeroIdentificacion,
           afiliado.TelefonoPrincipal
    FROM dbo.CR_Afiliados afiliado
    INNER JOIN dbo.CR_EstadoAfiliado estado
        ON estado.IdEstadoAfiliado = afiliado.IdEstadoAfiliado
    WHERE afiliado.IdEmpresa = @IdEmpresa
      AND afiliado.Activo = 1
      AND afiliado.Eliminado = 0
      AND estado.EsActivo = 1;
END;
GO

;WITH EmpresasObjetivo AS
(
    SELECT empresa.IdEmpresa
    FROM dbo.AD_Empresas empresa
    WHERE empresa.Activo = 1
      AND empresa.Eliminado = 0
      AND empresa.AplicaCR = 1

    UNION

    SELECT local.IdEmpresa
    FROM dbo.AD_EmpresaLocal local
    WHERE local.Activo = 1
      AND local.AplicaCR = 1
)
INSERT INTO dbo.SG_Autorizaciones
(
    IdEmpresa, Codigo, Nombre, CajaRural, PuntoVenta, Activo,
    Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizado
)
SELECT empresa.IdEmpresa,
       '00006',
       'AUTORIZAR PRESTAMO ADICIONAL',
       1,
       0,
       1,
       'SA',
       GETDATE(),
       HOST_NAME(),
       0,
       NULL
FROM EmpresasObjetivo empresa
WHERE empresa.IdEmpresa IS NOT NULL
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.SG_Autorizaciones autorizacion
      WHERE autorizacion.IdEmpresa = empresa.IdEmpresa
        AND LTRIM(RTRIM(autorizacion.Codigo)) = '00006'
  );

;WITH EmpresasObjetivo AS
(
    SELECT empresa.IdEmpresa
    FROM dbo.AD_Empresas empresa
    WHERE empresa.Activo = 1
      AND empresa.Eliminado = 0
      AND empresa.AplicaCR = 1

    UNION

    SELECT local.IdEmpresa
    FROM dbo.AD_EmpresaLocal local
    WHERE local.Activo = 1
      AND local.AplicaCR = 1
)
UPDATE autorizacion
SET Nombre = 'AUTORIZAR PRESTAMO ADICIONAL',
    CajaRural = 1,
    PuntoVenta = 0,
    Activo = 1,
    Usuario = 'SA',
    FechaHora = GETDATE(),
    NombreEquipo = HOST_NAME(),
    Sincronizado = 0
FROM dbo.SG_Autorizaciones autorizacion
INNER JOIN EmpresasObjetivo empresa
    ON empresa.IdEmpresa = autorizacion.IdEmpresa
WHERE LTRIM(RTRIM(autorizacion.Codigo)) = '00006';

INSERT INTO dbo.SG_AutorizacionesUsuarios
(
    IdEmpresa, IdAutorizacion, IdUsuario, Eliminado, Usuario,
    FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizado
)
SELECT destino.IdEmpresa,
       destino.IdAutorizacion,
       usuarioBase.IdUsuario,
       0,
       'SA',
       GETDATE(),
       HOST_NAME(),
       0,
       NULL
FROM dbo.SG_Autorizaciones destino
INNER JOIN dbo.SG_Autorizaciones autorizacionBase
    ON autorizacionBase.IdEmpresa = destino.IdEmpresa
   AND LTRIM(RTRIM(autorizacionBase.Codigo)) = '00002'
INNER JOIN dbo.SG_AutorizacionesUsuarios usuarioBase
    ON usuarioBase.IdEmpresa = autorizacionBase.IdEmpresa
   AND usuarioBase.IdAutorizacion = autorizacionBase.IdAutorizacion
   AND usuarioBase.Eliminado = 0
WHERE LTRIM(RTRIM(destino.Codigo)) = '00006'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.SG_AutorizacionesUsuarios existente
      WHERE existente.IdEmpresa = destino.IdEmpresa
        AND existente.IdAutorizacion = destino.IdAutorizacion
        AND existente.IdUsuario = usuarioBase.IdUsuario
        AND existente.Eliminado = 0
  );
GO

IF OBJECT_ID(N'dbo.CR_PrestamosDetalle_Proyeccion', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.CR_PrestamosDetalle_Proyeccion AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE [dbo].[CR_PrestamosDetalle_Proyeccion]
    @IdTipoPrestamo INT,
    @IdTipoCalculoPrestamo INT,
    @IdFrecuenciaPago INT,
    @TasaInteres DECIMAL(5, 2),
    @ValorFijoInteres DECIMAL(5, 2),
    @TasaMora DECIMAL(5, 2),
    @MontoPrestamo DECIMAL(10, 2),
    @NumeroCuotas INT,
    @FechaInicial DATE,
    @FechaPrimerCuota DATE,
    @CambioFechaPrimerCuota BIT
AS
BEGIN
    SET NOCOUNT ON;
    SET DATEFIRST 7;

    IF @MontoPrestamo IS NULL OR @MontoPrestamo <= 0
        THROW 51001, 'El monto del préstamo debe ser mayor que cero.', 1;

    -- ponytail: 1200 evita ciclos accidentales; ampliar solo si existe un producto con un plazo mayor.
    IF @NumeroCuotas IS NULL OR @NumeroCuotas NOT BETWEEN 1 AND 1200
        THROW 51002, 'El número de cuotas debe estar entre 1 y 1200.', 1;

    IF @FechaInicial IS NULL
        THROW 51003, 'La fecha inicial es obligatoria.', 1;

    IF @CambioFechaPrimerCuota = 1
       AND (@FechaPrimerCuota IS NULL OR @FechaPrimerCuota < @FechaInicial)
        THROW 51004, 'La primera cuota no puede ser anterior a la fecha inicial.', 1;

    IF @TasaInteres IS NULL OR @TasaInteres NOT BETWEEN 0 AND 100
        THROW 51005, 'La tasa de interés debe estar entre 0 y 100.', 1;

    IF @TasaMora IS NULL OR @TasaMora NOT BETWEEN 0 AND 100
        THROW 51006, 'La tasa moratoria debe estar entre 0 y 100.', 1;

    IF @ValorFijoInteres IS NULL OR @ValorFijoInteres < 0
        THROW 51007, 'El interés fijo no puede ser negativo.', 1;

    DECLARE @IdEmpresa INT;
    SELECT @IdEmpresa = tipo.IdEmpresa
    FROM dbo.CR_TiposPrestamos tipo
    WHERE tipo.IdTipoPrestamo = @IdTipoPrestamo
      AND tipo.Activo = 1
      AND tipo.Eliminado = 0;

    IF @IdEmpresa IS NULL
        THROW 51008, 'El tipo de préstamo no existe o está inactivo.', 1;

    DECLARE @Cantidad INT,
            @Codigo CHAR(1),
            @CocienteAnual INT,
            @EsMes BIT;

    SELECT @Cantidad = frecuencia.Cantidad,
           @Codigo = LOWER(frecuencia.Codigo),
           @CocienteAnual = frecuencia.CocienteAnual,
           @EsMes = frecuencia.EsMes
    FROM dbo.CR_FrecuenciasPagosPrestamos frecuencia
    WHERE frecuencia.IdFrecuenciaPagoPrestamo = @IdFrecuenciaPago;

    IF @Cantidad IS NULL OR @Cantidad <= 0
       OR @CocienteAnual IS NULL OR @CocienteAnual <= 0
       OR @Codigo NOT IN ('d', 'm', 'y')
        THROW 51009, 'La frecuencia de pago no es válida.', 1;

    DECLARE @InteresSimple BIT,
            @CuotaNivelada BIT,
            @SaldosInsolutos BIT,
            @CargoFijo BIT,
            @VencimientoUnaCuota BIT,
            @VencimientoInteresesCapitalFinal BIT;

    SELECT @InteresSimple = calculo.InteresSimple,
           @CuotaNivelada = calculo.CuotaNivelada,
           @SaldosInsolutos = calculo.SaldosInsolutos,
           @CargoFijo = ISNULL(calculo.CargoFijo, 0),
           @VencimientoUnaCuota = calculo.VencimientoUnaCuota,
           @VencimientoInteresesCapitalFinal = calculo.VencimientoInteresesCapitalFinal
    FROM dbo.CR_TipoCalculosPrestamos calculo
    WHERE calculo.IdTipoCalculoPrestamo = @IdTipoCalculoPrestamo;

    IF COALESCE(CONVERT(INT, @InteresSimple), 0)
       + COALESCE(CONVERT(INT, @CuotaNivelada), 0)
       + COALESCE(CONVERT(INT, @SaldosInsolutos), 0)
       + COALESCE(CONVERT(INT, @CargoFijo), 0)
       + COALESCE(CONVERT(INT, @VencimientoUnaCuota), 0)
       + COALESCE(CONVERT(INT, @VencimientoInteresesCapitalFinal), 0) <> 1
        THROW 51010, 'El tipo de cálculo debe tener exactamente un método activo.', 1;

    IF @VencimientoUnaCuota = 1 AND ISNULL(@EsMes, 0) = 0
        THROW 51011, 'Los préstamos de una cuota requieren frecuencia mensual.', 1;

    DECLARE @TasaInteresFrecuencia DECIMAL(18, 10) =
        CONVERT(DECIMAL(18, 10), @TasaInteres) / @CocienteAnual / 100;
    DECLARE @TasaInteresDiaria DECIMAL(18, 10) =
        CONVERT(DECIMAL(18, 10), @TasaInteres) / 360 / 100;

    DECLARE @ProyeccionCuotas TABLE
    (
        IdPrestamoDetalle INT IDENTITY(1, 1),
        NumeroCuota INT NOT NULL,
        FechaCuota DATE NOT NULL,
        MontoCapitalBase DECIMAL(10, 2) NOT NULL,
        InteresProyectado DECIMAL(10, 2) NOT NULL,
        SaldoCapital DECIMAL(10, 2) NOT NULL,
        InteresCobrado DECIMAL(10, 2) NOT NULL,
        MoraCuota DECIMAL(10, 2) NOT NULL,
        AbonoCapital BIT NOT NULL,
        CuotaVencida BIT NOT NULL
    );

    DECLARE @FechaBase DATE,
            @FechaCuota DATE,
            @NumeroCuota INT = 1,
            @MontoCapitalBase DECIMAL(10, 2),
            @InteresProyectado DECIMAL(10, 2),
            @MontoCuotaNivelada DECIMAL(10, 2),
            @SaldoCapital DECIMAL(10, 2) = @MontoPrestamo,
            @SaldoCapitalDespues DECIMAL(10, 2),
            @FechaInteresAnterior DATE = @FechaInicial,
            @DiasInteres INT;

    IF @VencimientoUnaCuota = 1
    BEGIN
        SET @FechaCuota = CASE
                              WHEN @CambioFechaPrimerCuota = 1 THEN @FechaPrimerCuota
                              ELSE DATEADD(MONTH, @NumeroCuotas * @Cantidad, @FechaInicial)
                          END;

        WHILE DATEPART(WEEKDAY, @FechaCuota) = 1
           OR EXISTS
              (
                  SELECT 1
                  FROM dbo.CR_Feriados feriado
                  WHERE feriado.IdEmpresa = @IdEmpresa
                    AND feriado.Fecha = @FechaCuota
                    AND feriado.Activo = 1
                    AND feriado.Eliminado = 0
              )
            SET @FechaCuota = DATEADD(DAY, 1, @FechaCuota);

        SET @DiasInteres = DATEDIFF(DAY, @FechaInicial, @FechaCuota);
        SET @InteresProyectado = ROUND(@MontoPrestamo * @TasaInteresDiaria * @DiasInteres, 2);

        INSERT INTO @ProyeccionCuotas
        (
            NumeroCuota, FechaCuota, MontoCapitalBase, InteresProyectado,
            SaldoCapital, InteresCobrado, MoraCuota, AbonoCapital, CuotaVencida
        )
        VALUES
        (1, @FechaCuota, @MontoPrestamo, @InteresProyectado, 0, 0, 0, 0, 0);
    END
    ELSE
    BEGIN
        SET @FechaBase = @FechaInicial;

        IF @CambioFechaPrimerCuota = 1
            SET @FechaBase = @FechaPrimerCuota;
        ELSE IF @Codigo = 'd'
            SET @FechaBase = DATEADD(DAY, @Cantidad, @FechaBase);
        ELSE IF @Codigo = 'm'
            SET @FechaBase = DATEADD(MONTH, @Cantidad, @FechaBase);
        ELSE
            SET @FechaBase = DATEADD(YEAR, @Cantidad, @FechaBase);

        WHILE @NumeroCuota <= @NumeroCuotas
        BEGIN
            SET @FechaCuota = @FechaBase;

            WHILE DATEPART(WEEKDAY, @FechaCuota) = 1
               OR EXISTS
                  (
                      SELECT 1
                      FROM dbo.CR_Feriados feriado
                      WHERE feriado.IdEmpresa = @IdEmpresa
                        AND feriado.Fecha = @FechaCuota
                        AND feriado.Activo = 1
                        AND feriado.Eliminado = 0
                  )
                SET @FechaCuota = DATEADD(DAY, 1, @FechaCuota);

            SET @DiasInteres = DATEDIFF(DAY, @FechaInteresAnterior, @FechaCuota);

            IF @InteresSimple = 1
            BEGIN
                SET @InteresProyectado = ROUND(@MontoPrestamo * @TasaInteresDiaria * @DiasInteres, 2);
                SET @MontoCapitalBase = ROUND(@MontoPrestamo / @NumeroCuotas, 2);
            END
            ELSE IF @CuotaNivelada = 1
            BEGIN
                SET @InteresProyectado = ROUND(@SaldoCapital * @TasaInteresDiaria * @DiasInteres, 2);

                IF @TasaInteresFrecuencia = 0
                    SET @MontoCapitalBase = ROUND(@MontoPrestamo / @NumeroCuotas, 2);
                ELSE
                BEGIN
                    SET @MontoCuotaNivelada = ROUND(
                        (@MontoPrestamo * @TasaInteresFrecuencia)
                        / (1 - POWER(1 + @TasaInteresFrecuencia, -@NumeroCuotas)), 2);
                    SET @MontoCapitalBase = @MontoCuotaNivelada - @InteresProyectado;
                END;
            END
            ELSE IF @SaldosInsolutos = 1
            BEGIN
                SET @InteresProyectado = ROUND(@SaldoCapital * @TasaInteresDiaria * @DiasInteres, 2);
                SET @MontoCapitalBase = ROUND(@MontoPrestamo / @NumeroCuotas, 2);
            END
            ELSE IF @VencimientoInteresesCapitalFinal = 1
            BEGIN
                SET @InteresProyectado = ROUND(@SaldoCapital * @TasaInteresDiaria * @DiasInteres, 2);
                SET @MontoCapitalBase = CASE WHEN @NumeroCuota = @NumeroCuotas THEN @SaldoCapital ELSE 0 END;
            END
            ELSE
            BEGIN
                SET @InteresProyectado = @ValorFijoInteres;
                SET @MontoCapitalBase = ROUND(@MontoPrestamo / @NumeroCuotas, 2);
            END;

            IF @NumeroCuota = @NumeroCuotas
                SET @MontoCapitalBase = @SaldoCapital;

            IF @MontoCapitalBase < 0 OR @MontoCapitalBase > @SaldoCapital
                THROW 51012, 'El cálculo produjo un abono de capital inválido.', 1;

            SET @SaldoCapitalDespues = @SaldoCapital - @MontoCapitalBase;

            INSERT INTO @ProyeccionCuotas
            (
                NumeroCuota, FechaCuota, MontoCapitalBase, InteresProyectado,
                SaldoCapital, InteresCobrado, MoraCuota, AbonoCapital, CuotaVencida
            )
            VALUES
            (
                @NumeroCuota, @FechaCuota, @MontoCapitalBase, @InteresProyectado,
                @SaldoCapitalDespues, 0, 0, 0, 0
            );

            SET @SaldoCapital = @SaldoCapitalDespues;
            SET @FechaInteresAnterior = @FechaCuota;

            IF @Codigo = 'd'
                SET @FechaBase = DATEADD(DAY, @Cantidad, @FechaBase);
            ELSE IF @Codigo = 'm'
                SET @FechaBase = DATEADD(MONTH, @Cantidad, @FechaBase);
            ELSE
                SET @FechaBase = DATEADD(YEAR, @Cantidad, @FechaBase);

            SET @NumeroCuota += 1;
        END;
    END;

    SELECT IdPrestamoDetalle,
           NumeroCuota,
           FechaCuota,
           MontoCapitalBase,
           InteresProyectado,
           MontoCapitalBase + InteresProyectado AS MontoCuota,
           SaldoCapital,
           InteresCobrado,
           MoraCuota,
           AbonoCapital,
           CuotaVencida
    FROM @ProyeccionCuotas
    ORDER BY NumeroCuota;
END;
GO

IF OBJECT_ID(N'dbo.fn_CR_Prestamos_RiesgoAfiliado', N'IF') IS NULL
    EXEC(N'CREATE FUNCTION dbo.fn_CR_Prestamos_RiesgoAfiliado(@IdEmpresa INT, @IdAfiliado INT, @FechaEvaluacion DATE) RETURNS TABLE AS RETURN (SELECT CAST(0 AS INT) AS PrestamosActivos);');
GO

ALTER FUNCTION [dbo].[fn_CR_Prestamos_RiesgoAfiliado]
(
    @IdEmpresa INT,
    @IdAfiliado INT,
    @FechaEvaluacion DATE
)
RETURNS TABLE
AS
RETURN
(
    WITH PrestamosActivos AS
    (
        SELECT prestamo.IdPrestamo
        FROM dbo.CR_Prestamos prestamo
        INNER JOIN dbo.CR_EstadosPrestamos estado
            ON estado.IdEstadoPrestamo = prestamo.IdEstadoPrestamo
        WHERE prestamo.IdEmpresa = @IdEmpresa
          AND prestamo.IdAfiliado = @IdAfiliado
          AND prestamo.Eliminado = 0
          AND prestamo.SaldoCapital > 0
          AND estado.EsActivo = 1
    ),
    DetallePendiente AS
    (
        SELECT prestamo.IdPrestamo,
               SUM(
                   detalle.SaldoCapital
                   + CASE
                         WHEN COALESCE(detalle.SaldoInteres,
                                       detalle.InteresProyectado - detalle.InteresCobrado,
                                       0) > 0
                         THEN COALESCE(detalle.SaldoInteres,
                                       detalle.InteresProyectado - detalle.InteresCobrado,
                                       0)
                         ELSE 0
                     END
               ) AS TotalPendiente,
               MAX(detalle.FechaCuota) AS UltimaFecha
        FROM PrestamosActivos prestamo
        INNER JOIN dbo.CR_PrestamosDetalle detalle
            ON detalle.IdPrestamo = prestamo.IdPrestamo
           AND detalle.Cancelada = 0
           AND detalle.Eliminado = 0
        GROUP BY prestamo.IdPrestamo
    )
    SELECT afiliado.IngresosSalariales,
           (SELECT COUNT(*) FROM PrestamosActivos) AS PrestamosActivos,
           (
               SELECT COUNT(*)
               FROM PrestamosActivos prestamo
               INNER JOIN dbo.CR_PrestamosDetalle detalle
                   ON detalle.IdPrestamo = prestamo.IdPrestamo
               WHERE detalle.Cancelada = 0
                 AND detalle.Eliminado = 0
                 AND detalle.FechaCuota < @FechaEvaluacion
                 AND (detalle.SaldoCapital > 0
                      OR COALESCE(detalle.SaldoInteres,
                                  detalle.InteresProyectado - detalle.InteresCobrado,
                                  0) > 0)
           ) AS CuotasVencidas,
           (
               SELECT TOP (1) prestamo.IdPrestamo
               FROM PrestamosActivos prestamo
               INNER JOIN dbo.CR_PrestamosDetalle detalle
                   ON detalle.IdPrestamo = prestamo.IdPrestamo
               WHERE detalle.Cancelada = 0
                 AND detalle.Eliminado = 0
                 AND detalle.FechaCuota < @FechaEvaluacion
                 AND (detalle.SaldoCapital > 0
                      OR COALESCE(detalle.SaldoInteres,
                                  detalle.InteresProyectado - detalle.InteresCobrado,
                                  0) > 0)
               ORDER BY detalle.FechaCuota, prestamo.IdPrestamo
           ) AS IdPrestamoVencido,
           (
               SELECT MIN(detalle.FechaCuota)
               FROM PrestamosActivos prestamo
               INNER JOIN dbo.CR_PrestamosDetalle detalle
                   ON detalle.IdPrestamo = prestamo.IdPrestamo
               WHERE detalle.Cancelada = 0
                 AND detalle.Eliminado = 0
                 AND detalle.FechaCuota < @FechaEvaluacion
                 AND (detalle.SaldoCapital > 0
                      OR COALESCE(detalle.SaldoInteres,
                                  detalle.InteresProyectado - detalle.InteresCobrado,
                                  0) > 0)
           ) AS FechaPrimeraCuotaVencida,
           CAST(COALESCE(
               (
                   SELECT SUM(
                       detalle.TotalPendiente
                       / CASE
                             WHEN DATEDIFF(DAY, @FechaEvaluacion, detalle.UltimaFecha) > 30
                             THEN CEILING(CONVERT(DECIMAL(18, 6), DATEDIFF(DAY, @FechaEvaluacion, detalle.UltimaFecha)) / 30.4375)
                             ELSE 1
                         END
                   )
                   FROM DetallePendiente detalle
               ),
               0
           ) AS DECIMAL(18, 2)) AS CargaMensualActual
    FROM dbo.CR_Afiliados afiliado
    WHERE afiliado.IdEmpresa = @IdEmpresa
      AND afiliado.IdAfiliado = @IdAfiliado
);
GO

IF OBJECT_ID(N'dbo.CR_Prestamos_Validar', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.CR_Prestamos_Validar AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE [dbo].[CR_Prestamos_Validar]
    @IdAfiliado INT,
    @Monto DECIMAL(18, 2),
    @IdTipoPrestamo INT,
    @CuotaMensualPropuesta DECIMAL(18, 2) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @EsValido BIT = 1,
            @Mensaje VARCHAR(500) = '',
            @IdEmpresa INT,
            @IngresosSalariales DECIMAL(18, 2),
            @PrestamosActivos INT,
            @CuotasVencidas INT,
            @IdPrestamoVencido INT,
            @FechaPrimeraCuotaVencida DATE,
            @CargaMensualActual DECIMAL(18, 2),
            @CargaMensualTotal DECIMAL(18, 2),
            @LimiteMensual DECIMAL(18, 2);

    BEGIN TRY
        SELECT @IdEmpresa = tipo.IdEmpresa
        FROM dbo.CR_TiposPrestamos tipo
        WHERE tipo.IdTipoPrestamo = @IdTipoPrestamo
          AND tipo.Activo = 1
          AND tipo.Eliminado = 0;

        IF @Monto IS NULL OR @Monto <= 0
        BEGIN
            SET @EsValido = 0;
            SET @Mensaje = 'El monto del préstamo debe ser mayor que cero.';
        END
        ELSE IF @IdEmpresa IS NULL
        BEGIN
            SET @EsValido = 0;
            SET @Mensaje = 'El tipo de préstamo no existe o está inactivo.';
        END
        ELSE IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.CR_Afiliados afiliado
            INNER JOIN dbo.CR_EstadoAfiliado estado
                ON estado.IdEstadoAfiliado = afiliado.IdEstadoAfiliado
            WHERE afiliado.IdAfiliado = @IdAfiliado
              AND afiliado.IdEmpresa = @IdEmpresa
              AND afiliado.Activo = 1
              AND afiliado.Eliminado = 0
              AND estado.EsActivo = 1
        )
        BEGIN
            SET @EsValido = 0;
            SET @Mensaje = 'El afiliado no existe, está inactivo o pertenece a otra empresa.';
        END
        ELSE
        BEGIN
            SELECT @IngresosSalariales = riesgo.IngresosSalariales,
                   @PrestamosActivos = riesgo.PrestamosActivos,
                   @CuotasVencidas = riesgo.CuotasVencidas,
                   @IdPrestamoVencido = riesgo.IdPrestamoVencido,
                   @FechaPrimeraCuotaVencida = riesgo.FechaPrimeraCuotaVencida,
                   @CargaMensualActual = riesgo.CargaMensualActual
            FROM dbo.fn_CR_Prestamos_RiesgoAfiliado(@IdEmpresa, @IdAfiliado, CAST(GETDATE() AS DATE)) riesgo;

            -- ponytail: límite fijo 60%; moverlo a configuración por empresa cuando exista una política diferenciada.
            SET @LimiteMensual = ROUND(COALESCE(@IngresosSalariales, 0) * 0.60, 2);
            SET @CargaMensualTotal = ROUND(COALESCE(@CargaMensualActual, 0)
                                           + COALESCE(@CuotaMensualPropuesta, 0), 2);

            IF COALESCE(@IngresosSalariales, 0) <= 0
            BEGIN
                SET @EsValido = 0;
                SET @Mensaje = 'No se puede evaluar la capacidad de pago: el afiliado no tiene ingresos salariales registrados. Actualice su ficha.';
            END
            ELSE IF COALESCE(@CuotasVencidas, 0) > 0
            BEGIN
                SET @EsValido = 0;
                SET @Mensaje = 'No se puede crear otro préstamo: tiene '
                    + CONVERT(VARCHAR(12), @CuotasVencidas)
                    + ' cuota(s) vencida(s) en el préstamo #'
                    + CONVERT(VARCHAR(12), @IdPrestamoVencido)
                    + ' desde ' + CONVERT(VARCHAR(10), @FechaPrimeraCuotaVencida, 103)
                    + '. Debe regularizar la mora.';
            END
            ELSE IF COALESCE(@PrestamosActivos, 0) > 0
                    AND COALESCE(@CuotaMensualPropuesta, 0) <= 0
            BEGIN
                SET @EsValido = 0;
                SET @Mensaje = 'No se pudo calcular la nueva cuota mensual. Actualice la aplicación antes de crear un préstamo adicional.';
            END
            ELSE IF COALESCE(@PrestamosActivos, 0) > 0
                    AND COALESCE(@CargaMensualActual, 0) <= 0
            BEGIN
                SET @EsValido = 0;
                SET @Mensaje = 'No se pudieron calcular las obligaciones de los préstamos activos. Revise sus cuotas antes de continuar.';
            END
            ELSE IF @CuotaMensualPropuesta IS NOT NULL
                    AND @CargaMensualTotal > @LimiteMensual
            BEGIN
                SET @EsValido = 0;
                SET @Mensaje = 'Capacidad de pago insuficiente: ingreso mensual L '
                    + CONVERT(VARCHAR(30), CAST(@IngresosSalariales AS MONEY), 1)
                    + ', obligaciones actuales L '
                    + CONVERT(VARCHAR(30), CAST(@CargaMensualActual AS MONEY), 1)
                    + ', nueva cuota mensual estimada L '
                    + CONVERT(VARCHAR(30), CAST(@CuotaMensualPropuesta AS MONEY), 1)
                    + ' y máximo permitido (60%) L '
                    + CONVERT(VARCHAR(30), CAST(@LimiteMensual AS MONEY), 1) + '.';
            END
            ELSE IF COALESCE(@PrestamosActivos, 0) > 0
            BEGIN
                SET @Mensaje = 'Préstamo adicional: el afiliado tiene '
                    + CONVERT(VARCHAR(12), @PrestamosActivos)
                    + ' préstamo(s) activo(s), está al día y la carga mensual estimada será L '
                    + CONVERT(VARCHAR(30), CAST(@CargaMensualTotal AS MONEY), 1)
                    + ' de un máximo de L '
                    + CONVERT(VARCHAR(30), CAST(@LimiteMensual AS MONEY), 1)
                    + '. Se requiere autorización.';
            END;
        END;
    END TRY
    BEGIN CATCH
        SET @EsValido = 0;
        SET @Mensaje = 'No se pudo validar el préstamo: ' + ERROR_MESSAGE();
    END CATCH;

    SELECT @EsValido AS Valido,
           @Mensaje AS Mensaje;
END;
GO

IF OBJECT_ID(N'dbo.CR_Prestamos_Insertar', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.CR_Prestamos_Insertar AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE [dbo].[CR_Prestamos_Insertar]
    @IdEmpresa INT,
    @IdAfiliado INT,
    @IdTipoPrestamo INT,
    @IdFrecuenciaPago INT,
    @IdTipoCalculoPrestamo INT,
    @TasaInteres DECIMAL(5, 2),
    @ValorFijoInteres DECIMAL(5, 2),
    @TasaMora DECIMAL(5, 2),
    @MontoPrestamo DECIMAL(10, 2),
    @ValorFijoMoratorio DECIMAL(10, 2),
    @UsaTasaInteres BIT,
    @UsaTasaMoratoria BIT,
    @NumeroCuotas INT,
    @FechaInicio DATE,
    @FechaPrimerCuota DATE,
    @CambioFechaPrimerCuota BIT,
    @Observaciones VARCHAR(500),
    @Gastos_admin_Des VARCHAR(500),
    @Gastos_Admin_Monto DECIMAL(18, 2),
    @Usuario VARCHAR(50),
    @NombreEquipo VARCHAR(200),
    @JustificacionAutorizacion VARCHAR(1000) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Mensaje VARCHAR(200) = 'Préstamo generado correctamente.',
            @TieneError BIT = 0;

    BEGIN TRY
        IF @IdEmpresa IS NULL OR @IdEmpresa <= 0
            THROW 51101, 'La empresa no es válida.', 1;

        IF @IdAfiliado IS NULL OR @IdAfiliado <= 0
           OR @IdTipoPrestamo IS NULL OR @IdTipoPrestamo <= 0
           OR @IdFrecuenciaPago IS NULL OR @IdFrecuenciaPago <= 0
           OR @IdTipoCalculoPrestamo IS NULL OR @IdTipoCalculoPrestamo <= 0
            THROW 51120, 'Los identificadores del préstamo no son válidos.', 1;

        IF @UsaTasaInteres IS NULL OR @UsaTasaMoratoria IS NULL
           OR @CambioFechaPrimerCuota IS NULL
            THROW 51121, 'La configuración del préstamo está incompleta.', 1;

        IF @MontoPrestamo IS NULL OR @MontoPrestamo <= 0
            THROW 51102, 'El monto del préstamo debe ser mayor que cero.', 1;

        IF @NumeroCuotas IS NULL OR @NumeroCuotas NOT BETWEEN 1 AND 1200
            THROW 51103, 'El número de cuotas debe estar entre 1 y 1200.', 1;

        IF @FechaInicio IS NULL
            THROW 51104, 'La fecha inicial es obligatoria.', 1;

        IF @CambioFechaPrimerCuota = 1
           AND (@FechaPrimerCuota IS NULL OR @FechaPrimerCuota < @FechaInicio)
            THROW 51105, 'La primera cuota no puede ser anterior a la fecha inicial.', 1;

        IF @TasaInteres IS NULL OR @TasaInteres NOT BETWEEN 0 AND 100
           OR @TasaMora IS NULL OR @TasaMora NOT BETWEEN 0 AND 100
            THROW 51106, 'Las tasas deben estar entre 0 y 100.', 1;

        IF @ValorFijoInteres IS NULL OR @ValorFijoInteres < 0
           OR @ValorFijoMoratorio IS NULL OR @ValorFijoMoratorio < 0
            THROW 51107, 'Los valores fijos no pueden ser negativos.', 1;

        IF @Gastos_Admin_Monto IS NULL OR @Gastos_Admin_Monto < 0
            THROW 51108, 'Los gastos administrativos no pueden ser negativos.', 1;

        IF @Gastos_Admin_Monto > 0 AND NULLIF(LTRIM(RTRIM(@Gastos_admin_Des)), '') IS NULL
            THROW 51109, 'Debe describir los gastos administrativos.', 1;

        IF NULLIF(LTRIM(RTRIM(@Usuario)), '') IS NULL
           OR NULLIF(LTRIM(RTRIM(@NombreEquipo)), '') IS NULL
            THROW 51110, 'No se pudo identificar al usuario o al equipo.', 1;

        BEGIN TRANSACTION;

        DECLARE @ResultadoBloqueo INT,
                @RecursoBloqueo NVARCHAR(255) =
                    N'CRPOS:Prestamo:' + CONVERT(NVARCHAR(20), @IdEmpresa)
                    + N':' + CONVERT(NVARCHAR(20), @IdAfiliado);

        EXEC @ResultadoBloqueo = sys.sp_getapplock
            @Resource = @RecursoBloqueo,
            @LockMode = 'Exclusive',
            @LockOwner = 'Transaction',
            @LockTimeout = 10000;

        IF @ResultadoBloqueo < 0
            THROW 51116, 'No se pudo bloquear al afiliado para crear el préstamo. Intente nuevamente.', 1;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.CR_Afiliados afiliado
            INNER JOIN dbo.CR_EstadoAfiliado estado
                ON estado.IdEstadoAfiliado = afiliado.IdEstadoAfiliado
            WHERE afiliado.IdAfiliado = @IdAfiliado
              AND afiliado.IdEmpresa = @IdEmpresa
              AND afiliado.Activo = 1
              AND afiliado.Eliminado = 0
              AND estado.EsActivo = 1
        )
            THROW 51111, 'El afiliado no existe, está inactivo o pertenece a otra empresa.', 1;

        DECLARE @TasaTipoInteres DECIMAL(18, 2),
                @ValorTipoInteres DECIMAL(18, 2),
                @TasaTipoMora DECIMAL(18, 2),
                @ValorTipoMora DECIMAL(18, 2),
                @TipoUsaTasaInteres BIT,
                @TipoUsaTasaMora BIT;

        SELECT @TasaTipoInteres = tipo.TasaInteres,
               @ValorTipoInteres = tipo.ValorFijoInteres,
               @TasaTipoMora = tipo.TasaMora,
               @ValorTipoMora = tipo.ValorFijoMoratorio,
               @TipoUsaTasaInteres = tipo.UsaTasaInteres,
               @TipoUsaTasaMora = tipo.UsaTasaMoratoria
        FROM dbo.CR_TiposPrestamos tipo
        WHERE tipo.IdTipoPrestamo = @IdTipoPrestamo
          AND tipo.IdEmpresa = @IdEmpresa
          AND tipo.Activo = 1
          AND tipo.Eliminado = 0;

        IF @TasaTipoInteres IS NULL
            THROW 51112, 'El tipo de préstamo no existe, está inactivo o pertenece a otra empresa.', 1;

        DECLARE @CocienteAnualNuevo INT;

        SELECT @CocienteAnualNuevo = frecuencia.CocienteAnual
        FROM dbo.CR_FrecuenciasPagosPrestamos frecuencia
        WHERE frecuencia.IdFrecuenciaPagoPrestamo = @IdFrecuenciaPago
          AND frecuencia.Cantidad > 0
          AND frecuencia.CocienteAnual > 0
          AND LOWER(frecuencia.Codigo) IN ('d', 'm', 'y');

        IF @CocienteAnualNuevo IS NULL
            THROW 51113, 'La frecuencia de pago no es válida.', 1;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.CR_TipoCalculosPrestamos calculo
            WHERE calculo.IdTipoCalculoPrestamo = @IdTipoCalculoPrestamo
        )
            THROW 51114, 'El tipo de cálculo no es válido.', 1;

        DECLARE @IdEstadoPrestamo INT,
                @CantidadEstadosActivos INT;

        SELECT @IdEstadoPrestamo = MIN(estado.IdEstadoPrestamo),
               @CantidadEstadosActivos = COUNT(*)
        FROM dbo.CR_EstadosPrestamos estado
        WHERE estado.EsActivo = 1;

        IF @CantidadEstadosActivos <> 1
            THROW 51115, 'Debe existir exactamente un estado inicial activo para préstamos.', 1;

        DECLARE @PrestamosActivosAntes INT;

        SELECT @PrestamosActivosAntes = COUNT(*)
        FROM dbo.CR_Prestamos prestamo WITH (UPDLOCK, HOLDLOCK)
        INNER JOIN dbo.CR_EstadosPrestamos estado
            ON estado.IdEstadoPrestamo = prestamo.IdEstadoPrestamo
        WHERE prestamo.IdEmpresa = @IdEmpresa
          AND prestamo.IdAfiliado = @IdAfiliado
          AND prestamo.Eliminado = 0
          AND prestamo.SaldoCapital > 0
          AND estado.EsActivo = 1;

        DECLARE @Detalle TABLE
        (
            IdPrestamoDetalle INT,
            NumeroCuota INT,
            FechaCuota DATE,
            MontoCapitalBase DECIMAL(10, 2),
            InteresProyectado DECIMAL(10, 2),
            MontoCuota DECIMAL(11, 2),
            SaldoCapital DECIMAL(10, 2),
            InteresCobrado DECIMAL(10, 2),
            MoraCuota DECIMAL(10, 2),
            AbonoCapital BIT,
            CuotaVencida BIT
        );

        INSERT INTO @Detalle
        EXEC dbo.CR_PrestamosDetalle_Proyeccion
            @IdTipoPrestamo = @IdTipoPrestamo,
            @IdTipoCalculoPrestamo = @IdTipoCalculoPrestamo,
            @IdFrecuenciaPago = @IdFrecuenciaPago,
            @TasaInteres = @TasaInteres,
            @ValorFijoInteres = @ValorFijoInteres,
            @TasaMora = @TasaMora,
            @MontoPrestamo = @MontoPrestamo,
            @NumeroCuotas = @NumeroCuotas,
            @FechaInicial = @FechaInicio,
            @FechaPrimerCuota = @FechaPrimerCuota,
            @CambioFechaPrimerCuota = @CambioFechaPrimerCuota;

        IF NOT EXISTS (SELECT 1 FROM @Detalle)
            THROW 51118, 'No se generó el calendario de cuotas.', 1;

        DECLARE @CapitalGenerado DECIMAL(18, 2),
                @FechaPrimerCuotaReal DATE,
                @FechaFin DATE;

        SELECT @CapitalGenerado = SUM(detalle.MontoCapitalBase),
               @FechaPrimerCuotaReal = MIN(detalle.FechaCuota),
               @FechaFin = MAX(detalle.FechaCuota)
        FROM @Detalle detalle;

        IF @CapitalGenerado <> @MontoPrestamo
            THROW 51119, 'La suma del capital de las cuotas no coincide con el préstamo.', 1;

        DECLARE @MesesProyectados DECIMAL(18, 6) =
                    CONVERT(DECIMAL(18, 6), @NumeroCuotas) * 12 / @CocienteAnualNuevo,
                @CuotaMensualNueva DECIMAL(18, 2),
                @IngresosSalariales DECIMAL(18, 2),
                @PrestamosActivosActuales INT,
                @CuotasVencidas INT,
                @IdPrestamoVencido INT,
                @FechaPrimeraCuotaVencida DATE,
                @CargaMensualActual DECIMAL(18, 2),
                @CargaMensualTotal DECIMAL(18, 2),
                @LimiteMensual DECIMAL(18, 2),
                @ErrorRiesgo NVARCHAR(2048);

        IF @MesesProyectados < 1
            SET @MesesProyectados = 1;

        SELECT @CuotaMensualNueva = ROUND(SUM(detalle.MontoCuota) / @MesesProyectados, 2)
        FROM @Detalle detalle;

        SELECT @IngresosSalariales = riesgo.IngresosSalariales,
               @PrestamosActivosActuales = riesgo.PrestamosActivos,
               @CuotasVencidas = riesgo.CuotasVencidas,
               @IdPrestamoVencido = riesgo.IdPrestamoVencido,
               @FechaPrimeraCuotaVencida = riesgo.FechaPrimeraCuotaVencida,
               @CargaMensualActual = riesgo.CargaMensualActual
        FROM dbo.fn_CR_Prestamos_RiesgoAfiliado(@IdEmpresa, @IdAfiliado, CAST(GETDATE() AS DATE)) riesgo;

        SET @LimiteMensual = ROUND(COALESCE(@IngresosSalariales, 0) * 0.60, 2);
        SET @CargaMensualTotal = ROUND(COALESCE(@CargaMensualActual, 0) + @CuotaMensualNueva, 2);

        IF COALESCE(@IngresosSalariales, 0) <= 0
            THROW 51125, 'No se puede evaluar la capacidad de pago: actualice los ingresos salariales del afiliado.', 1;

        IF COALESCE(@PrestamosActivosActuales, 0) > 0
           AND COALESCE(@CargaMensualActual, 0) <= 0
            THROW 51126, 'No se pudieron calcular las obligaciones de los préstamos activos. Revise sus cuotas.', 1;

        IF COALESCE(@CuotasVencidas, 0) > 0
        BEGIN
            SET @ErrorRiesgo = N'Préstamo adicional rechazado: '
                + CONVERT(NVARCHAR(12), @CuotasVencidas)
                + N' cuota(s) vencida(s) en préstamo #'
                + CONVERT(NVARCHAR(12), @IdPrestamoVencido)
                + N' desde ' + CONVERT(NVARCHAR(10), @FechaPrimeraCuotaVencida, 103) + N'.';
            THROW 51122, @ErrorRiesgo, 1;
        END;

        IF @CargaMensualTotal > @LimiteMensual
        BEGIN
            SET @ErrorRiesgo = N'Capacidad insuficiente: carga mensual L '
                + CONVERT(NVARCHAR(30), CAST(@CargaMensualTotal AS MONEY), 1)
                + N' supera máximo L '
                + CONVERT(NVARCHAR(30), CAST(@LimiteMensual AS MONEY), 1) + N'.';
            THROW 51123, @ErrorRiesgo, 1;
        END;

        IF COALESCE(@PrestamosActivosAntes, 0) > 0
           AND NOT EXISTS
           (
               SELECT 1
               FROM dbo.SG_AutorizacionesLogs registro
               INNER JOIN dbo.SG_Autorizaciones autorizacion
                   ON autorizacion.IdEmpresa = registro.IdEmpresa
                  AND autorizacion.IdAutorizacion = registro.IdAutorizacion
               WHERE registro.IdEmpresa = @IdEmpresa
              AND LTRIM(RTRIM(autorizacion.Codigo)) = '00006'
                 AND autorizacion.Activo = 1
                 AND registro.FechaHora >= DATEADD(MINUTE, -10, GETDATE())
                 AND registro.Justificacion = LTRIM(RTRIM(@JustificacionAutorizacion))
           )
            THROW 51124, 'El préstamo adicional requiere una autorización válida y registrada.', 1;

        DECLARE @HayTasaPersonalizada BIT = CASE
            WHEN @TasaTipoInteres <> @TasaInteres
              OR @ValorTipoInteres <> @ValorFijoInteres
              OR @TasaTipoMora <> @TasaMora
              OR @ValorTipoMora <> @ValorFijoMoratorio
              OR @TipoUsaTasaInteres <> @UsaTasaInteres
              OR @TipoUsaTasaMora <> @UsaTasaMoratoria
            THEN 1 ELSE 0 END;

        INSERT INTO dbo.CR_Prestamos
        (
            IdEmpresa, IdAfiliado, IdTipoPrestamo, IdFrecuenciaPago,
            IdEstadoPrestamo, IdTipoCalculoPrestamo, TasaInteres,
            ValorFijoInteres, TasaMora, MontoPrestamo, SaldoCapital,
            ValorFijoMoratorio, UsaTasaInteres, UsaTasaMoratoria,
            NumeroCuotas, FechaInicio, FechaFin, FechaPrimerCuota,
            CambioFechaPrimerCuota, HayTasaPersonalizada, Observaciones,
            Gastos_Admin_Des, Gastos_Admin_Monto, Readecuado, Eliminado,
            Usuario, FechaHora, NombreEquipo, Sincronizado,
            FechaHoraSincronizacion
        )
        VALUES
        (
            @IdEmpresa, @IdAfiliado, @IdTipoPrestamo, @IdFrecuenciaPago,
            @IdEstadoPrestamo, @IdTipoCalculoPrestamo, @TasaInteres,
            @ValorFijoInteres, @TasaMora, @MontoPrestamo, @MontoPrestamo,
            @ValorFijoMoratorio, @UsaTasaInteres, @UsaTasaMoratoria,
            @NumeroCuotas, @FechaInicio, @FechaFin, @FechaPrimerCuotaReal,
            @CambioFechaPrimerCuota, @HayTasaPersonalizada, NULLIF(LTRIM(RTRIM(@Observaciones)), ''),
            NULLIF(LTRIM(RTRIM(@Gastos_admin_Des)), ''), @Gastos_Admin_Monto, 0, 0,
            @Usuario, GETDATE(), @NombreEquipo, 0, NULL
        );

        DECLARE @IdPrestamo INT = SCOPE_IDENTITY();

        INSERT INTO dbo.CR_PrestamosDetalle
        (
            IdEmpresa, IdPrestamo, NumeroCuota, FechaCuota,
            FechaPagoPrestamo, MontoCapitalBase, InteresProyectado,
            SaldoCapital, InteresCobrado, MoraCuota, AbonoCapital,
            CuotaVencida, Cancelada, MoraCobrada, Eliminado, Usuario,
            FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion
        )
        SELECT @IdEmpresa,
               @IdPrestamo,
               detalle.NumeroCuota,
               detalle.FechaCuota,
               NULL,
               detalle.MontoCapitalBase,
               detalle.InteresProyectado,
               detalle.MontoCapitalBase,
               0,
               0,
               0,
               0,
               0,
               0,
               0,
               @Usuario,
               GETDATE(),
               @NombreEquipo,
               0,
               NULL
        FROM @Detalle detalle;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        SET @TieneError = 1;
        SET @Mensaje = LEFT(ERROR_MESSAGE(), 200);
    END CATCH;

    SELECT @TieneError AS HayError,
           @Mensaje AS Mensaje;
END;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.CR_Prestamos')
      AND name = N'IX_CR_Prestamos_EmpresaAfiliadoActivo'
)
BEGIN
    CREATE NONCLUSTERED INDEX IX_CR_Prestamos_EmpresaAfiliadoActivo
        ON dbo.CR_Prestamos (IdEmpresa, IdAfiliado, Eliminado, IdEstadoPrestamo)
        INCLUDE (SaldoCapital);
END;
GO
