/*
    Genera un asiento individual y trazable para cada otorgamiento y cada
    abono o reversión de préstamo. La mayorización continúa siendo manual.
*/
SET XACT_ABORT ON;
GO

IF OBJECT_ID(N'dbo.CR_Asientos_Prestamo_Automatico', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.CR_Asientos_Prestamo_Automatico AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.CR_Asientos_Prestamo_Automatico
    @IdPrestamo INT = NULL,
    @IdMovimientoPrestamo INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    IF (@IdPrestamo IS NULL AND @IdMovimientoPrestamo IS NULL)
       OR (@IdPrestamo IS NOT NULL AND @IdMovimientoPrestamo IS NOT NULL)
        THROW 51401, 'Debe indicar un préstamo o un movimiento, pero no ambos.', 1;

    DECLARE @IdEmpresa INT,
            @IdTipoAsiento INT,
            @IdTipoPrestamo INT,
            @IdAsiento INT = 0,
            @FechaAsiento DATE,
            @NumeroReferencia VARCHAR(200),
            @Sinopsis VARCHAR(MAX),
            @NombreAfiliado VARCHAR(201),
            @Usuario VARCHAR(50),
            @NombreEquipo VARCHAR(200),
            @EsReversion BIT = 0,
            @EsAbono BIT = 0,
            @Eliminado BIT = 0;

    DECLARE @Conceptos TABLE
    (
        Codigo VARCHAR(20) NOT NULL PRIMARY KEY,
        Monto DECIMAL(18, 2) NOT NULL,
        CuentaEspecial VARCHAR(200) NULL
    );

    IF @IdPrestamo IS NOT NULL
    BEGIN
        DECLARE @MontoPrestamo DECIMAL(18, 2),
                @GastosAdministrativos DECIMAL(18, 2);

        SELECT @IdEmpresa = prestamo.IdEmpresa,
               @IdTipoPrestamo = prestamo.IdTipoPrestamo,
               @IdAsiento = COALESCE(prestamo.IdAsiento, 0),
               @FechaAsiento = prestamo.FechaInicio,
               @MontoPrestamo = ROUND(prestamo.MontoPrestamo, 2),
               @GastosAdministrativos = ROUND(COALESCE(prestamo.Gastos_Admin_Monto, 0), 2),
               @Usuario = prestamo.Usuario,
               @NombreEquipo = prestamo.NombreEquipo,
               @Eliminado = prestamo.Eliminado
        FROM dbo.CR_Prestamos prestamo
        WHERE prestamo.IdPrestamo = @IdPrestamo;

        IF @IdEmpresa IS NULL OR @Eliminado = 1
            THROW 51402, 'No se puede contabilizar un préstamo inexistente o eliminado.', 1;

        SELECT @IdTipoAsiento = tipo.IdTipoAsiento,
               @Sinopsis = COALESCE(tipo.Descripcion, tipo.TipoAsiento)
        FROM dbo.CR_TipoAsiento tipo
        WHERE tipo.Codigo = '0003'
          AND tipo.Activo = 1;

        SET @NumeroReferencia = 'PRESTAMO-' + CONVERT(VARCHAR(20), @IdPrestamo);

        INSERT INTO @Conceptos (Codigo, Monto, CuentaEspecial)
        SELECT '003-001', @MontoPrestamo, tipoPrestamo.CuentaContable
        FROM dbo.CR_TiposPrestamos tipoPrestamo
        WHERE tipoPrestamo.IdTipoPrestamo = @IdTipoPrestamo
          AND tipoPrestamo.IdEmpresa = @IdEmpresa
        UNION ALL
        SELECT '003-002', @MontoPrestamo - @GastosAdministrativos, NULL
        UNION ALL
        SELECT '003-003', @GastosAdministrativos, NULL;
    END
    ELSE
    BEGIN
        DECLARE @MontoCapital DECIMAL(18, 2),
                @MontoInteres DECIMAL(18, 2),
                @MontoMora DECIMAL(18, 2);

        SELECT @IdEmpresa = movimiento.IdEmpresa,
               @IdPrestamo = movimiento.IdPrestamo,
               @IdTipoPrestamo = prestamo.IdTipoPrestamo,
               @IdAsiento = COALESCE(movimiento.IdAsiento, 0),
               @FechaAsiento = CONVERT(DATE, movimiento.FechaMovimiento),
               @MontoCapital = ABS(ROUND(movimiento.MontoCapital, 2)),
               @MontoInteres = ABS(ROUND(movimiento.MontoInteres, 2)),
               @MontoMora = ABS(ROUND(movimiento.MontoMora, 2)),
               @Usuario = movimiento.Usuario,
               @NombreEquipo = movimiento.NombreEquipo,
               @EsReversion = movimiento.EsReversion,
               @EsAbono = COALESCE(tipoMovimiento.EsAbono, 0),
               @Eliminado = movimiento.Eliminado
        FROM dbo.CR_MovimientosPrestamos movimiento
        INNER JOIN dbo.CR_Prestamos prestamo
            ON prestamo.IdPrestamo = movimiento.IdPrestamo
           AND prestamo.IdEmpresa = movimiento.IdEmpresa
        INNER JOIN dbo.CR_TiposMovimientosPrestamos tipoMovimiento
            ON tipoMovimiento.IdTipoMovimientoPrestamo = movimiento.IdTipoMovimientoPrestamo
        WHERE movimiento.IdMovimientoPrestamo = @IdMovimientoPrestamo;

        IF @IdEmpresa IS NULL OR @Eliminado = 1
            THROW 51403, 'No se puede contabilizar un movimiento inexistente o eliminado.', 1;

        -- Los movimientos que no son abonos no tienen una plantilla contable de préstamo.
        IF @EsAbono = 0
            RETURN;

        SELECT @IdTipoAsiento = tipo.IdTipoAsiento,
               @Sinopsis = COALESCE(tipo.Descripcion, tipo.TipoAsiento)
        FROM dbo.CR_TipoAsiento tipo
        WHERE tipo.Codigo = '0004'
          AND tipo.Activo = 1;

        SET @NumeroReferencia =
            CASE WHEN @EsReversion = 1 THEN 'REV-' ELSE 'ABONO-' END
            + 'PRESTAMO-' + CONVERT(VARCHAR(20), @IdPrestamo)
            + '-MOV-' + CONVERT(VARCHAR(20), @IdMovimientoPrestamo);

        INSERT INTO @Conceptos (Codigo, Monto, CuentaEspecial)
        SELECT '004-001', @MontoCapital, tipoPrestamo.CuentaContable
        FROM dbo.CR_TiposPrestamos tipoPrestamo
        WHERE tipoPrestamo.IdTipoPrestamo = @IdTipoPrestamo
          AND tipoPrestamo.IdEmpresa = @IdEmpresa
        UNION ALL
        SELECT '004-002', @MontoInteres, tipoPrestamo.CuentaContableIntereses
        FROM dbo.CR_TiposPrestamos tipoPrestamo
        WHERE tipoPrestamo.IdTipoPrestamo = @IdTipoPrestamo
          AND tipoPrestamo.IdEmpresa = @IdEmpresa
        UNION ALL
        SELECT '004-003', @MontoCapital + @MontoInteres + @MontoMora, NULL
        UNION ALL
        SELECT '004-004', @MontoMora, NULL;
    END;

    SELECT @NombreAfiliado = LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos)))
    FROM dbo.CR_Prestamos prestamo
    INNER JOIN dbo.CR_Afiliados afiliado
        ON afiliado.IdAfiliado = prestamo.IdAfiliado
       AND afiliado.IdEmpresa = prestamo.IdEmpresa
    WHERE prestamo.IdPrestamo = @IdPrestamo
      AND prestamo.IdEmpresa = @IdEmpresa;

    IF NULLIF(@NombreAfiliado, '') IS NULL
        THROW 51410, 'El préstamo no tiene un afiliado válido para describir el asiento.', 1;

    SET @Sinopsis = CONCAT(@Sinopsis, ' - ', @NombreAfiliado);

    IF @IdTipoAsiento IS NULL
        THROW 51404, 'No existe un tipo de asiento activo para contabilizar el préstamo.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM @Conceptos concepto
        WHERE concepto.Monto > 0
          AND
          (
              SELECT COUNT(*)
              FROM dbo.CR_TipoAsientoCuentasContables plantilla
              WHERE plantilla.IdEmpresa = @IdEmpresa
                AND plantilla.IdTipoAsiento = @IdTipoAsiento
                AND plantilla.Codigo = concepto.Codigo
          ) <> 1
    )
        THROW 51405, 'La plantilla contable del préstamo está incompleta o tiene conceptos duplicados.', 1;

    IF EXISTS
    (
        SELECT 1
        FROM @Conceptos concepto
        INNER JOIN dbo.CR_TipoAsientoCuentasContables plantilla
            ON plantilla.IdEmpresa = @IdEmpresa
           AND plantilla.IdTipoAsiento = @IdTipoAsiento
           AND plantilla.Codigo = concepto.Codigo
        WHERE concepto.Monto > 0
          AND
          (
              SELECT COUNT(*)
              FROM dbo.CR_CuentasContables cuenta
              WHERE cuenta.IdEmpresa = @IdEmpresa
                AND cuenta.Eliminado = 0
                AND cuenta.Operable = 1
                AND
                (
                    (concepto.CuentaEspecial IS NOT NULL
                     AND cuenta.CuentaContable = concepto.CuentaEspecial)
                    OR
                    (concepto.CuentaEspecial IS NULL
                     AND cuenta.IdCuentaContable = plantilla.IdCuentaContable)
                )
          ) <> 1
    )
        THROW 51406, 'Una cuenta configurada para el préstamo no existe, está eliminada o no es operable.', 1;

    DECLARE @Lineas TABLE
    (
        IdCuentaContable INT NOT NULL,
        Debito DECIMAL(18, 2) NOT NULL,
        Credito DECIMAL(18, 2) NOT NULL
    );

    INSERT INTO @Lineas (IdCuentaContable, Debito, Credito)
    SELECT cuenta.IdCuentaContable,
           CASE
               WHEN (@EsReversion = 0 AND plantilla.Debito = 1)
                 OR (@EsReversion = 1 AND plantilla.Debito = 0)
                   THEN concepto.Monto
               ELSE 0
           END,
           CASE
               WHEN (@EsReversion = 0 AND plantilla.Debito = 0)
                 OR (@EsReversion = 1 AND plantilla.Debito = 1)
                   THEN concepto.Monto
               ELSE 0
           END
    FROM @Conceptos concepto
    INNER JOIN dbo.CR_TipoAsientoCuentasContables plantilla
        ON plantilla.IdEmpresa = @IdEmpresa
       AND plantilla.IdTipoAsiento = @IdTipoAsiento
       AND plantilla.Codigo = concepto.Codigo
    INNER JOIN dbo.CR_CuentasContables cuenta
        ON cuenta.IdEmpresa = @IdEmpresa
       AND cuenta.Eliminado = 0
       AND cuenta.Operable = 1
       AND
       (
           (concepto.CuentaEspecial IS NOT NULL
            AND cuenta.CuentaContable = concepto.CuentaEspecial)
           OR
           (concepto.CuentaEspecial IS NULL
            AND cuenta.IdCuentaContable = plantilla.IdCuentaContable)
       )
    WHERE concepto.Monto > 0;

    DECLARE @Debito DECIMAL(18, 2),
            @Credito DECIMAL(18, 2);

    SELECT @Debito = ROUND(COALESCE(SUM(linea.Debito), 0), 2),
           @Credito = ROUND(COALESCE(SUM(linea.Credito), 0), 2)
    FROM @Lineas linea;

    IF @Debito <= 0 OR @Debito <> @Credito
        THROW 51407, 'El asiento automático no está balanceado; revise la plantilla contable.', 1;

    IF @IdAsiento > 0
    BEGIN
        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.CR_Asientos asiento
            WHERE asiento.IdAsiento = @IdAsiento
              AND asiento.IdEmpresa = @IdEmpresa
        )
            THROW 51408, 'El origen tiene asociado un asiento contable inexistente.', 1;

        IF EXISTS
        (
            SELECT 1
            FROM dbo.CR_Asientos asiento
            WHERE asiento.IdAsiento = @IdAsiento
              AND (asiento.Mayorizado = 1 OR asiento.Anulado = 1 OR asiento.Eliminado = 1)
        )
            THROW 51409, 'No se puede modificar el movimiento porque su asiento ya fue mayorizado, anulado o eliminado.', 1;

        DELETE FROM dbo.CR_AsientosDet
        WHERE IdEmpresa = @IdEmpresa
          AND IdAsiento = @IdAsiento;

        UPDATE dbo.CR_Asientos
        SET IdTipoAsiento = @IdTipoAsiento,
            FechaAsiento = @FechaAsiento,
            FechaHoraPosteo = GETDATE(),
            NumeroReferencia = @NumeroReferencia,
            Debito = @Debito,
            Credito = @Credito,
            Sinopsis = @Sinopsis,
            Usuario = @Usuario,
            FechaHora = GETDATE(),
            NombreEquipo = @NombreEquipo,
            Sincronizado = 0,
            FechaHoraSincronizacion = NULL
        WHERE IdEmpresa = @IdEmpresa
          AND IdAsiento = @IdAsiento;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.CR_Asientos
        (
            IdEmpresa, IdTipoAsiento, FechaAsiento, FechaHoraPosteo,
            FechaHoraMayorizacion, NumeroReferencia, Debito, Credito,
            Sinopsis, Mayorizado, Eliminado, Anulado, Usuario, FechaHora,
            NombreEquipo, Sincronizado, FechaHoraSincronizacion
        )
        VALUES
        (
            @IdEmpresa, @IdTipoAsiento, @FechaAsiento, GETDATE(),
            NULL, @NumeroReferencia, @Debito, @Credito,
            @Sinopsis, 0, 0, 0, @Usuario, GETDATE(),
            @NombreEquipo, 0, NULL
        );

        SET @IdAsiento = SCOPE_IDENTITY();
    END;

    INSERT INTO dbo.CR_AsientosDet
    (
        IdEmpresa, IdAsiento, IdCuentaContable, Debito, Credito,
        Sinopsis, Usuario, FechaHora, NombreEquipo, Sincronizado,
        FechaHoraSincronizacion
    )
    SELECT @IdEmpresa, @IdAsiento, linea.IdCuentaContable,
           linea.Debito, linea.Credito, @NumeroReferencia,
           @Usuario, GETDATE(), @NombreEquipo, 0, NULL
    FROM @Lineas linea;

    IF @IdMovimientoPrestamo IS NULL
        UPDATE dbo.CR_Prestamos
        SET IdAsiento = @IdAsiento
        WHERE IdPrestamo = @IdPrestamo
          AND IdEmpresa = @IdEmpresa
          AND COALESCE(IdAsiento, 0) <> @IdAsiento;
    ELSE
        UPDATE dbo.CR_MovimientosPrestamos
        SET IdAsiento = @IdAsiento
        WHERE IdMovimientoPrestamo = @IdMovimientoPrestamo
          AND IdEmpresa = @IdEmpresa
          AND COALESCE(IdAsiento, 0) <> @IdAsiento;
END;
GO

/* Completa también la sinopsis de los asientos automáticos existentes. */
UPDATE asiento
SET Sinopsis = concepto.Sinopsis
FROM dbo.CR_Asientos asiento
INNER JOIN dbo.CR_Prestamos prestamo
    ON prestamo.IdAsiento = asiento.IdAsiento
   AND prestamo.IdEmpresa = asiento.IdEmpresa
INNER JOIN dbo.CR_Afiliados afiliado
    ON afiliado.IdAfiliado = prestamo.IdAfiliado
   AND afiliado.IdEmpresa = prestamo.IdEmpresa
INNER JOIN dbo.CR_TipoAsiento tipo
    ON tipo.IdTipoAsiento = asiento.IdTipoAsiento
CROSS APPLY
(
    SELECT CONCAT(COALESCE(tipo.Descripcion, tipo.TipoAsiento), ' - ',
                  LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos))))
) concepto(Sinopsis)
WHERE tipo.Codigo = '0003'
  AND asiento.Eliminado = 0
  AND NULLIF(LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos))), '') IS NOT NULL
  AND COALESCE(asiento.Sinopsis, '') <> concepto.Sinopsis;
GO

UPDATE asiento
SET Sinopsis = concepto.Sinopsis
FROM dbo.CR_Asientos asiento
INNER JOIN dbo.CR_MovimientosPrestamos movimiento
    ON movimiento.IdAsiento = asiento.IdAsiento
   AND movimiento.IdEmpresa = asiento.IdEmpresa
INNER JOIN dbo.CR_Prestamos prestamo
    ON prestamo.IdPrestamo = movimiento.IdPrestamo
   AND prestamo.IdEmpresa = movimiento.IdEmpresa
INNER JOIN dbo.CR_Afiliados afiliado
    ON afiliado.IdAfiliado = prestamo.IdAfiliado
   AND afiliado.IdEmpresa = prestamo.IdEmpresa
INNER JOIN dbo.CR_TipoAsiento tipo
    ON tipo.IdTipoAsiento = asiento.IdTipoAsiento
CROSS APPLY
(
    SELECT CONCAT(COALESCE(tipo.Descripcion, tipo.TipoAsiento), ' - ',
                  LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos))))
) concepto(Sinopsis)
WHERE tipo.Codigo = '0004'
  AND asiento.Eliminado = 0
  AND NULLIF(LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos))), '') IS NOT NULL
  AND COALESCE(asiento.Sinopsis, '') <> concepto.Sinopsis;
GO

IF OBJECT_ID(N'dbo.TR_CR_Prestamos_AsientoAutomatico', N'TR') IS NULL
    EXEC(N'CREATE TRIGGER dbo.TR_CR_Prestamos_AsientoAutomatico ON dbo.CR_Prestamos AFTER INSERT AS BEGIN SET NOCOUNT ON; END');
GO

ALTER TRIGGER dbo.TR_CR_Prestamos_AsientoAutomatico
ON dbo.CR_Prestamos
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdPrestamo INT;
    DECLARE prestamos CURSOR LOCAL FAST_FORWARD FOR
        SELECT IdPrestamo
        FROM inserted
        WHERE Eliminado = 0;

    OPEN prestamos;
    FETCH NEXT FROM prestamos INTO @IdPrestamo;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC dbo.CR_Asientos_Prestamo_Automatico @IdPrestamo = @IdPrestamo;
        FETCH NEXT FROM prestamos INTO @IdPrestamo;
    END;

    CLOSE prestamos;
    DEALLOCATE prestamos;
END;
GO

ENABLE TRIGGER dbo.TR_CR_Prestamos_AsientoAutomatico ON dbo.CR_Prestamos;
GO

IF OBJECT_ID(N'dbo.TR_CR_MovimientosPrestamos_AsientoAutomatico', N'TR') IS NULL
    EXEC(N'CREATE TRIGGER dbo.TR_CR_MovimientosPrestamos_AsientoAutomatico ON dbo.CR_MovimientosPrestamos AFTER INSERT, UPDATE AS BEGIN SET NOCOUNT ON; END');
GO

ALTER TRIGGER dbo.TR_CR_MovimientosPrestamos_AsientoAutomatico
ON dbo.CR_MovimientosPrestamos
AFTER INSERT, UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    IF NOT
    (
        UPDATE(IdTipoMovimientoPrestamo)
        OR UPDATE(FechaMovimiento)
        OR UPDATE(MontoCapital)
        OR UPDATE(MontoInteres)
        OR UPDATE(MontoMora)
        OR UPDATE(EsReversion)
        OR UPDATE(Eliminado)
    )
        RETURN;

    DECLARE @IdMovimientoPrestamo INT;
    DECLARE movimientos CURSOR LOCAL FAST_FORWARD FOR
        SELECT IdMovimientoPrestamo
        FROM inserted;

    OPEN movimientos;
    FETCH NEXT FROM movimientos INTO @IdMovimientoPrestamo;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC dbo.CR_Asientos_Prestamo_Automatico
            @IdMovimientoPrestamo = @IdMovimientoPrestamo;
        FETCH NEXT FROM movimientos INTO @IdMovimientoPrestamo;
    END;

    CLOSE movimientos;
    DEALLOCATE movimientos;
END;
GO

ENABLE TRIGGER dbo.TR_CR_MovimientosPrestamos_AsientoAutomatico ON dbo.CR_MovimientosPrestamos;
GO
