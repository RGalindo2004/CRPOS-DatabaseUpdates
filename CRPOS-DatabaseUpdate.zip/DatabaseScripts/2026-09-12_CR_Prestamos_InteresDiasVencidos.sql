SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'dbo.fn_CR_Prestamos_InteresDiario', N'FN') IS NULL
    EXEC(N'CREATE FUNCTION dbo.fn_CR_Prestamos_InteresDiario(@IdPrestamo INT, @FechaCalculo DATE) RETURNS DECIMAL(18, 2) AS BEGIN RETURN 0; END');
GO

ALTER FUNCTION [dbo].[fn_CR_Prestamos_InteresDiario]
(
    @IdPrestamo INT,
    @FechaCalculo DATE
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @FechaPrimeraCuotaPendiente DATE,
            @SaldoCapital DECIMAL(18, 2),
            @SaldoInteresAnterior DECIMAL(18, 2) = 0,
            @TasaInteres DECIMAL(18, 6),
            @DiasVencidos INT;

    SELECT @SaldoCapital = prestamo.SaldoCapital,
           @TasaInteres = prestamo.TasaInteres
    FROM dbo.CR_Prestamos prestamo
    WHERE prestamo.IdPrestamo = @IdPrestamo
      AND prestamo.Eliminado = 0;

    SELECT @FechaPrimeraCuotaPendiente = MIN(detalle.FechaCuota)
    FROM dbo.CR_PrestamosDetalle detalle
    WHERE detalle.IdPrestamo = @IdPrestamo
      AND detalle.Cancelada = 0
      AND detalle.Eliminado = 0;

    IF @FechaPrimeraCuotaPendiente IS NULL OR @FechaCalculo IS NULL
        RETURN 0;

    SET @DiasVencidos = CASE
                            WHEN @FechaCalculo > @FechaPrimeraCuotaPendiente
                                THEN DATEDIFF(DAY, @FechaPrimeraCuotaPendiente, @FechaCalculo)
                            ELSE 0
                        END;

    SELECT TOP (1)
           @SaldoInteresAnterior = COALESCE(detalle.SaldoInteres, 0)
    FROM dbo.CR_PrestamosDetalle detalle
    WHERE detalle.IdPrestamo = @IdPrestamo
      AND detalle.Cancelada = 0
      AND detalle.Eliminado = 0
    ORDER BY detalle.FechaCuota, detalle.NumeroCuota;

    RETURN ROUND(
        COALESCE(@SaldoInteresAnterior, 0)
        + COALESCE(@SaldoCapital, 0) * COALESCE(@TasaInteres, 0) / 100.0 / 360.0 * @DiasVencidos,
        2
    );
END;
GO
