SET XACT_ABORT ON;
BEGIN TRANSACTION;
GO

CREATE OR ALTER PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero]
    @IdEmpresa int = 1,
    @Anio int = 2025,
    @Mes varchar(100) = '5,6,7',
    @IdEstadoFinanciero int = 1
AS
BEGIN
    SET NOCOUNT ON;
    SET LANGUAGE Spanish;

    IF @Anio NOT BETWEEN 1900 AND 9999
        THROW 50001, 'El año indicado para el estado financiero no es válido.', 1;

    IF NULLIF(LTRIM(RTRIM(@Mes)), '') IS NULL
        THROW 50002, 'Debe indicar al menos un mes para el estado financiero.', 1;

    IF EXISTS (
        SELECT 1
        FROM dbo.SplitString(@Mes, ',')
        WHERE TRY_CONVERT(int, LTRIM(RTRIM([Value]))) IS NULL
           OR TRY_CONVERT(int, LTRIM(RTRIM([Value]))) NOT BETWEEN 1 AND 12
    )
        THROW 50003, 'La lista de meses del estado financiero no es válida.', 1;

    DECLARE @Meses TABLE (Mes int NOT NULL PRIMARY KEY);

    INSERT INTO @Meses(Mes)
    SELECT DISTINCT TRY_CONVERT(int, LTRIM(RTRIM([Value])))
    FROM dbo.SplitString(@Mes, ',');

    DECLARE @UltimoMes int = (SELECT MAX(Mes) FROM @Meses);
    DECLARE @Fecha date = DATEFROMPARTS(@Anio, @UltimoMes, 1);
    DECLARE @Dia int = DAY(EOMONTH(@Fecha));
    DECLARE @MesLetra varchar(50) = DATENAME(MONTH, @Fecha);

    ;WITH Mapeos AS (
        SELECT A.IdEstadoFinancieroDetalle,
               A.IdEmpresa,
               A.IdCuentaContable,
               A.Operacion
        FROM dbo.CR_EstadosFinancierosDetalleCuentas A
        WHERE A.Eliminado = 0
        GROUP BY A.IdEstadoFinancieroDetalle,
                 A.IdEmpresa,
                 A.IdCuentaContable,
                 A.Operacion
    )
    SELECT C.Titulo,
           CASE WHEN C.Tipo = 'Acumulado' THEN CONVERT(bit, 1) ELSE CONVERT(bit, 0) END Acumulado,
           B.ParametroLinea,
           B.Negrita,
           B.Tabulacion,
           B.Columna,
           B.Fuente,
           B.Size,
           REPLICATE(CHAR(9), B.Tabulacion) + B.Descripcion NombreCuenta,
           B.Orden,
           CONVERT(varchar(10), @Anio) Anio,
           CONVERT(varchar(10), @UltimoMes) Mes,
           SUM(ISNULL(D.SaldoAnterior, 0)) SaldoAnterior,
           CASE
               WHEN B.ParametroLinea = 1 THEN NULL
               ELSE SUM(ISNULL(
                   CASE
                       WHEN C.Tipo = 'Acumulado' THEN
                           CASE WHEN A.Operacion = 2 THEN D.Saldo * -1 ELSE D.Saldo END
                       ELSE
                           CASE WHEN A.Operacion = 2 THEN D.SaldoActual * -1 ELSE D.SaldoActual END
                   END, 0))
           END Saldo,
           B.Subtitulo,
           CONVERT(varchar(10), @Dia) DiaFinalMes,
           CONVERT(varchar(10), @MesLetra) MesLetra,
           E.NombreCR
    FROM dbo.CR_EstadosFinancierosDetalle B
    LEFT JOIN Mapeos A
           ON A.IdEstadoFinancieroDetalle = B.IdEstadoFinancieroDetalle
          AND A.IdEmpresa = B.IdEmpresa
    INNER JOIN dbo.CR_EstadosFinancieros C
            ON C.IdEstadoFinanciero = B.IdEstadoFinanciero
           AND C.IdEmpresa = B.IdEmpresa
           AND C.Eliminado = 0
    LEFT JOIN dbo.CR_AsientosMayorizacion D
           ON D.IdCuentaContable = A.IdCuentaContable
          AND D.IdEmpresa = A.IdEmpresa
          AND D.Anio = @Anio
          AND D.Mes IN (SELECT Mes FROM @Meses)
          AND D.Eliminado = 0
    LEFT JOIN dbo.AD_Empresas E
           ON E.IdEmpresa = B.IdEmpresa
    WHERE B.Eliminado = 0
      AND B.IdEmpresa = @IdEmpresa
      AND C.IdEstadoFinanciero = @IdEstadoFinanciero
    GROUP BY C.Titulo,
             CASE WHEN C.Tipo = 'Acumulado' THEN CONVERT(bit, 1) ELSE CONVERT(bit, 0) END,
             B.ParametroLinea,
             B.Negrita,
             B.Tabulacion,
             B.Columna,
             B.Fuente,
             B.Size,
             REPLICATE(CHAR(9), B.Tabulacion) + B.Descripcion,
             B.Orden,
             B.Subtitulo,
             E.NombreCR
    ORDER BY B.Orden;
END;
GO

DECLARE @FechaActualizacion datetime = GETDATE();
DECLARE @UsuarioActualizacion varchar(50) = 'SISTEMA';
DECLARE @EquipoActualizacion varchar(200) = 'SCRIPT_ESTADO_RESULTADOS';

UPDATE D
SET D.Descripcion = 'INTERESES SOBRE CARTERA DE PRÉSTAMOS',
    D.Usuario = @UsuarioActualizacion,
    D.FechaHora = @FechaActualizacion,
    D.NombreEquipo = @EquipoActualizacion,
    D.Sincronizado = 0,
    D.FechaHoraSincronizacion = NULL
FROM dbo.CR_EstadosFinancierosDetalle D
INNER JOIN dbo.CR_EstadosFinancieros F
        ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
       AND F.IdEmpresa = D.IdEmpresa
       AND F.Eliminado = 0
WHERE D.Eliminado = 0
  AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
  AND D.Descripcion COLLATE Latin1_General_CI_AI = 'POR CARTERA DE PRESTAMOS';

UPDATE A
SET A.CuentaContable = C.CuentaContable,
    A.NombreCuenta = C.Nombre,
    A.Usuario = @UsuarioActualizacion,
    A.FechaHora = @FechaActualizacion,
    A.NombreEquipo = @EquipoActualizacion,
    A.Sincronizado = 0,
    A.FechaHoraSincronizacion = NULL
FROM dbo.CR_EstadosFinancierosDetalleCuentas A
INNER JOIN dbo.CR_EstadosFinancierosDetalle D
        ON D.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle
       AND D.IdEmpresa = A.IdEmpresa
       AND D.Eliminado = 0
INNER JOIN dbo.CR_EstadosFinancieros F
        ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
       AND F.IdEmpresa = D.IdEmpresa
       AND F.Eliminado = 0
INNER JOIN dbo.CR_CuentasContables C
        ON C.IdCuentaContable = A.IdCuentaContable
       AND C.IdEmpresa = A.IdEmpresa
       AND C.Eliminado = 0
WHERE A.Eliminado = 0
  AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
  AND A.NombreCuenta COLLATE Latin1_General_CI_AI LIKE '%CARTERA DE PRESTAMOS%'
  AND A.NombreCuenta COLLATE Latin1_General_CI_AI NOT LIKE '%MORATORIOS%';

UPDATE A
SET A.IdCuentaContable = C.IdCuentaContable,
    A.CuentaContable = C.CuentaContable,
    A.NombreCuenta = C.Nombre,
    A.Usuario = @UsuarioActualizacion,
    A.FechaHora = @FechaActualizacion,
    A.NombreEquipo = @EquipoActualizacion,
    A.Sincronizado = 0,
    A.FechaHoraSincronizacion = NULL
FROM dbo.CR_EstadosFinancierosDetalleCuentas A
INNER JOIN dbo.CR_EstadosFinancierosDetalle D
        ON D.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle
       AND D.IdEmpresa = A.IdEmpresa
       AND D.Eliminado = 0
INNER JOIN dbo.CR_EstadosFinancieros F
        ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
       AND F.IdEmpresa = D.IdEmpresa
       AND F.Eliminado = 0
INNER JOIN dbo.CR_CuentasContables C
        ON C.IdEmpresa = A.IdEmpresa
       AND C.CuentaContable = '40103'
       AND C.Nombre COLLATE Latin1_General_CI_AI LIKE '%INTERESES MORATORIOS%COMISIONES%'
       AND C.Eliminado = 0
WHERE A.Eliminado = 0
  AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
  AND A.NombreCuenta COLLATE Latin1_General_CI_AI LIKE '%INTERESES MORATORIOS%COMISIONES%';

UPDATE A
SET A.Eliminado = 1,
    A.Usuario = @UsuarioActualizacion,
    A.FechaHora = @FechaActualizacion,
    A.NombreEquipo = @EquipoActualizacion,
    A.Sincronizado = 0,
    A.FechaHoraSincronizacion = NULL
FROM dbo.CR_EstadosFinancierosDetalleCuentas A
INNER JOIN dbo.CR_EstadosFinancierosDetalle D
        ON D.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle
       AND D.IdEmpresa = A.IdEmpresa
       AND D.Eliminado = 0
INNER JOIN dbo.CR_EstadosFinancieros F
        ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
       AND F.IdEmpresa = D.IdEmpresa
       AND F.Eliminado = 0
INNER JOIN dbo.CR_CuentasContables C
        ON C.IdCuentaContable = A.IdCuentaContable
       AND C.IdEmpresa = A.IdEmpresa
WHERE A.Eliminado = 0
  AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
  AND A.NombreCuenta COLLATE Latin1_General_CI_AI = 'ARRENDAMIENTOS'
  AND C.Nombre COLLATE Latin1_General_CI_AI LIKE '%INTERESES MORATORIOS%';

UPDATE A
SET A.Eliminado = 1,
    A.Usuario = @UsuarioActualizacion,
    A.FechaHora = @FechaActualizacion,
    A.NombreEquipo = @EquipoActualizacion,
    A.Sincronizado = 0,
    A.FechaHoraSincronizacion = NULL
FROM dbo.CR_EstadosFinancierosDetalleCuentas A
INNER JOIN dbo.CR_EstadosFinancierosDetalle D
        ON D.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle
       AND D.IdEmpresa = A.IdEmpresa
       AND D.Eliminado = 0
INNER JOIN dbo.CR_EstadosFinancieros F
        ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
       AND F.IdEmpresa = D.IdEmpresa
       AND F.Eliminado = 0
INNER JOIN dbo.CR_CuentasContables C
        ON C.IdCuentaContable = A.IdCuentaContable
       AND C.IdEmpresa = A.IdEmpresa
WHERE A.Eliminado = 0
  AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
  AND D.Descripcion COLLATE Latin1_General_CI_AI = 'MARGEN FINANCIERO'
  AND C.CuentaContable LIKE '402%';

UPDATE D
SET D.ParametroLinea = 3,
    D.Usuario = @UsuarioActualizacion,
    D.FechaHora = @FechaActualizacion,
    D.NombreEquipo = @EquipoActualizacion,
    D.Sincronizado = 0,
    D.FechaHoraSincronizacion = NULL
FROM dbo.CR_EstadosFinancierosDetalle D
INNER JOIN dbo.CR_EstadosFinancieros F
        ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
       AND F.IdEmpresa = D.IdEmpresa
       AND F.Eliminado = 0
WHERE D.Eliminado = 0
  AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
  AND D.Descripcion COLLATE Latin1_General_CI_AI = 'MARGEN FINANCIERO'
  AND D.ParametroLinea <> 3;

IF EXISTS (
    SELECT 1
    FROM dbo.CR_EstadosFinancierosDetalle D
    INNER JOIN dbo.CR_EstadosFinancieros F
            ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
           AND F.IdEmpresa = D.IdEmpresa
           AND F.Eliminado = 0
    INNER JOIN dbo.CR_EstadosFinancierosDetalleCuentas A
            ON A.IdEstadoFinancieroDetalle = D.IdEstadoFinancieroDetalle
           AND A.IdEmpresa = D.IdEmpresa
           AND A.Eliminado = 0
    WHERE D.Eliminado = 0
      AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
      AND D.ParametroLinea = 2
    GROUP BY D.IdEmpresa, D.IdEstadoFinanciero, A.IdCuentaContable
    HAVING COUNT(DISTINCT D.IdEstadoFinancieroDetalle) > 1
)
    THROW 50004, 'Quedaron cuentas repetidas entre las líneas individuales del Estado de Resultados.', 1;

IF EXISTS (
    SELECT 1
    FROM dbo.CR_EstadosFinancierosDetalle D
    INNER JOIN dbo.CR_EstadosFinancieros F
            ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
           AND F.IdEmpresa = D.IdEmpresa
           AND F.Eliminado = 0
    INNER JOIN dbo.CR_EstadosFinancierosDetalleCuentas A
            ON A.IdEstadoFinancieroDetalle = D.IdEstadoFinancieroDetalle
           AND A.IdEmpresa = D.IdEmpresa
           AND A.Eliminado = 0
    INNER JOIN dbo.CR_CuentasContables C
            ON C.IdCuentaContable = A.IdCuentaContable
           AND C.IdEmpresa = A.IdEmpresa
    WHERE D.Eliminado = 0
      AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
      AND D.Descripcion COLLATE Latin1_General_CI_AI = 'MARGEN FINANCIERO'
      AND C.CuentaContable LIKE '402%'
)
    THROW 50005, 'El margen financiero todavía contiene otros ingresos no financieros.', 1;

IF EXISTS (
    SELECT 1
    FROM dbo.CR_EstadosFinancierosDetalle D
    INNER JOIN dbo.CR_EstadosFinancieros F
            ON F.IdEstadoFinanciero = D.IdEstadoFinanciero
           AND F.IdEmpresa = D.IdEmpresa
           AND F.Eliminado = 0
    WHERE D.Eliminado = 0
      AND F.Nombre COLLATE Latin1_General_CI_AI LIKE '%ESTADO DE RESULTADOS%'
      AND D.Descripcion COLLATE Latin1_General_CI_AI = 'MARGEN FINANCIERO'
      AND D.ParametroLinea <> 3
)
    THROW 50006, 'El margen financiero no quedó configurado como una línea de total.', 1;

COMMIT TRANSACTION;
GO
