SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'dbo.fn_CR_Prestamos_InteresDiario', N'FN') IS NULL
    EXEC(N'CREATE FUNCTION dbo.fn_CR_Prestamos_InteresDiario(@IdPrestamo INT, @FechaCalculo DATE) RETURNS DECIMAL(18, 2) AS BEGIN RETURN 0; END');
GO

ALTER FUNCTION [dbo].[fn_CR_Prestamos_InteresDiario]
(
    @IdPrestamo INT,
    @FechaCalculo DATE
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @InteresVencido DECIMAL(18, 2) = 0;

    IF @FechaCalculo IS NULL
        RETURN 0;

    SELECT @InteresVencido = COALESCE(SUM(
               CASE
                   WHEN detalle.FechaCuota <= @FechaCalculo
                       THEN CASE
                                WHEN COALESCE(detalle.SaldoInteres,
                                              detalle.InteresProyectado - COALESCE(detalle.InteresCobrado, 0),
                                              0) > 0
                                    THEN COALESCE(detalle.SaldoInteres,
                                                  detalle.InteresProyectado - COALESCE(detalle.InteresCobrado, 0),
                                                  0)
                                ELSE 0
                            END
                   ELSE 0
               END
           ), 0)
    FROM dbo.CR_PrestamosDetalle detalle
    WHERE detalle.IdPrestamo = @IdPrestamo
      AND detalle.Cancelada = 0
      AND detalle.Eliminado = 0;

    RETURN ROUND(@InteresVencido, 2);
END;
GO

IF OBJECT_ID(N'dbo.fn_CR_PrestamosDetalle_InteresPlanDiario', N'FN') IS NULL
    EXEC(N'CREATE FUNCTION dbo.fn_CR_PrestamosDetalle_InteresPlanDiario(@IdPrestamoDetalle INT, @FechaCalculo DATE) RETURNS DECIMAL(18, 2) AS BEGIN RETURN 0; END');
GO

ALTER FUNCTION [dbo].[fn_CR_PrestamosDetalle_InteresPlanDiario]
(
    @IdPrestamoDetalle INT,
    @FechaCalculo DATE
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @IdPrestamo INT,
            @FechaInicio DATE,
            @FechaInicioPeriodo DATE,
            @FechaCuota DATE,
            @InteresMensual DECIMAL(18, 2),
            @DiasPeriodo INT,
            @DiasTranscurridos INT;

    SELECT @IdPrestamo = detalle.IdPrestamo,
           @FechaInicio = prestamo.FechaInicio,
           @FechaCuota = detalle.FechaCuota,
           @InteresMensual = COALESCE(detalle.SaldoInteres,
                                      detalle.InteresProyectado - COALESCE(detalle.InteresCobrado, 0),
                                      0)
    FROM dbo.CR_PrestamosDetalle detalle
    INNER JOIN dbo.CR_Prestamos prestamo
        ON prestamo.IdPrestamo = detalle.IdPrestamo
    WHERE detalle.IdPrestamoDetalle = @IdPrestamoDetalle
      AND detalle.Cancelada = 0
      AND detalle.Eliminado = 0;

    IF @FechaCuota IS NULL OR @FechaCalculo IS NULL OR @InteresMensual <= 0
        RETURN 0;

    SELECT @FechaInicioPeriodo = COALESCE(MAX(anterior.FechaCuota), @FechaInicio)
    FROM dbo.CR_PrestamosDetalle anterior
    WHERE anterior.IdPrestamo = @IdPrestamo
      AND anterior.Eliminado = 0
      AND anterior.FechaCuota < @FechaCuota;

    IF @FechaCalculo >= @FechaCuota
        RETURN ROUND(@InteresMensual, 2);

    IF @FechaInicioPeriodo IS NULL OR @FechaCalculo <= @FechaInicioPeriodo
        RETURN 0;

    SET @DiasPeriodo = DATEDIFF(DAY, @FechaInicioPeriodo, @FechaCuota);
    SET @DiasTranscurridos = DATEDIFF(DAY, @FechaInicioPeriodo, @FechaCalculo);

    IF @DiasPeriodo <= 0
        RETURN 0;

    RETURN ROUND(@InteresMensual * @DiasTranscurridos / CONVERT(DECIMAL(18, 6), @DiasPeriodo), 2);
END;
GO

IF OBJECT_ID(N'dbo.fn_CR_Prestamos_InteresPlanDiario', N'FN') IS NULL
    EXEC(N'CREATE FUNCTION dbo.fn_CR_Prestamos_InteresPlanDiario(@IdPrestamo INT, @FechaCalculo DATE) RETURNS DECIMAL(18, 2) AS BEGIN RETURN 0; END');
GO

ALTER FUNCTION [dbo].[fn_CR_Prestamos_InteresPlanDiario]
(
    @IdPrestamo INT,
    @FechaCalculo DATE
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @Interes DECIMAL(18, 2) = 0;

    SELECT @Interes = COALESCE(SUM(dbo.fn_CR_PrestamosDetalle_InteresPlanDiario(
               detalle.IdPrestamoDetalle,
               @FechaCalculo
           )), 0)
    FROM dbo.CR_PrestamosDetalle detalle
    WHERE detalle.IdPrestamo = @IdPrestamo
      AND detalle.Cancelada = 0
      AND detalle.Eliminado = 0;

    RETURN ROUND(@Interes, 2);
END;
GO
