SET ANSI_NULLS ON;
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID(N'dbo.fn_CR_Prestamos_InteresDiario', N'FN') IS NULL
    EXEC(N'CREATE FUNCTION dbo.fn_CR_Prestamos_InteresDiario(@IdPrestamo INT, @FechaCalculo DATE) RETURNS DECIMAL(18, 2) AS BEGIN RETURN 0; END');
GO

ALTER FUNCTION [dbo].[fn_CR_Prestamos_InteresDiario]
(
    @IdPrestamo INT,
    @FechaCalculo DATE
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @InteresVencido DECIMAL(18, 2) = 0;

    IF @FechaCalculo IS NULL
        RETURN 0;

    SELECT @InteresVencido = COALESCE(SUM(
               CASE
                   WHEN detalle.FechaCuota <= @FechaCalculo
                       THEN CASE
                                WHEN COALESCE(detalle.SaldoInteres,
                                              detalle.InteresProyectado - COALESCE(detalle.InteresCobrado, 0),
                                              0) > 0
                                    THEN COALESCE(detalle.SaldoInteres,
                                                  detalle.InteresProyectado - COALESCE(detalle.InteresCobrado, 0),
                                                  0)
                                ELSE 0
                            END
                   ELSE 0
               END
           ), 0)
    FROM dbo.CR_PrestamosDetalle detalle
    WHERE detalle.IdPrestamo = @IdPrestamo
      AND detalle.Cancelada = 0
      AND detalle.Eliminado = 0;

    RETURN ROUND(@InteresVencido, 2);
END;
GO
