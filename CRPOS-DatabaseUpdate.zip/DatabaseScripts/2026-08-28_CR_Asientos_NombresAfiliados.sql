SET XACT_ABORT ON;
BEGIN TRANSACTION;
GO

IF COL_LENGTH('dbo.CR_Asientos', 'NombresAfiliados') IS NULL
BEGIN
    ALTER TABLE dbo.CR_Asientos ADD NombresAfiliados varchar(max) NULL;
END;
GO

CREATE OR ALTER FUNCTION dbo.FN_CR_Asientos_NombresAfiliados
(
    @IdEmpresa int,
    @FechaDesde date,
    @FechaHasta date
)
RETURNS TABLE
AS
RETURN
(
    WITH AsientosObjetivo AS
    (
        SELECT asiento.IdAsiento,
               asiento.IdEmpresa,
               asiento.FechaAsiento,
               tipo.Codigo
        FROM dbo.CR_Asientos asiento
        LEFT JOIN dbo.CR_TipoAsiento tipo
               ON tipo.IdTipoAsiento = asiento.IdTipoAsiento
        WHERE asiento.IdEmpresa = @IdEmpresa
          AND asiento.FechaAsiento BETWEEN @FechaDesde AND @FechaHasta
          AND ISNULL(asiento.Eliminado, 0) = 0
    ),
    Relaciones AS
    (
        SELECT asiento.IdAsiento,
               LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos))) NombreAfiliado
        FROM AsientosObjetivo asiento
        INNER JOIN dbo.CR_MovimientosCuentas movimiento
                ON movimiento.IdEmpresa = asiento.IdEmpresa
               AND movimiento.Eliminado = 0
        INNER JOIN dbo.CR_Cuentas cuenta
                ON cuenta.IdCuenta = movimiento.IdCuenta
               AND cuenta.IdEmpresa = movimiento.IdEmpresa
        INNER JOIN dbo.CR_Afiliados afiliado
                ON afiliado.IdAfiliado = cuenta.IdAfiliado
               AND afiliado.IdEmpresa = cuenta.IdEmpresa
        INNER JOIN dbo.Cr_TipoMovimientosCuenta tipoMovimiento
                ON tipoMovimiento.IdTipoMovimientoCuenta = movimiento.IdTipoMovimientoCuenta
               AND tipoMovimiento.IdEmpresa = movimiento.IdEmpresa
        INNER JOIN dbo.CR_TiposCuenta tipoCuenta
                ON tipoCuenta.IdTipoCuenta = cuenta.IdTipoCuenta
               AND tipoCuenta.IdEmpresa = cuenta.IdEmpresa
        WHERE
            (
                (ISNULL(movimiento.IdAsiento, 0) > 0 AND movimiento.IdAsiento = asiento.IdAsiento)
                OR
                (
                    ISNULL(movimiento.IdAsiento, 0) = 0
                    AND CONVERT(date, movimiento.FechaMovimiento) = asiento.FechaAsiento
                    AND movimiento.Reversado = 0
                    AND
                    (
                        (asiento.Codigo = '0001' AND tipoMovimiento.EsDeposito = 1 AND tipoCuenta.EsCuentaAhorro = 1 AND ISNULL(movimiento.EsReversion, 0) = 0)
                        OR (asiento.Codigo = '0002' AND tipoMovimiento.EsDeposito = 1 AND tipoCuenta.EsCuentaAhorro = 0)
                        OR (asiento.Codigo = '0006' AND tipoMovimiento.EsRetiro = 1 AND tipoCuenta.EsCuentaAhorro = 1)
                        OR (asiento.Codigo = '0007' AND tipoMovimiento.EsRetiro = 1 AND tipoCuenta.EsCuentaAhorro = 0)
                    )
                )
            )

        UNION

        SELECT asiento.IdAsiento,
               LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos))) NombreAfiliado
        FROM AsientosObjetivo asiento
        INNER JOIN dbo.CR_Capitalizaciones capitalizacion
                ON capitalizacion.IdEmpresa = asiento.IdEmpresa
               AND capitalizacion.Eliminado = 0
               AND CONVERT(date, capitalizacion.Fecha) = asiento.FechaAsiento
        INNER JOIN dbo.CR_Cuentas cuenta
                ON cuenta.IdCuenta = capitalizacion.IdCuenta
               AND cuenta.IdEmpresa = capitalizacion.IdEmpresa
        INNER JOIN dbo.CR_Afiliados afiliado
                ON afiliado.IdAfiliado = cuenta.IdAfiliado
               AND afiliado.IdEmpresa = cuenta.IdEmpresa
        INNER JOIN dbo.CR_TiposCuenta tipoCuenta
                ON tipoCuenta.IdTipoCuenta = cuenta.IdTipoCuenta
               AND tipoCuenta.IdEmpresa = cuenta.IdEmpresa
        WHERE (asiento.Codigo = '0008' AND tipoCuenta.EsCuentaAhorro = 1)
           OR (asiento.Codigo = '0009' AND tipoCuenta.EsCuentaAhorro = 0)

        UNION

        SELECT asiento.IdAsiento,
               LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos))) NombreAfiliado
        FROM AsientosObjetivo asiento
        INNER JOIN dbo.CR_Prestamos prestamo
                ON prestamo.IdEmpresa = asiento.IdEmpresa
               AND prestamo.Eliminado = 0
        INNER JOIN dbo.CR_Afiliados afiliado
                ON afiliado.IdAfiliado = prestamo.IdAfiliado
               AND afiliado.IdEmpresa = prestamo.IdEmpresa
        WHERE (ISNULL(prestamo.IdAsiento, 0) > 0 AND prestamo.IdAsiento = asiento.IdAsiento)
           OR (ISNULL(prestamo.IdAsiento, 0) = 0 AND asiento.Codigo = '0003' AND CONVERT(date, prestamo.FechaInicio) = asiento.FechaAsiento)

        UNION

        SELECT asiento.IdAsiento,
               LTRIM(RTRIM(CONCAT(afiliado.Nombres, ' ', afiliado.Apellidos))) NombreAfiliado
        FROM AsientosObjetivo asiento
        INNER JOIN dbo.CR_MovimientosPrestamos movimiento
                ON movimiento.IdEmpresa = asiento.IdEmpresa
               AND movimiento.Eliminado = 0
        INNER JOIN dbo.CR_Prestamos prestamo
                ON prestamo.IdPrestamo = movimiento.IdPrestamo
               AND prestamo.IdEmpresa = movimiento.IdEmpresa
        INNER JOIN dbo.CR_Afiliados afiliado
                ON afiliado.IdAfiliado = prestamo.IdAfiliado
               AND afiliado.IdEmpresa = prestamo.IdEmpresa
        INNER JOIN dbo.CR_TiposMovimientosPrestamos tipoMovimiento
                ON tipoMovimiento.IdTipoMovimientoPrestamo = movimiento.IdTipoMovimientoPrestamo
        WHERE (ISNULL(movimiento.IdAsiento, 0) > 0 AND movimiento.IdAsiento = asiento.IdAsiento)
           OR
           (
               ISNULL(movimiento.IdAsiento, 0) = 0
               AND asiento.Codigo = '0004'
               AND movimiento.Reversado = 0
               AND ISNULL(movimiento.EsReversion, 0) = 0
               AND tipoMovimiento.EsAbono = 1
               AND CONVERT(date, movimiento.FechaMovimiento) = asiento.FechaAsiento
           )
    )
    SELECT relacion.IdAsiento,
           STUFF
           (
               (
                   SELECT ', ' + nombre.NombreAfiliado
                   FROM
                   (
                       SELECT DISTINCT relacionDetalle.NombreAfiliado
                       FROM Relaciones relacionDetalle
                       WHERE relacionDetalle.IdAsiento = relacion.IdAsiento
                         AND NULLIF(relacionDetalle.NombreAfiliado, '') IS NOT NULL
                   ) nombre
                   ORDER BY nombre.NombreAfiliado
                   FOR XML PATH(''), TYPE
               ).value('.', 'varchar(max)'),
               1,
               2,
               ''
           ) NombresAfiliados
    FROM Relaciones relacion
    WHERE NULLIF(relacion.NombreAfiliado, '') IS NOT NULL
    GROUP BY relacion.IdAsiento
);
GO

CREATE OR ALTER PROCEDURE dbo.CR_Asientos_ActualizarNombresAfiliados
    @IdEmpresa int,
    @FechaDesde date,
    @FechaHasta date,
    @Usuario varchar(50),
    @NombreEquipo varchar(200)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE asiento
       SET asiento.NombresAfiliados = nombres.NombresAfiliados,
           asiento.Usuario = @Usuario,
           asiento.FechaHora = GETDATE(),
           asiento.NombreEquipo = @NombreEquipo,
           asiento.Sincronizado = 0,
           asiento.FechaHoraSincronizacion = NULL
    FROM dbo.CR_Asientos asiento
    INNER JOIN dbo.FN_CR_Asientos_NombresAfiliados(@IdEmpresa, @FechaDesde, @FechaHasta) nombres
            ON nombres.IdAsiento = asiento.IdAsiento
    WHERE asiento.IdEmpresa = @IdEmpresa
      AND asiento.FechaAsiento BETWEEN @FechaDesde AND @FechaHasta
      AND ISNULL(asiento.Eliminado, 0) = 0
      AND ISNULL(asiento.NombresAfiliados, '') <> ISNULL(nombres.NombresAfiliados, '');

    SELECT @@ROWCOUNT CantidadActualizada;
END;
GO

CREATE OR ALTER PROCEDURE dbo.POS_AsientosVisor
    @IdEmpresa int,
    @FechaDesde date,
    @FechaHasta date,
    @IdTipo int,
    @Busqueda varchar(200),
    @Anulado bit = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @Busqueda = ISNULL(@Busqueda, '');

    SELECT A.IdAsiento,
           A.IdAsiento NoAsiento,
           A.FechaAsiento,
           ISNULL(A.NumeroReferencia, '') NumeroReferencia,
           ISNULL(B.TipoAsiento, 'ASIENTO MANUAL') TipoAsiento,
           CASE
               WHEN NULLIF(COALESCE(NULLIF(N.NombresAfiliados, ''), NULLIF(A.NombresAfiliados, '')), '') IS NULL
                   THEN ISNULL(A.Sinopsis, '')
               WHEN CHARINDEX(COALESCE(NULLIF(N.NombresAfiliados, ''), A.NombresAfiliados), ISNULL(A.Sinopsis, '')) > 0
                   THEN ISNULL(A.Sinopsis, '')
               WHEN NULLIF(LTRIM(RTRIM(ISNULL(A.Sinopsis, ''))), '') IS NULL
                   THEN COALESCE(NULLIF(N.NombresAfiliados, ''), A.NombresAfiliados)
               ELSE ISNULL(A.Sinopsis, '') + ' - ' + COALESCE(NULLIF(N.NombresAfiliados, ''), A.NombresAfiliados)
           END Sinopsis,
           ISNULL(A.Anulado, 0) Anulado,
           A.FechaHoraMayorizacion,
           ISNULL(A.Mayorizado, 0) Mayorizado,
           ISNULL(A.IdTipoAsiento, -1) IdTipoAsiento
    FROM dbo.CR_Asientos A
    LEFT JOIN dbo.CR_TipoAsiento B
           ON A.IdTipoAsiento = B.IdTipoAsiento
    LEFT JOIN dbo.FN_CR_Asientos_NombresAfiliados(@IdEmpresa, @FechaDesde, @FechaHasta) N
           ON N.IdAsiento = A.IdAsiento
    WHERE ISNULL(A.Eliminado, 0) = 0
      AND A.IdEmpresa = @IdEmpresa
      AND A.FechaAsiento BETWEEN @FechaDesde AND @FechaHasta
      AND ISNULL(A.IdTipoAsiento, -1) = CASE
                                            WHEN ISNULL(@IdTipo, 0) = 0 THEN ISNULL(A.IdTipoAsiento, -1)
                                            WHEN @IdTipo > 0 THEN @IdTipo
                                            ELSE -1
                                        END
      AND (@Anulado IS NULL OR A.Anulado = @Anulado)
      AND
      (
          ISNULL(A.NumeroReferencia, '') LIKE '%' + @Busqueda + '%'
          OR ISNULL(A.Sinopsis, '') LIKE '%' + @Busqueda + '%'
          OR ISNULL(COALESCE(NULLIF(N.NombresAfiliados, ''), A.NombresAfiliados), '') LIKE '%' + @Busqueda + '%'
      );
END;
GO

COMMIT TRANSACTION;
GO
