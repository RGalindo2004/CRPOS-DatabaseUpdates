/*
    CR_Prestamos_EliminarPrueba
    Script portable para ejecutar en bases restauradas o en varias empresas.

    No crea tablas ni inserta datos operativos.
    Solo:
      1. Crea/actualiza el procedimiento dbo.CR_Prestamos_EliminarPrueba.
      2. Actualiza la validacion de autorizaciones para permitir Administrador/Soporte.
      3. Crea la autorizacion 00004 para empresas activas de Caja Rural.
      4. Asigna esa autorizacion a los usuarios que ya tienen la 00002.
*/

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.SG_AutorizacionesUsuarios_ValidarUsuario', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.SG_AutorizacionesUsuarios_ValidarUsuario AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE [dbo].[SG_AutorizacionesUsuarios_ValidarUsuario]
    @IdEmpresa INT,
    @CodigoAutorizacion VARCHAR(200),
    @Usuario VARCHAR(50),
    @Contrasena VARCHAR(50),
    @Justificacion VARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdUsuario INT = 0;
    DECLARE @IdAutorizacion INT = 0;
    DECLARE @Perfil VARCHAR(250) = '';
    DECLARE @Mensaje VARCHAR(MAX) = '';
    DECLARE @Error BIT = 0;

    SELECT TOP 1
           @IdUsuario = u.IdUsuario,
           @Perfil = UPPER(LTRIM(RTRIM(ISNULL(p.Perfil, ''))))
    FROM dbo.SG_Usuarios u
    LEFT JOIN dbo.SG_Perfiles p
        ON p.IdPerfil = u.IdPerfil
    WHERE LTRIM(RTRIM(u.NombreUsuario)) = LTRIM(RTRIM(@Usuario))
      AND dbo.DesencriptarClave(u.Contrasena) = @Contrasena
      AND u.Activo = 1
      AND u.Eliminado = 0
      AND (u.IdEmpresa = @IdEmpresa OR u.IdEmpresa IS NULL);

    SELECT TOP 1
           @IdAutorizacion = sa.IdAutorizacion
    FROM dbo.SG_Autorizaciones sa
    WHERE sa.IdEmpresa = @IdEmpresa
      AND LTRIM(RTRIM(sa.Codigo)) = LTRIM(RTRIM(@CodigoAutorizacion))
      AND sa.Activo = 1;

    IF @IdUsuario <= 0
    BEGIN
        SET @Mensaje = '¡Usuario o Contraseña incorrectos!';
        SET @Error = 1;
    END
    ELSE IF @IdAutorizacion <= 0
    BEGIN
        SET @Mensaje = '¡Autorización no configurada o inactiva!';
        SET @Error = 1;
    END
    ELSE IF @Perfil NOT LIKE '%ADMINISTRADOR%'
         AND @Perfil NOT LIKE '%SOPORTE%'
         AND NOT EXISTS (
             SELECT 1
             FROM dbo.SG_AutorizacionesUsuarios sau
             WHERE sau.IdUsuario = @IdUsuario
               AND sau.IdEmpresa = @IdEmpresa
               AND sau.IdAutorizacion = @IdAutorizacion
               AND sau.Eliminado = 0
         )
    BEGIN
        SET @Mensaje = '¡Usuario no autorizado!';
        SET @Error = 1;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.SG_AutorizacionesLogs
        (
            IdEmpresa,
            IdAutorizacion,
            Usuario,
            FechaHora,
            Justificacion
        )
        VALUES
        (
            @IdEmpresa,
            @IdAutorizacion,
            @Usuario,
            GETDATE(),
            @Justificacion
        );
    END;

    SELECT @Mensaje AS Mensaje,
           @Error AS HayError;
END;
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.CR_Prestamos_EliminarPrueba', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.CR_Prestamos_EliminarPrueba AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.CR_Prestamos_EliminarPrueba
    @IdPrestamo INT,
    @HayError BIT OUTPUT,
    @Mensaje VARCHAR(200) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SET @HayError = 0;
    SET @Mensaje = '';

    BEGIN TRY
        IF @IdPrestamo IS NULL OR @IdPrestamo <= 0
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'Debe seleccionar un prestamo valido.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF NOT EXISTS (SELECT 1 FROM dbo.CR_Prestamos WHERE IdPrestamo = @IdPrestamo)
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se encontro el prestamo seleccionado.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (SELECT 1 FROM dbo.CR_Prestamos WHERE IdPrestamo = @IdPrestamo AND Eliminado = 1)
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'El prestamo seleccionado ya esta eliminado.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM dbo.CR_Prestamos
            WHERE IdPrestamo = @IdPrestamo
              AND (PosteadoPrestamo = 1 OR IdAsiento <> 0)
        )
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se puede eliminar un prestamo posteado contablemente.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM dbo.CR_MovimientosPrestamos
            WHERE IdPrestamo = @IdPrestamo
              AND Eliminado = 0
        )
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se puede eliminar un prestamo con movimientos registrados.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        BEGIN TRANSACTION;

        UPDATE im
        SET Eliminado = 1,
            Sincronizado = 0
        FROM dbo.CR_PrestamosDetalle_InteresesMora im
        INNER JOIN dbo.CR_PrestamosDetalle pd
            ON pd.IdPrestamoDetalle = im.IdPrestamoDetalle
        WHERE pd.IdPrestamo = @IdPrestamo
          AND im.Eliminado = 0;

        UPDATE dbo.CR_PrestamosDetalle
        SET Eliminado = 1,
            Sincronizado = 0
        WHERE IdPrestamo = @IdPrestamo
          AND Eliminado = 0;

        UPDATE dbo.CR_Prestamos
        SET Eliminado = 1,
            Sincronizado = 0
        WHERE IdPrestamo = @IdPrestamo
          AND Eliminado = 0;

        COMMIT TRANSACTION;

        SET @HayError = 0;
        SET @Mensaje = 'El prestamo fue eliminado correctamente.';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @HayError = 1;
        SET @Mensaje = LEFT(ERROR_MESSAGE(), 200);
    END CATCH;

    SELECT @HayError AS HayError, @Mensaje AS Mensaje;
END;
GO

DECLARE @AutorizacionesNuevas TABLE (IdAutorizacion INT, IdEmpresa INT);

;WITH EmpresasObjetivo AS
(
    SELECT e.IdEmpresa
    FROM dbo.AD_Empresas e
    WHERE e.Activo = 1
      AND e.Eliminado = 0
      AND e.AplicaCR = 1

    UNION

    SELECT el.IdEmpresa
    FROM dbo.AD_EmpresaLocal el
    WHERE el.Activo = 1
      AND el.AplicaCR = 1
)
INSERT INTO dbo.SG_Autorizaciones
(
    IdEmpresa,
    Codigo,
    Nombre,
    CajaRural,
    PuntoVenta,
    Activo,
    Usuario,
    FechaHora,
    NombreEquipo,
    Sincronizado,
    FechaHoraSincronizado
)
OUTPUT inserted.IdAutorizacion, inserted.IdEmpresa
INTO @AutorizacionesNuevas (IdAutorizacion, IdEmpresa)
SELECT
    e.IdEmpresa,
    '00004',
    'ELIMINAR PRESTAMO DE PRUEBA',
    1,
    0,
    1,
    'SA',
    GETDATE(),
    HOST_NAME(),
    0,
    NULL
FROM EmpresasObjetivo e
WHERE e.IdEmpresa IS NOT NULL
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.SG_Autorizaciones a
      WHERE a.IdEmpresa = e.IdEmpresa
        AND LTRIM(RTRIM(a.Codigo)) = '00004'
  );

;WITH EmpresasObjetivo AS
(
    SELECT e.IdEmpresa
    FROM dbo.AD_Empresas e
    WHERE e.Activo = 1
      AND e.Eliminado = 0
      AND e.AplicaCR = 1

    UNION

    SELECT el.IdEmpresa
    FROM dbo.AD_EmpresaLocal el
    WHERE el.Activo = 1
      AND el.AplicaCR = 1
)
UPDATE a
SET Nombre = 'ELIMINAR PRESTAMO DE PRUEBA',
    CajaRural = 1,
    PuntoVenta = 0,
    Activo = 1,
    Usuario = 'SA',
    FechaHora = GETDATE(),
    NombreEquipo = HOST_NAME(),
    Sincronizado = 0
FROM dbo.SG_Autorizaciones a
INNER JOIN EmpresasObjetivo e
    ON e.IdEmpresa = a.IdEmpresa
WHERE LTRIM(RTRIM(a.Codigo)) = '00004'
  AND (
      a.Activo <> 1
      OR a.CajaRural <> 1
      OR a.PuntoVenta <> 0
      OR LTRIM(RTRIM(ISNULL(a.Nombre, ''))) <> 'ELIMINAR PRESTAMO DE PRUEBA'
  );

INSERT INTO dbo.SG_AutorizacionesUsuarios
(
    IdEmpresa,
    IdAutorizacion,
    IdUsuario,
    Eliminado,
    Usuario,
    FechaHora,
    NombreEquipo,
    Sincronizado,
    FechaHoraSincronizado
)
SELECT
    aDestino.IdEmpresa,
    aDestino.IdAutorizacion,
    au.IdUsuario,
    0,
    'SA',
    GETDATE(),
    HOST_NAME(),
    0,
    NULL
FROM dbo.SG_Autorizaciones aDestino
INNER JOIN dbo.SG_Autorizaciones aBase
    ON aBase.IdEmpresa = aDestino.IdEmpresa
   AND LTRIM(RTRIM(aBase.Codigo)) = '00002'
INNER JOIN dbo.SG_AutorizacionesUsuarios au
    ON au.IdEmpresa = aBase.IdEmpresa
   AND au.IdAutorizacion = aBase.IdAutorizacion
   AND au.Eliminado = 0
WHERE LTRIM(RTRIM(aDestino.Codigo)) = '00004'
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.SG_AutorizacionesUsuarios existente
      WHERE existente.IdEmpresa = aDestino.IdEmpresa
        AND existente.IdAutorizacion = aDestino.IdAutorizacion
        AND existente.IdUsuario = au.IdUsuario
        AND existente.Eliminado = 0
  );
GO

IF OBJECT_ID('dbo.SG_Menus', 'U') IS NOT NULL
   AND OBJECT_ID('dbo.SG_MenusPerfiles', 'U') IS NOT NULL
   AND OBJECT_ID('dbo.SG_Perfiles', 'U') IS NOT NULL
BEGIN
    DECLARE @IdMenuConfiguracion INT;
    DECLARE @IdMenuBaseDatosPagina INT;
    DECLARE @IdMenuBaseDatosGrupo INT;
    DECLARE @IdMenuActualizarBaseDatos INT;

    SELECT @IdMenuConfiguracion = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mConfiguracion';

    IF @IdMenuConfiguracion IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mConfiguracion', 'Configuracion', NULL, 1, 0, 0, 1, 1);

        SET @IdMenuConfiguracion = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1,
            Nivel = 1,
            IdMenuPadre = NULL
        WHERE IdMenu = @IdMenuConfiguracion;
    END;

    SELECT @IdMenuBaseDatosPagina = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mConfiguracionBaseDatos';

    IF @IdMenuBaseDatosPagina IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mConfiguracionBaseDatos', 'Base de datos', @IdMenuConfiguracion, 2, 0, 0, 1, 1);

        SET @IdMenuBaseDatosPagina = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Base de datos',
            IdMenuPadre = @IdMenuConfiguracion,
            Nivel = 2,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuBaseDatosPagina;
    END;

    SELECT @IdMenuBaseDatosGrupo = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mBaseDatosEmpresa';

    IF @IdMenuBaseDatosGrupo IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mBaseDatosEmpresa', 'Base de datos', @IdMenuBaseDatosPagina, 3, 0, 0, 1, 1);

        SET @IdMenuBaseDatosGrupo = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Base de datos',
            IdMenuPadre = @IdMenuBaseDatosPagina,
            Nivel = 3,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuBaseDatosGrupo;
    END;

    SELECT @IdMenuActualizarBaseDatos = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mActualizarBaseDatos';

    IF @IdMenuActualizarBaseDatos IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mActualizarBaseDatos', 'Actualizar base de datos', @IdMenuBaseDatosGrupo, 4, 0, 0, 1, 1);

        SET @IdMenuActualizarBaseDatos = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Actualizar base de datos',
            IdMenuPadre = @IdMenuBaseDatosGrupo,
            Nivel = 4,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuActualizarBaseDatos;
    END;

    INSERT INTO dbo.SG_MenusPerfiles(IdMenu, IdPerfil, IdEmpresa)
    SELECT menu.IdMenu,
           p.IdPerfil,
           p.IdEmpresa
    FROM dbo.SG_Perfiles p
    CROSS APPLY
    (
        SELECT @IdMenuConfiguracion AS IdMenu
        UNION ALL SELECT @IdMenuBaseDatosPagina
        UNION ALL SELECT @IdMenuBaseDatosGrupo
        UNION ALL SELECT @IdMenuActualizarBaseDatos
    ) menu
    WHERE p.Activo = 1
      AND p.Eliminado = 0
      AND (
          UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%ADMINISTRADOR%'
          OR UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%SOPORTE%'
      )
      AND NOT EXISTS (
          SELECT 1
          FROM dbo.SG_MenusPerfiles mp
          WHERE mp.IdMenu = menu.IdMenu
            AND mp.IdPerfil = p.IdPerfil
            AND (
                (mp.IdEmpresa IS NULL AND p.IdEmpresa IS NULL)
                OR mp.IdEmpresa = p.IdEmpresa
            )
      );

    DELETE mp
    FROM dbo.SG_MenusPerfiles mp
    INNER JOIN dbo.SG_Perfiles p
        ON p.IdPerfil = mp.IdPerfil
    WHERE mp.IdMenu IN (
          @IdMenuConfiguracion,
          @IdMenuBaseDatosPagina,
          @IdMenuBaseDatosGrupo,
          @IdMenuActualizarBaseDatos
      )
      AND mp.IdEmpresa IS NULL
      AND p.IdEmpresa IS NOT NULL
      AND p.Activo = 1
      AND p.Eliminado = 0
      AND (
          UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%ADMINISTRADOR%'
          OR UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%SOPORTE%'
      )
      AND EXISTS (
          SELECT 1
          FROM dbo.SG_MenusPerfiles mpEmpresa
          WHERE mpEmpresa.IdMenu = mp.IdMenu
            AND mpEmpresa.IdPerfil = mp.IdPerfil
            AND mpEmpresa.IdEmpresa = p.IdEmpresa
      );
END;
GO

SELECT
    a.IdEmpresa,
    a.Codigo,
    a.Nombre,
    a.Activo,
    COUNT(au.IdAutorizacionUsuario) AS UsuariosAsignados
FROM dbo.SG_Autorizaciones a
LEFT JOIN dbo.SG_AutorizacionesUsuarios au
    ON au.IdEmpresa = a.IdEmpresa
   AND au.IdAutorizacion = a.IdAutorizacion
   AND au.Eliminado = 0
WHERE LTRIM(RTRIM(a.Codigo)) = '00004'
GROUP BY a.IdEmpresa, a.Codigo, a.Nombre, a.Activo
ORDER BY a.IdEmpresa;
GO

ALTER PROCEDURE [dbo].[SG_MenusPerfiles_SelectEmpresa]
    @IdPerfil INT,
    @IdEmpresa INT
AS
BEGIN
    DECLARE @CajaRural BIT,
            @PuntoVenta BIT

    SELECT  @CajaRural = ae.AplicaCR,
            @PuntoVenta = ae.AplicaPOS
    FROM    dbo.AD_EmpresaLocal ae
    WHERE   ae.IdEmpresa = @IdEmpresa

    SELECT DISTINCT
           sm.IdMenu,
           sm.NombreLogico,
           sm.NombreHeader,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END AS Nivel,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos'
                THEN (SELECT TOP 1 IdMenu FROM dbo.SG_Menus WHERE NombreLogico = 'mConfiguracionBaseDatos')
                ELSE sm.IdMenuPadre
           END AS IdMenuPadre,
           CAST((CASE WHEN smp.IdMenu IS NULL THEN 0 ELSE 1 END) AS BIT) Seleccionado
    FROM    dbo.SG_Menus sm
    LEFT JOIN dbo.SG_MenusPerfiles smp
           ON sm.IdMenu = smp.IdMenu
          AND smp.IdPerfil = @IdPerfil
          AND smp.IdEmpresa = @IdEmpresa
    WHERE   EXISTS(SELECT 1 FROM dbo.SG_Perfiles sp WHERE sp.IdPerfil = @IdPerfil AND sp.IdEmpresa = @IdEmpresa)
        AND sm.Empresa = 1
        AND sm.NombreLogico <> 'mBaseDatosEmpresa'
        AND (
            (sm.CajaRural = 0 AND sm.PuntoVenta = 0)
            OR (sm.CajaRural = 1 AND sm.PuntoVenta = 0 AND @CajaRural = 1)
            OR (sm.CajaRural = 0 AND sm.PuntoVenta = 1 AND @PuntoVenta = 1)
        )
    ORDER BY CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END,
             sm.NombreHeader;
END;
GO

ALTER PROCEDURE [dbo].[SG_MenusPerfiles_SelectAdministracion]
    @IdPerfil INT
AS
BEGIN
    SELECT DISTINCT
           sm.IdMenu,
           sm.NombreLogico,
           sm.NombreHeader,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END AS Nivel,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos'
                THEN (SELECT TOP 1 IdMenu FROM dbo.SG_Menus WHERE NombreLogico = 'mConfiguracionBaseDatos')
                ELSE sm.IdMenuPadre
           END AS IdMenuPadre,
           CAST((CASE WHEN smp.IdMenu IS NULL THEN 0 ELSE 1 END) AS BIT) Seleccionado
    FROM   dbo.SG_Menus sm
    LEFT JOIN dbo.SG_MenusPerfiles smp
           ON sm.IdMenu = smp.IdMenu
          AND smp.IdPerfil = @IdPerfil
          AND smp.IdEmpresa IS NULL
    WHERE  EXISTS(SELECT 1 FROM dbo.SG_Perfiles sp WHERE sp.IdPerfil = @IdPerfil AND sp.IdEmpresa IS NULL)
      AND  sm.Administracion = 1
      AND  sm.NombreLogico <> 'mBaseDatosEmpresa'
    ORDER BY CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END,
             sm.NombreHeader;
END;
GO

/*
    CR_EstadosFinancieros - Balance General
    1. Corrige el procedimiento de reporte para validar meses numericamente.
    2. Crea/actualiza el procedimiento que asegura la plantilla de Balance General
       desde CR_CuentasContables.
    3. Ejecuta la configuracion para empresas activas de Caja Rural.
*/

IF OBJECT_ID(N'dbo.CR_AsientosMayorizacion_ReporteEstadoFinanciero', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.CR_AsientosMayorizacion_ReporteEstadoFinanciero AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero]
    @IdEmpresa int = 1,
    @Anio int = 2025,
    @Mes varchar(100) = '5,6,7',
    @IdEstadoFinanciero int = 1
AS
BEGIN
    SET NOCOUNT ON;
    SET LANGUAGE Spanish;

    DECLARE @Meses TABLE(
        Mes int NOT NULL PRIMARY KEY
    );

    INSERT INTO @Meses(Mes)
    SELECT DISTINCT TRY_CONVERT(int, Value)
    FROM [dbo].[SplitString](@Mes, ',')
    WHERE TRY_CONVERT(int, Value) BETWEEN 1 AND 12;

    IF NOT EXISTS(SELECT 1 FROM @Meses)
    BEGIN
        RAISERROR('Debe seleccionar al menos un mes valido para generar el estado financiero.', 16, 1);
        RETURN;
    END;

    DECLARE @UltimoMes int,
            @Sql varchar(MAX),
            @Fecha date,
            @Dia int,
            @MesLetra varchar(50),
            @Var_Meses varchar(MAX),
            @EsBalanceGeneral bit = 0;

    SELECT @UltimoMes = MAX(Mes)
    FROM @Meses;

    SET @Fecha = DATEFROMPARTS(@Anio, @UltimoMes, 20);
    SET @Dia = DATEPART(DAY, EOMONTH(@Fecha));
    SET @MesLetra = DATENAME(MONTH, @Fecha);

    SELECT @Var_Meses = STUFF((
        SELECT ',' + CONVERT(varchar(2), Mes)
        FROM @Meses
        ORDER BY Mes
        FOR XML PATH(''), TYPE
    ).value('.', 'varchar(max)'), 1, 1, '');

    SELECT @EsBalanceGeneral =
        CASE
            WHEN UPPER(ISNULL(C.Codigo, '')) IN ('BG', 'BAL', 'BALGEN') THEN 1
            WHEN UPPER(ISNULL(C.Nombre, '')) COLLATE Latin1_General_CI_AI LIKE '%BALANCE%GENERAL%' THEN 1
            WHEN UPPER(ISNULL(C.Titulo, '')) COLLATE Latin1_General_CI_AI LIKE '%BALANCE%GENERAL%' THEN 1
            ELSE 0
        END
    FROM dbo.CR_EstadosFinancieros C
    WHERE C.IdEmpresa = @IdEmpresa
          AND C.IdEstadoFinanciero = @IdEstadoFinanciero
          AND C.Eliminado = 0;

    IF ISNULL(@EsBalanceGeneral, 0) = 1
    BEGIN
        -- BalanceGeneralDocumentoValidoMayorizado: el Balance General es una fotografia del ultimo mes mayorizado.
        -- BalanceGeneralUltimoMesAcumulado: para estados acumulados solo se usa el ultimo mes seleccionado.
        -- BalanceGeneralDesdePlanCuentasMayorizado: no depende de rubros manuales de CR_EstadosFinancierosDetalle.
        IF NOT EXISTS (
            SELECT 1
            FROM dbo.CR_AsientosMayorizacion M
            WHERE M.IdEmpresa = @IdEmpresa
                  AND M.Anio = @Anio
                  AND M.Mes = @UltimoMes
                  AND M.Eliminado = 0
        )
        BEGIN
            RAISERROR('No se puede generar el Balance General porque el mes seleccionado no tiene mayorizacion aplicada.', 16, 1);
            RETURN;
        END;

        DECLARE @Titulo varchar(500),
                @Subtitulo varchar(MAX),
                @NombreCR varchar(500);

        SELECT @Titulo = C.Titulo,
               @Subtitulo = C.Subtitulo,
               @NombreCR = E.NombreCR
        FROM dbo.CR_EstadosFinancieros C
             LEFT JOIN dbo.AD_EmpresaLocal E ON E.IdEmpresa = C.IdEmpresa
        WHERE C.IdEmpresa = @IdEmpresa
              AND C.IdEstadoFinanciero = @IdEstadoFinanciero
              AND C.Eliminado = 0;

        SET @Titulo = ISNULL(NULLIF(LTRIM(RTRIM(@Titulo)), ''), 'Balance General');

        DECLARE @Arbol TABLE(
            IdCuentaContable int NOT NULL PRIMARY KEY,
            IdCuentaPadre int NULL,
            CuentaContable varchar(100) NOT NULL,
            Nombre varchar(500) NOT NULL,
            TipoSaldo varchar(1) NOT NULL,
            Clase char(1) NOT NULL,
            Nivel int NOT NULL,
            IdGrupo int NULL
        );

        ;WITH CuentasActivas AS (
            SELECT C.IdCuentaContable,
                   C.IdCuentaPadre,
                   LTRIM(RTRIM(C.CuentaContable)) AS CuentaContable,
                   ISNULL(NULLIF(LTRIM(RTRIM(C.Nombre)), ''), LTRIM(RTRIM(C.CuentaContable))) AS Nombre,
                   UPPER(ISNULL(NULLIF(LTRIM(RTRIM(C.TipoSaldo)), ''), 'D')) AS TipoSaldo
            FROM dbo.CR_CuentasContables C
            WHERE C.IdEmpresa = @IdEmpresa
                  AND C.Eliminado = 0
                  AND LEFT(LTRIM(RTRIM(C.CuentaContable)), 1) IN ('1', '2', '3', '4', '5')
        ),
        Raices AS (
            SELECT C.IdCuentaContable,
                   C.IdCuentaPadre,
                   C.CuentaContable,
                   C.Nombre,
                   C.TipoSaldo,
                   LEFT(C.CuentaContable, 1) AS Clase,
                   CASE WHEN C.CuentaContable IN ('1', '2', '3', '4', '5') THEN CONVERT(bit, 1) ELSE CONVERT(bit, 0) END AS EsRaizClase
            FROM CuentasActivas C
            WHERE C.CuentaContable IN ('1', '2', '3', '4', '5')
                  OR C.IdCuentaPadre IS NULL
                  OR C.IdCuentaPadre = 0
                  OR NOT EXISTS (
                      SELECT 1
                      FROM CuentasActivas P
                      WHERE P.IdCuentaContable = C.IdCuentaPadre
                  )
        ),
        Arbol AS (
            SELECT R.IdCuentaContable,
                   R.IdCuentaPadre,
                   R.CuentaContable,
                   R.Nombre,
                   R.TipoSaldo,
                   R.Clase,
                   0 AS Nivel,
                   CASE WHEN R.EsRaizClase = 1 THEN CONVERT(int, NULL) ELSE R.IdCuentaContable END AS IdGrupo
            FROM Raices R
            UNION ALL
            SELECT H.IdCuentaContable,
                   H.IdCuentaPadre,
                   H.CuentaContable,
                   H.Nombre,
                   H.TipoSaldo,
                   A.Clase,
                   A.Nivel + 1 AS Nivel,
                   CASE WHEN A.IdGrupo IS NULL THEN H.IdCuentaContable ELSE A.IdGrupo END AS IdGrupo
            FROM CuentasActivas H
                 INNER JOIN Arbol A ON A.IdCuentaContable = H.IdCuentaPadre
            WHERE H.IdCuentaContable <> A.IdCuentaContable
        )
        INSERT INTO @Arbol(IdCuentaContable, IdCuentaPadre, CuentaContable, Nombre, TipoSaldo, Clase, Nivel, IdGrupo)
        SELECT IdCuentaContable,
               IdCuentaPadre,
               CuentaContable,
               Nombre,
               TipoSaldo,
               Clase,
               Nivel,
               IdGrupo
        FROM Arbol
        OPTION (MAXRECURSION 100);

        DECLARE @SaldosGrupos TABLE(
            IdGrupo int NOT NULL,
            Clase char(1) NOT NULL,
            CuentaContable varchar(100) NOT NULL,
            Nombre varchar(500) NOT NULL,
            SaldoAnterior numeric(18,6) NOT NULL,
            Saldo numeric(18,6) NOT NULL,
            PRIMARY KEY (IdGrupo, Clase)
        );

        ;WITH Movimientos AS (
            SELECT G.IdCuentaContable AS IdGrupo,
                   L.Clase,
                   G.CuentaContable,
                   G.Nombre,
                   M.Anio,
                   M.Mes,
                   CASE
                       WHEN L.Clase IN ('1', '5') THEN CASE WHEN L.TipoSaldo = 'D' THEN ISNULL(M.SaldoActual, 0) ELSE ISNULL(M.SaldoActual, 0) * -1 END
                       WHEN L.Clase IN ('2', '3', '4') THEN CASE WHEN L.TipoSaldo = 'C' THEN ISNULL(M.SaldoActual, 0) ELSE ISNULL(M.SaldoActual, 0) * -1 END
                       ELSE 0
                   END AS Movimiento
            FROM @Arbol L
                 INNER JOIN dbo.CR_AsientosMayorizacion M ON M.IdEmpresa = @IdEmpresa
                                                         AND M.IdCuentaContable = L.IdCuentaContable
                                                         AND M.Eliminado = 0
                                                         AND (
                                                             M.Anio < @Anio
                                                             OR (M.Anio = @Anio AND M.Mes <= @UltimoMes)
                                                         )
                 INNER JOIN @Arbol G ON G.IdCuentaContable = ISNULL(L.IdGrupo, L.IdCuentaContable)
            WHERE NOT EXISTS (
                      SELECT 1
                      FROM @Arbol H
                      WHERE H.IdCuentaPadre = L.IdCuentaContable
                  )
                  AND (
                      L.Clase IN ('1', '2', '3')
                      OR (L.Clase IN ('4', '5') AND M.Anio = @Anio)
                  )
        )
        INSERT INTO @SaldosGrupos(IdGrupo, Clase, CuentaContable, Nombre, SaldoAnterior, Saldo)
        SELECT IdGrupo,
               Clase,
               CuentaContable,
               Nombre,
               SUM(CASE
                       WHEN Anio < @Anio OR (Anio = @Anio AND Mes < @UltimoMes) THEN Movimiento
                       ELSE 0
                   END) AS SaldoAnterior,
               SUM(Movimiento) AS Saldo
        FROM Movimientos
        GROUP BY IdGrupo,
                 Clase,
                 CuentaContable,
                 Nombre;

        DECLARE @TotalActivo numeric(18,6) = ISNULL((SELECT SUM(Saldo) FROM @SaldosGrupos WHERE Clase = '1'), 0),
                @TotalPasivo numeric(18,6) = ISNULL((SELECT SUM(Saldo) FROM @SaldosGrupos WHERE Clase = '2'), 0),
                @TotalPatrimonio numeric(18,6) = ISNULL((SELECT SUM(Saldo) FROM @SaldosGrupos WHERE Clase = '3'), 0),
                @TotalIngresos numeric(18,6) = ISNULL((SELECT SUM(Saldo) FROM @SaldosGrupos WHERE Clase = '4'), 0),
                @TotalGastos numeric(18,6) = ISNULL((SELECT SUM(Saldo) FROM @SaldosGrupos WHERE Clase = '5'), 0),
                @ResultadoEjerciciosAnteriores numeric(18,6) = 0,
                @ResultadoEjercicio numeric(18,6) = 0,
                @ResultadoAnteriorUsado numeric(18,6) = 0,
                @ResultadoUsado numeric(18,6) = 0,
                @DiferenciaSinResultado numeric(18,6) = 0,
                @DiferenciaConResultadoActual numeric(18,6) = 0,
                @DiferenciaConResultado numeric(18,6) = 0;

        ;WITH MovimientosAnteriores AS (
            SELECT L.Clase,
                   CASE
                       WHEN L.Clase IN ('1', '5') THEN CASE WHEN L.TipoSaldo = 'D' THEN ISNULL(M.SaldoActual, 0) ELSE ISNULL(M.SaldoActual, 0) * -1 END
                       WHEN L.Clase IN ('2', '3', '4') THEN CASE WHEN L.TipoSaldo = 'C' THEN ISNULL(M.SaldoActual, 0) ELSE ISNULL(M.SaldoActual, 0) * -1 END
                       ELSE 0
                   END AS Movimiento
            FROM @Arbol L
                 INNER JOIN dbo.CR_AsientosMayorizacion M ON M.IdEmpresa = @IdEmpresa
                                                         AND M.IdCuentaContable = L.IdCuentaContable
                                                         AND M.Anio < @Anio
                                                         AND M.Eliminado = 0
            WHERE L.Clase IN ('4', '5')
                  AND NOT EXISTS (
                      SELECT 1
                      FROM @Arbol H
                      WHERE H.IdCuentaPadre = L.IdCuentaContable
                  )
        )
        SELECT @ResultadoEjerciciosAnteriores = ISNULL(SUM(CASE WHEN Clase = '4' THEN Movimiento ELSE Movimiento * -1 END), 0)
        FROM MovimientosAnteriores;

        SET @ResultadoEjercicio = @TotalIngresos - @TotalGastos;
        SET @DiferenciaSinResultado = ROUND(@TotalActivo - (@TotalPasivo + @TotalPatrimonio), 2);
        SET @DiferenciaConResultadoActual = ROUND(@TotalActivo - (@TotalPasivo + @TotalPatrimonio + @ResultadoEjercicio), 2);
        SET @DiferenciaConResultado = ROUND(@TotalActivo - (@TotalPasivo + @TotalPatrimonio + @ResultadoEjerciciosAnteriores + @ResultadoEjercicio), 2);

        IF ABS(@DiferenciaSinResultado) <= 0.01
        BEGIN
            SET @ResultadoAnteriorUsado = 0;
            SET @ResultadoUsado = 0;
        END
        ELSE IF ABS(@DiferenciaConResultadoActual) <= 0.01
        BEGIN
            SET @ResultadoAnteriorUsado = 0;
            SET @ResultadoUsado = @ResultadoEjercicio;
        END
        ELSE IF ABS(@DiferenciaConResultado) <= 0.01
        BEGIN
            SET @ResultadoAnteriorUsado = @ResultadoEjerciciosAnteriores;
            SET @ResultadoUsado = @ResultadoEjercicio;
        END
        ELSE
        BEGIN
            DECLARE @MensajeDescuadre nvarchar(4000);
            SET @MensajeDescuadre = N'Balance General descuadrado. Activo: '
                + CONVERT(varchar(50), CONVERT(money, @TotalActivo), 1)
                + N'; Pasivo: ' + CONVERT(varchar(50), CONVERT(money, @TotalPasivo), 1)
                + N'; Patrimonio: ' + CONVERT(varchar(50), CONVERT(money, @TotalPatrimonio), 1)
                + N'; Resultado ejercicios anteriores: ' + CONVERT(varchar(50), CONVERT(money, @ResultadoEjerciciosAnteriores), 1)
                + N'; Resultado del ejercicio: ' + CONVERT(varchar(50), CONVERT(money, @ResultadoEjercicio), 1)
                + N'; Diferencia sin resultado: ' + CONVERT(varchar(50), CONVERT(money, @DiferenciaSinResultado), 1)
                + N'; Diferencia con resultado actual: ' + CONVERT(varchar(50), CONVERT(money, @DiferenciaConResultadoActual), 1)
                + N'; Diferencia con resultados acumulados: ' + CONVERT(varchar(50), CONVERT(money, @DiferenciaConResultado), 1)
                + N'. Revise que el mes este mayorizado, que los meses anteriores existan y que los asientos del periodo esten cuadrados.';
            RAISERROR(@MensajeDescuadre, 16, 1);
            RETURN;
        END;

        DECLARE @Reporte TABLE(
            RowId int IDENTITY(1,1) NOT NULL PRIMARY KEY,
            Titulo varchar(500) NULL,
            Acumulado bit NOT NULL,
            ParametroLinea int NOT NULL,
            Negrita bit NOT NULL,
            Tabulacion int NOT NULL,
            Columna int NOT NULL,
            Fuente varchar(50) NOT NULL,
            Size int NOT NULL,
            NombreCuenta nvarchar(500) NOT NULL,
            Orden int NOT NULL,
            Anio int NOT NULL,
            Mes int NOT NULL,
            SaldoAnterior numeric(18,6) NULL,
            Saldo numeric(18,6) NULL,
            Subtitulo bit NOT NULL,
            DiaFinalMes int NOT NULL,
            MesLetra varchar(50) NOT NULL,
            NombreCR varchar(500) NULL
        );

        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        VALUES(@Titulo, 1, 1, 1, 0, 1, 'Cambria', 12, N'ACTIVO', 10, @Anio, @UltimoMes, NULL, NULL, 1, @Dia, @MesLetra, @NombreCR);

        ;WITH Detalle AS (
            SELECT ROW_NUMBER() OVER(ORDER BY CuentaContable, Nombre) AS Fila,
                   Nombre,
                   SaldoAnterior,
                   Saldo
            FROM @SaldosGrupos
            WHERE Clase = '1'
                  AND ABS(Saldo) > 0.01
        )
        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        SELECT @Titulo, 1, 2, 0, 0, 3, 'Cambria', 12, UPPER(Nombre), 20 + (Fila * 10), @Anio, @UltimoMes, SaldoAnterior, Saldo, 0, @Dia, @MesLetra, @NombreCR
        FROM Detalle;

        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        VALUES(@Titulo, 1, 2, 1, 0, 3, 'Cambria', 12, N'TOTAL ACTIVO', 990, @Anio, @UltimoMes, NULL, @TotalActivo, 0, @Dia, @MesLetra, @NombreCR);

        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        VALUES(@Titulo, 1, 1, 1, 0, 1, 'Cambria', 12, N'PASIVO', 1000, @Anio, @UltimoMes, NULL, NULL, 1, @Dia, @MesLetra, @NombreCR);

        ;WITH Detalle AS (
            SELECT ROW_NUMBER() OVER(ORDER BY CuentaContable, Nombre) AS Fila,
                   Nombre,
                   SaldoAnterior,
                   Saldo
            FROM @SaldosGrupos
            WHERE Clase = '2'
                  AND ABS(Saldo) > 0.01
        )
        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        SELECT @Titulo, 1, 2, 0, 0, 3, 'Cambria', 12, UPPER(Nombre), 1010 + (Fila * 10), @Anio, @UltimoMes, SaldoAnterior, Saldo, 0, @Dia, @MesLetra, @NombreCR
        FROM Detalle;

        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        VALUES(@Titulo, 1, 2, 1, 0, 3, 'Cambria', 12, N'TOTAL PASIVO', 1990, @Anio, @UltimoMes, NULL, @TotalPasivo, 0, @Dia, @MesLetra, @NombreCR);

        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        VALUES(@Titulo, 1, 1, 1, 0, 1, 'Cambria', 12, N'PATRIMONIO', 2000, @Anio, @UltimoMes, NULL, NULL, 1, @Dia, @MesLetra, @NombreCR);

        ;WITH Detalle AS (
            SELECT ROW_NUMBER() OVER(ORDER BY CuentaContable, Nombre) AS Fila,
                   Nombre,
                   SaldoAnterior,
                   Saldo
            FROM @SaldosGrupos
            WHERE Clase = '3'
                  AND ABS(Saldo) > 0.01
        )
        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        SELECT @Titulo, 1, 2, 0, 0, 3, 'Cambria', 12, UPPER(Nombre), 2010 + (Fila * 10), @Anio, @UltimoMes, SaldoAnterior, Saldo, 0, @Dia, @MesLetra, @NombreCR
        FROM Detalle;

        IF ABS(@ResultadoAnteriorUsado) > 0.01
        BEGIN
            INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
            VALUES(@Titulo, 1, 2, 0, 0, 3, 'Cambria', 12, N'RESULTADOS DE EJERCICIOS ANTERIORES', 2970, @Anio, @UltimoMes, NULL, @ResultadoAnteriorUsado, 0, @Dia, @MesLetra, @NombreCR);
        END;

        IF ABS(@ResultadoUsado) > 0.01
        BEGIN
            INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
            VALUES(@Titulo, 1, 2, 0, 0, 3, 'Cambria', 12, N'RESULTADO DEL EJERCICIO', 2980, @Anio, @UltimoMes, NULL, @ResultadoUsado, 0, @Dia, @MesLetra, @NombreCR);
        END;

        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        VALUES(@Titulo, 1, 2, 1, 0, 3, 'Cambria', 12, N'TOTAL PATRIMONIO', 2990, @Anio, @UltimoMes, NULL, @TotalPatrimonio + @ResultadoAnteriorUsado + @ResultadoUsado, 0, @Dia, @MesLetra, @NombreCR);

        INSERT INTO @Reporte(Titulo, Acumulado, ParametroLinea, Negrita, Tabulacion, Columna, Fuente, Size, NombreCuenta, Orden, Anio, Mes, SaldoAnterior, Saldo, Subtitulo, DiaFinalMes, MesLetra, NombreCR)
        VALUES(@Titulo, 1, 2, 1, 0, 3, 'Cambria', 12, N'TOTAL PASIVO + PATRIMONIO', 3000, @Anio, @UltimoMes, NULL, @TotalPasivo + @TotalPatrimonio + @ResultadoAnteriorUsado + @ResultadoUsado, 0, @Dia, @MesLetra, @NombreCR);

        SELECT Titulo,
               Acumulado,
               ParametroLinea,
               Negrita,
               Tabulacion,
               Columna,
               Fuente,
               Size,
               NombreCuenta,
               Orden,
               Anio,
               Mes,
               SaldoAnterior,
               Saldo,
               Subtitulo,
               DiaFinalMes,
               MesLetra,
               NombreCR
        FROM @Reporte
        ORDER BY Orden, RowId;

        RETURN;
    END;

    -- Para otros estados financieros se mantiene el comportamiento configurado por rubros.
    SET @Sql = '
        SELECT C.Titulo,
               CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END Acumulado,
               B.ParametroLinea,
               B.Negrita,
               B.Tabulacion,
               B.Columna,
               B.Fuente,
               B.Size,
               REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion NombreCuenta,
               B.Orden,
               ' + CONVERT(varchar(10), @Anio) + ' Anio,
               ' + CONVERT(varchar(10), @UltimoMes) + ' Mes,
               SUM(D.SaldoAnterior) SaldoAnterior,
               CASE WHEN B.ParametroLinea = 1 THEN NULL ELSE SUM(ISNULL(CASE WHEN C.Tipo = ''Acumulado'' THEN CASE WHEN A.Operacion = 2 THEN D.Saldo * -1 ELSE D.Saldo END ELSE CASE WHEN A.Operacion = 2 THEN D.SaldoActual * -1 ELSE D.SaldoActual END END,0)) END Saldo,
               B.Subtitulo,
               ' + CONVERT(varchar(10), @Dia) + ' DiaFinalMes,
               ''' + CONVERT(varchar(10), @MesLetra) + ''' MesLetra,
               E.NombreCR
        FROM CR_EstadosFinancierosDetalle B
             LEFT JOIN CR_EstadosFinancierosDetalleCuentas A ON B.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle AND A.Eliminado = 0
             LEFT JOIN CR_EstadosFinancieros C ON C.IdEstadoFinanciero = B.IdEstadoFinanciero AND C.IdEmpresa = B.IdEmpresa AND C.Eliminado = 0
             LEFT JOIN CR_AsientosMayorizacion D ON D.IdCuentaContable = A.IdCuentaContable AND D.IdEmpresa = A.IdEmpresa AND D.Anio = ' + CONVERT(varchar(10), @Anio) + ' AND ((C.Tipo = ''Acumulado'' AND D.Mes = ' + CONVERT(varchar(10), @UltimoMes) + ') OR (C.Tipo <> ''Acumulado'' AND D.Mes IN (' + @Var_Meses + '))) AND D.Eliminado = 0
             LEFT JOIN AD_EmpresaLocal E ON E.IdEmpresa = B.IdEmpresa
        WHERE B.Eliminado = 0
              AND B.IdEmpresa = ' + CONVERT(varchar(10), @IdEmpresa) + '
              AND C.IdEstadoFinanciero = ' + CONVERT(varchar(10), @IdEstadoFinanciero) + '
        GROUP BY C.Titulo,
               CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END,
               B.ParametroLinea,
               B.Negrita,
               B.Tabulacion,
               B.Columna,
               B.Fuente,
               B.Size,
               REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion,
               B.Orden,
               B.Subtitulo,
               E.NombreCR
        ORDER BY B.Orden';

    EXEC(@Sql);
END
GO

IF OBJECT_ID(N'dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[CR_EstadosFinancieros_AsegurarBalanceGeneral]
    @IdEmpresa int,
    @Usuario varchar(50) = 'SISTEMA',
    @NombreEquipo varchar(200) = 'SCRIPT',
    @CrearEstadoFinanciero bit = 1
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
    IF @IdEmpresa IS NULL OR @IdEmpresa <= 0
    BEGIN
        RAISERROR('Debe indicar una empresa valida.', 16, 1);
        RETURN;
    END;

    SET @Usuario = ISNULL(NULLIF(LTRIM(RTRIM(@Usuario)), ''), 'SISTEMA');
    SET @NombreEquipo = ISNULL(NULLIF(LTRIM(RTRIM(@NombreEquipo)), ''), 'SCRIPT');

    DECLARE @FechaHora datetime = GETDATE(),
            @IdEstadoFinanciero int;

    BEGIN TRANSACTION;

    SELECT TOP (1) @IdEstadoFinanciero = E.IdEstadoFinanciero
    FROM dbo.CR_EstadosFinancieros E
    WHERE E.IdEmpresa = @IdEmpresa
          AND E.Eliminado = 0
          AND (
              UPPER(ISNULL(E.Codigo, '')) IN ('BG', 'BAL', 'BALGEN')
              OR UPPER(ISNULL(E.Nombre, '')) LIKE '%BALANCE%'
              OR UPPER(ISNULL(E.Titulo, '')) LIKE '%BALANCE%'
          )
    ORDER BY CASE
                 WHEN UPPER(ISNULL(E.Nombre, '')) = 'BALANCE GENERAL' THEN 0
                 WHEN UPPER(ISNULL(E.Titulo, '')) = 'BALANCE GENERAL' THEN 1
                 ELSE 2
             END,
             E.IdEstadoFinanciero;

    IF @IdEstadoFinanciero IS NULL AND @CrearEstadoFinanciero = 1
    BEGIN
        INSERT INTO dbo.CR_EstadosFinancieros
            (IdEmpresa, Codigo, Nombre, Titulo, Subtitulo, Tipo, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
        VALUES
            (@IdEmpresa, 'BG', 'Balance General', 'Balance General', '', 'Acumulado', 0, @Usuario, @FechaHora, @NombreEquipo, 0, NULL);

        SET @IdEstadoFinanciero = SCOPE_IDENTITY();
    END;

    IF @IdEstadoFinanciero IS NULL
    BEGIN
        RAISERROR('No se encontro un estado financiero de Balance General para la empresa indicada.', 16, 1);
        RETURN;
    END;

    UPDATE dbo.CR_EstadosFinancieros
       SET Tipo = 'Acumulado',
           Eliminado = 0,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    WHERE IdEstadoFinanciero = @IdEstadoFinanciero
          AND IdEmpresa = @IdEmpresa
          AND (Tipo <> 'Acumulado' OR Eliminado <> 0);

    DECLARE @Cuentas TABLE(
        Categoria varchar(20) NOT NULL PRIMARY KEY,
        IdCuentaContable int NOT NULL,
        CuentaContable varchar(100) NOT NULL,
        Nombre varchar(500) NOT NULL
    );

    INSERT INTO @Cuentas(Categoria, IdCuentaContable, CuentaContable, Nombre)
    SELECT TOP (1) 'ACTIVO', C.IdCuentaContable, C.CuentaContable, ISNULL(C.Nombre, '')
    FROM dbo.CR_CuentasContables C
    WHERE C.IdEmpresa = @IdEmpresa
          AND C.Eliminado = 0
          AND (C.CuentaContable LIKE '1%' OR UPPER(ISNULL(C.Nombre, '')) LIKE '%ACTIVO%')
    ORDER BY CASE
                 WHEN C.IdCuentaPadre IS NULL OR C.IdCuentaPadre = 0
                      OR NOT EXISTS (
                          SELECT 1
                          FROM dbo.CR_CuentasContables P
                          WHERE P.IdEmpresa = C.IdEmpresa
                                AND P.IdCuentaContable = C.IdCuentaPadre
                                AND P.Eliminado = 0
                      ) THEN 0
                 ELSE 1
             END,
             CASE WHEN C.Operable = 0 THEN 0 ELSE 1 END,
             CASE WHEN C.CuentaContable LIKE '1%' THEN 0 ELSE 1 END,
             LEN(C.CuentaContable),
             C.CuentaContable;

    INSERT INTO @Cuentas(Categoria, IdCuentaContable, CuentaContable, Nombre)
    SELECT TOP (1) 'PASIVO', C.IdCuentaContable, C.CuentaContable, ISNULL(C.Nombre, '')
    FROM dbo.CR_CuentasContables C
    WHERE C.IdEmpresa = @IdEmpresa
          AND C.Eliminado = 0
          AND (C.CuentaContable LIKE '2%' OR UPPER(ISNULL(C.Nombre, '')) LIKE '%PASIVO%')
    ORDER BY CASE
                 WHEN C.IdCuentaPadre IS NULL OR C.IdCuentaPadre = 0
                      OR NOT EXISTS (
                          SELECT 1
                          FROM dbo.CR_CuentasContables P
                          WHERE P.IdEmpresa = C.IdEmpresa
                                AND P.IdCuentaContable = C.IdCuentaPadre
                                AND P.Eliminado = 0
                      ) THEN 0
                 ELSE 1
             END,
             CASE WHEN C.Operable = 0 THEN 0 ELSE 1 END,
             CASE WHEN C.CuentaContable LIKE '2%' THEN 0 ELSE 1 END,
             LEN(C.CuentaContable),
             C.CuentaContable;

    INSERT INTO @Cuentas(Categoria, IdCuentaContable, CuentaContable, Nombre)
    SELECT TOP (1) 'PATRIMONIO', C.IdCuentaContable, C.CuentaContable, ISNULL(C.Nombre, '')
    FROM dbo.CR_CuentasContables C
    WHERE C.IdEmpresa = @IdEmpresa
          AND C.Eliminado = 0
          AND (
              C.CuentaContable LIKE '3%'
              OR UPPER(ISNULL(C.Nombre, '')) LIKE '%PATRIMONIO%'
              OR UPPER(ISNULL(C.Nombre, '')) LIKE '%CAPITAL%'
          )
    ORDER BY CASE
                 WHEN C.IdCuentaPadre IS NULL OR C.IdCuentaPadre = 0
                      OR NOT EXISTS (
                          SELECT 1
                          FROM dbo.CR_CuentasContables P
                          WHERE P.IdEmpresa = C.IdEmpresa
                                AND P.IdCuentaContable = C.IdCuentaPadre
                                AND P.Eliminado = 0
                      ) THEN 0
                 ELSE 1
             END,
             CASE WHEN C.Operable = 0 THEN 0 ELSE 1 END,
             CASE WHEN C.CuentaContable LIKE '3%' THEN 0 ELSE 1 END,
             LEN(C.CuentaContable),
             C.CuentaContable;

    DECLARE @Faltantes varchar(200) = '';

    IF NOT EXISTS (SELECT 1 FROM @Cuentas WHERE Categoria = 'ACTIVO')
        SET @Faltantes = @Faltantes + ' ACTIVO';

    IF NOT EXISTS (SELECT 1 FROM @Cuentas WHERE Categoria = 'PASIVO')
        SET @Faltantes = @Faltantes + ' PASIVO';

    IF NOT EXISTS (SELECT 1 FROM @Cuentas WHERE Categoria = 'PATRIMONIO')
        SET @Faltantes = @Faltantes + ' PATRIMONIO/CAPITAL';

    IF @Faltantes <> ''
    BEGIN
        RAISERROR('No se encontraron cuentas raiz para:%s. Revise CR_CuentasContables.', 16, 1, @Faltantes);
        RETURN;
    END;

    DECLARE @Lineas TABLE(
        Clave varchar(50) NOT NULL PRIMARY KEY,
        Orden int NOT NULL,
        ParametroLinea int NOT NULL,
        Descripcion nvarchar(200) NOT NULL,
        Subtitulo bit NOT NULL,
        Negrita bit NOT NULL,
        Tabulacion int NOT NULL,
        Columna int NOT NULL,
        Fuente varchar(50) NOT NULL,
        Size int NOT NULL
    );

    INSERT INTO @Lineas(Clave, Orden, ParametroLinea, Descripcion, Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size)
    VALUES
        ('ACTIVO_TITULO', 10, 1, N'ACTIVO', 1, 1, 0, 1, 'Cambria', 12),
        ('ACTIVO_CAJA', 20, 2, N'CAJA', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_BANCOS', 30, 2, N'BANCOS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_DEPOSITOS_PLAZO', 40, 2, N'DEPÓSITOS A PLAZO', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_CARTERA_PRESTAMOS', 50, 2, N'CARTERA DE PRÉSTAMOS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_DEUDORES_VARIOS', 60, 2, N'DEUDORES VARIOS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_FUNCIONARIOS_EMPLEADOS', 70, 2, N'FUNCIONARIOS Y EMPLEADOS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_COOPERATIVISTAS', 80, 2, N'COOPERATIVISTAS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_CUENTAS_VARIAS', 90, 2, N'CUENTAS VARIAS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_TERRENOS_EVENTUALES', 100, 2, N'TERRENOS EVENTUALES', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_EDIFICIOS_EVENTUALES', 110, 2, N'EDIFICIOS EVENTUALES', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_BIENES_RAICES', 120, 2, N'ACTIVOS PARA BIENES RAÍCES', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_TERRENOS_EDIFICIOS', 130, 2, N'TERRENOS Y EDIFICIOS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_VEHICULOS', 140, 2, N'VEHÍCULOS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_MOBILIARIO_EQUIPO_OFICINA', 150, 2, N'MOBILIARIO Y EQUIPO DE OFICINA', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_MAQUINARIA_EQUIPO', 160, 2, N'MAQUINARIA Y EQUIPO', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_EQUIPO_INFORMATICA', 170, 2, N'EQUIPO DE INFORMÁTICA', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_PRIMAS_SEGURO', 180, 2, N'PRIMAS DE SEGURO', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_ESPECIES_FISCALES', 190, 2, N'ESPECIES FISCALES', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_OTROS_CARGOS_DIFERIDOS', 200, 2, N'OTROS CARGOS DIFERIDOS', 0, 0, 0, 3, 'Cambria', 12),
        ('ACTIVO_PROGRAMAS_APLICACIONES', 210, 2, N'PROGRAMAS Y APLICACIONES INFORMÁTICAS', 0, 0, 0, 3, 'Cambria', 12),
        ('TOTAL_ACTIVO', 220, 2, N'TOTAL ACTIVO', 0, 1, 0, 3, 'Cambria', 12),
        ('PASIVO_TITULO', 230, 1, N'PASIVO', 1, 1, 0, 1, 'Cambria', 12),
        ('PASIVO_ACREEDORES_VARIOS', 240, 2, N'ACREEDORES VARIOS', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_SUELDOS_PAGAR', 250, 2, N'SUELDOS POR PAGAR', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_SERVICIOS_PUBLICOS', 260, 2, N'SERVICIOS PUBLICOS', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_CUENTAS_VARIAS', 270, 2, N'CUENTAS VARIAS', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_EXCEDENTES_DISTRIBUIR', 280, 2, N'EXCEDENTES POR DISTRIBUIR', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_INTERESES_PAGAR', 290, 2, N'INTERESES POR PAGAR', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_AHORROS_NAVIDENOS', 300, 2, N'AHORROS NAVIDEÑOS', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_AHORROS_RETIRABLES', 310, 2, N'AHORROS RETIRABLES', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_DEPOSITOS_PLAZO', 320, 2, N'DEPÓSITOS A PLAZO', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_PRESTAMOS_PAGAR', 330, 2, N'PRÉSTAMOS POR PAGAR', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_PROVISION_CREDITOS_DUDOSOS', 340, 2, N'PROVISIÓN PARA CRÉDITOS DUDOSOS', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_PROVISION_INTERESES_DUDOSOS', 350, 2, N'PROVISIÓN PARA INTERESES DUDOSOS', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_DEPRECIACION_EDIFICIOS', 360, 2, N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_DEPRECIACION_VEHICULOS', 370, 2, N'DEPRECIACIÓN ACUMULADA DE VEHÍCULOS', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_DEPRECIACION_MOBILIARIO_EQUIPO_OFICINA', 380, 2, N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 0, 0, 0, 3, 'Cambria', 12),
        ('PASIVO_DEPRECIACION_MAQUINARIA_EQUIPO', 390, 2, N'DEPRECIACIÓN ACUMULADA DE MAQUINARIA Y EQUIPO', 0, 0, 0, 3, 'Cambria', 12),
        ('TOTAL_PASIVO', 400, 2, N'TOTAL PASIVO', 0, 1, 0, 3, 'Cambria', 12),
        ('PATRIMONIO_TITULO', 410, 1, N'PATRIMONIO', 1, 1, 0, 1, 'Cambria', 12),
        ('TOTAL_PATRIMONIO', 420, 2, N'TOTAL PATRIMONIO', 0, 1, 0, 3, 'Cambria', 12),
        ('TOTAL_PASIVO_PATRIMONIO', 430, 2, N'TOTAL PASIVO + PATRIMONIO', 0, 1, 0, 3, 'Cambria', 12);

    ;WITH LineasUnicas AS (
        SELECT L.*
        FROM @Lineas L
        WHERE NOT EXISTS (
            SELECT 1
            FROM @Lineas L2
            WHERE L2.Clave <> L.Clave
                  AND UPPER(LTRIM(RTRIM(L2.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
        )
    )
    UPDATE D
       SET Orden = L.Orden,
           ParametroLinea = L.ParametroLinea,
           Descripcion = L.Descripcion,
           Subtitulo = L.Subtitulo,
           Negrita = L.Negrita,
           Tabulacion = L.Tabulacion,
           Columna = L.Columna,
           Fuente = L.Fuente,
           Size = L.Size,
           Eliminado = 0,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalle D
         INNER JOIN LineasUnicas L ON UPPER(LTRIM(RTRIM(D.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
    WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
          AND D.IdEmpresa = @IdEmpresa;

    UPDATE D
       SET ParametroLinea = L.ParametroLinea,
           Subtitulo = L.Subtitulo,
           Negrita = L.Negrita,
           Tabulacion = L.Tabulacion,
           Columna = L.Columna,
           Fuente = L.Fuente,
           Size = L.Size,
           Eliminado = 0,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalle D
         INNER JOIN @Lineas L ON UPPER(LTRIM(RTRIM(D.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
                              AND D.Orden = L.Orden
    WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
          AND D.IdEmpresa = @IdEmpresa;

    UPDATE D
       SET Eliminado = 1,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalle D
    WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
          AND D.IdEmpresa = @IdEmpresa
          AND D.Eliminado = 0
          AND UPPER(LTRIM(RTRIM(D.Descripcion))) COLLATE Latin1_General_CI_AI = N'PASIVO Y PATRIMONIO'
          AND NOT EXISTS (
              SELECT 1
              FROM @Lineas L
              WHERE UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(D.Descripcion))) COLLATE Latin1_General_CI_AI
          );

    INSERT INTO dbo.CR_EstadosFinancierosDetalle
        (IdEstadoFinanciero, IdEmpresa, Orden, ParametroLinea, Descripcion, Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
    SELECT @IdEstadoFinanciero, @IdEmpresa, L.Orden, L.ParametroLinea, L.Descripcion, L.Subtitulo, L.Negrita, L.Tabulacion, L.Columna, L.Fuente, L.Size, 0, @Usuario, @FechaHora, @NombreEquipo, 0, NULL
    FROM @Lineas L
    WHERE NOT EXISTS (
        SELECT 1
        FROM dbo.CR_EstadosFinancierosDetalle D
        WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
              AND D.IdEmpresa = @IdEmpresa
              AND D.Eliminado = 0
              AND UPPER(LTRIM(RTRIM(D.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
              AND (
                  D.Orden = L.Orden
                  OR NOT EXISTS (
                      SELECT 1
                      FROM @Lineas L2
                      WHERE L2.Clave <> L.Clave
                            AND UPPER(LTRIM(RTRIM(L2.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
                  )
              )
    );

    UPDATE DC
       SET Eliminado = 1,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalleCuentas DC
         INNER JOIN dbo.CR_EstadosFinancierosDetalle D ON D.IdEstadoFinancieroDetalle = DC.IdEstadoFinancieroDetalle
    WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
          AND D.IdEmpresa = @IdEmpresa
          AND D.Eliminado = 0
          AND NOT EXISTS (
              SELECT 1
              FROM @Lineas L
              WHERE UPPER(LTRIM(RTRIM(D.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
          );

    UPDATE D
       SET Eliminado = 1,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalle D
    WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
          AND D.IdEmpresa = @IdEmpresa
          AND D.Eliminado = 0
          AND NOT EXISTS (
              SELECT 1
              FROM @Lineas L
              WHERE UPPER(LTRIM(RTRIM(D.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
          );

    DECLARE @Detalle TABLE(
        Clave varchar(50) NOT NULL PRIMARY KEY,
        IdEstadoFinancieroDetalle int NOT NULL
    );

    ;WITH Candidatos AS (
        SELECT L.Clave,
               D.IdEstadoFinancieroDetalle,
               ROW_NUMBER() OVER(
                   PARTITION BY L.Clave
                   ORDER BY CASE WHEN D.Orden = L.Orden THEN 0 ELSE 1 END,
                            ABS(D.Orden - L.Orden),
                            D.IdEstadoFinancieroDetalle
               ) AS Fila
        FROM @Lineas L
             INNER JOIN dbo.CR_EstadosFinancierosDetalle D ON UPPER(LTRIM(RTRIM(D.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
        WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
              AND D.IdEmpresa = @IdEmpresa
              AND D.Eliminado = 0
              AND (
                  D.Orden = L.Orden
                  OR NOT EXISTS (
                      SELECT 1
                      FROM @Lineas L2
                      WHERE L2.Clave <> L.Clave
                            AND UPPER(LTRIM(RTRIM(L2.Descripcion))) COLLATE Latin1_General_CI_AI = UPPER(LTRIM(RTRIM(L.Descripcion))) COLLATE Latin1_General_CI_AI
                  )
              )
    )
    INSERT INTO @Detalle(Clave, IdEstadoFinancieroDetalle)
    SELECT Clave, IdEstadoFinancieroDetalle
    FROM Candidatos
    WHERE Fila = 1;

    UPDATE D
       SET Orden = L.Orden,
           ParametroLinea = L.ParametroLinea,
           Descripcion = L.Descripcion,
           Subtitulo = L.Subtitulo,
           Negrita = L.Negrita,
           Tabulacion = L.Tabulacion,
           Columna = L.Columna,
           Fuente = L.Fuente,
           Size = L.Size,
           Eliminado = 0,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalle D
         INNER JOIN @Detalle X ON X.IdEstadoFinancieroDetalle = D.IdEstadoFinancieroDetalle
         INNER JOIN @Lineas L ON L.Clave = X.Clave;

    DECLARE @MapeoFinal TABLE(
        Clave varchar(50) NOT NULL,
        IdCuentaContable int NOT NULL,
        CuentaContable varchar(100) NOT NULL,
        Nombre varchar(500) NOT NULL,
        Operacion int NOT NULL,
        Orden int NOT NULL,
        PRIMARY KEY (Clave, IdCuentaContable)
    );

    INSERT INTO @MapeoFinal(Clave, IdCuentaContable, CuentaContable, Nombre, Operacion, Orden)
    SELECT 'TOTAL_ACTIVO', C.IdCuentaContable, C.CuentaContable, C.Nombre, 1, 1
    FROM @Cuentas C
    WHERE C.Categoria = 'ACTIVO'
    UNION ALL
    SELECT 'TOTAL_PASIVO', C.IdCuentaContable, C.CuentaContable, C.Nombre, 1, 1
    FROM @Cuentas C
    WHERE C.Categoria = 'PASIVO'
    UNION ALL
    SELECT 'TOTAL_PATRIMONIO', C.IdCuentaContable, C.CuentaContable, C.Nombre, 1, 1
    FROM @Cuentas C
    WHERE C.Categoria = 'PATRIMONIO'
    UNION ALL
    SELECT 'TOTAL_PASIVO_PATRIMONIO', C.IdCuentaContable, C.CuentaContable, C.Nombre, 1,
           CASE C.Categoria WHEN 'PASIVO' THEN 1 ELSE 2 END
    FROM @Cuentas C
    WHERE C.Categoria IN ('PASIVO', 'PATRIMONIO');

    DECLARE @Patrones TABLE(
        Clave varchar(50) NOT NULL,
        PrefijoCuenta varchar(10) NULL,
        Patron nvarchar(200) NOT NULL,
        Prioridad int NOT NULL,
        Operacion int NOT NULL,
        Orden int NOT NULL
    );

    INSERT INTO @Patrones(Clave, PrefijoCuenta, Patron, Prioridad, Operacion, Orden)
    VALUES
        ('ACTIVO_CAJA', '1', N'%CAJA%', 1, 1, 1),
        ('ACTIVO_BANCOS', '1', N'%BANCO%', 1, 1, 1),
        ('ACTIVO_DEPOSITOS_PLAZO', '1', N'%DEPOSITO%A%PLAZO%', 1, 1, 1),
        ('ACTIVO_DEPOSITOS_PLAZO', '1', N'%DEPÓSITO%A%PLAZO%', 1, 1, 1),
        ('ACTIVO_CARTERA_PRESTAMOS', '1', N'%CARTERA%PRESTAMO%', 1, 1, 1),
        ('ACTIVO_CARTERA_PRESTAMOS', '1', N'%PRESTAMO%COBRAR%', 2, 1, 1),
        ('ACTIVO_DEUDORES_VARIOS', '1', N'%DEUDORES%VARIOS%', 1, 1, 1),
        ('ACTIVO_FUNCIONARIOS_EMPLEADOS', '1', N'%FUNCIONARIOS%EMPLEADOS%', 1, 1, 1),
        ('ACTIVO_FUNCIONARIOS_EMPLEADOS', '1', N'%FUNCIONARIO%EMPLEADO%', 2, 1, 1),
        ('ACTIVO_COOPERATIVISTAS', '1', N'%COOPERATIVIST%', 1, 1, 1),
        ('ACTIVO_CUENTAS_VARIAS', '1', N'%CUENTAS%VARIAS%', 1, 1, 1),
        ('ACTIVO_TERRENOS_EVENTUALES', '1', N'%TERRENOS%EVENTUALES%', 1, 1, 1),
        ('ACTIVO_EDIFICIOS_EVENTUALES', '1', N'%EDIFICIOS%EVENTUALES%', 1, 1, 1),
        ('ACTIVO_BIENES_RAICES', '1', N'%BIENES%RAICES%', 1, 1, 1),
        ('ACTIVO_BIENES_RAICES', '1', N'%BIENES%RAÍCES%', 1, 1, 1),
        ('ACTIVO_TERRENOS_EDIFICIOS', '1', N'%TERRENOS%EDIFICIOS%', 1, 1, 1),
        ('ACTIVO_VEHICULOS', '1', N'%VEHICULO%', 1, 1, 1),
        ('ACTIVO_MOBILIARIO_EQUIPO_OFICINA', '1', N'%MOBILIARIO%EQUIPO%OFICINA%', 1, 1, 1),
        ('ACTIVO_MAQUINARIA_EQUIPO', '1', N'%MAQUINARIA%EQUIPO%', 1, 1, 1),
        ('ACTIVO_EQUIPO_INFORMATICA', '1', N'%EQUIPO%INFORMATICA%', 1, 1, 1),
        ('ACTIVO_PRIMAS_SEGURO', '1', N'%PRIMAS%SEGURO%', 1, 1, 1),
        ('ACTIVO_ESPECIES_FISCALES', '1', N'%ESPECIES%FISCALES%', 1, 1, 1),
        ('ACTIVO_OTROS_CARGOS_DIFERIDOS', '1', N'%OTROS%CARGOS%DIFERIDOS%', 1, 1, 1),
        ('ACTIVO_PROGRAMAS_APLICACIONES', '1', N'%PROGRAMAS%APLICACIONES%', 1, 1, 1),
        ('ACTIVO_PROGRAMAS_APLICACIONES', '1', N'%APLICACIONES%INFORMATICAS%', 2, 1, 1),
        ('PASIVO_ACREEDORES_VARIOS', '2', N'%ACREEDORES%VARIOS%', 1, 1, 1),
        ('PASIVO_SUELDOS_PAGAR', '2', N'%SUELDOS%PAGAR%', 1, 1, 1),
        ('PASIVO_SERVICIOS_PUBLICOS', '2', N'%SERVICIOS%PUBLICOS%', 1, 1, 1),
        ('PASIVO_CUENTAS_VARIAS', '2', N'%CUENTAS%VARIAS%', 1, 1, 1),
        ('PASIVO_EXCEDENTES_DISTRIBUIR', '2', N'%EXCEDENTES%DISTRIBUIR%', 1, 1, 1),
        ('PASIVO_INTERESES_PAGAR', '2', N'%INTERESES%PAGAR%', 1, 1, 1),
        ('PASIVO_AHORROS_NAVIDENOS', '2', N'%AHORROS%NAVID%', 1, 1, 1),
        ('PASIVO_AHORROS_RETIRABLES', '2', N'%AHORROS%RETIRABLES%', 1, 1, 1),
        ('PASIVO_AHORROS_RETIRABLES', '2', N'%AHORRO%RETIRABLE%', 2, 1, 1),
        ('PASIVO_DEPOSITOS_PLAZO', '2', N'%DEPOSITO%A%PLAZO%', 1, 1, 1),
        ('PASIVO_DEPOSITOS_PLAZO', '2', N'%DEPÓSITO%A%PLAZO%', 1, 1, 1),
        ('PASIVO_PRESTAMOS_PAGAR', '2', N'%PRESTAMOS%PAGAR%', 1, 1, 1),
        ('PASIVO_PRESTAMOS_PAGAR', '2', N'%PRESTAMO%POR%PAGAR%', 2, 1, 1),
        ('PASIVO_PROVISION_CREDITOS_DUDOSOS', NULL, N'%PROVISION%CREDITOS%DUDOSOS%', 1, 1, 1),
        ('PASIVO_PROVISION_CREDITOS_DUDOSOS', NULL, N'%PROVISIÓN%CRÉDITOS%DUDOSOS%', 1, 1, 1),
        ('PASIVO_PROVISION_INTERESES_DUDOSOS', NULL, N'%PROVISION%INTERESES%DUDOSOS%', 1, 1, 1),
        ('PASIVO_PROVISION_INTERESES_DUDOSOS', NULL, N'%PROVISIÓN%INTERESES%DUDOSOS%', 1, 1, 1),
        ('PASIVO_DEPRECIACION_EDIFICIOS', NULL, N'%DEPRECIACION%ACUMULADA%EDIFICIOS%', 1, 1, 1),
        ('PASIVO_DEPRECIACION_EDIFICIOS', NULL, N'%DEPRECIACIÓN%ACUMULADA%EDIFICIOS%', 1, 1, 1),
        ('PASIVO_DEPRECIACION_VEHICULOS', NULL, N'%DEPRECIACION%ACUMULADA%VEHICULOS%', 1, 1, 1),
        ('PASIVO_DEPRECIACION_VEHICULOS', NULL, N'%DEPRECIACIÓN%ACUMULADA%VEHÍCULOS%', 1, 1, 1),
        ('PASIVO_DEPRECIACION_MOBILIARIO_EQUIPO_OFICINA', NULL, N'%DEPRECIACION%ACUMULADA%MOBILIARIO%EQUIPO%OFICINA%', 1, 1, 1),
        ('PASIVO_DEPRECIACION_MOBILIARIO_EQUIPO_OFICINA', NULL, N'%DEPRECIACIÓN%ACUMULADA%MOBILIARIO%EQUIPO%OFICINA%', 1, 1, 1),
        ('PASIVO_DEPRECIACION_MAQUINARIA_EQUIPO', NULL, N'%DEPRECIACION%ACUMULADA%MAQUINARIA%EQUIPO%', 1, 1, 1),
        ('PASIVO_DEPRECIACION_MAQUINARIA_EQUIPO', NULL, N'%DEPRECIACIÓN%ACUMULADA%MAQUINARIA%EQUIPO%', 1, 1, 1);

    ;WITH Coincidencias AS (
        SELECT P.Clave,
               C.IdCuentaContable,
               C.CuentaContable,
               ISNULL(C.Nombre, '') AS Nombre,
               P.Operacion,
               P.Orden,
               ROW_NUMBER() OVER(
                   PARTITION BY P.Clave
                   ORDER BY P.Prioridad,
                            CASE WHEN C.Operable = 0 THEN 0 ELSE 1 END,
                            LEN(C.CuentaContable),
                            C.CuentaContable
               ) AS Fila
        FROM @Patrones P
             INNER JOIN dbo.CR_CuentasContables C ON C.IdEmpresa = @IdEmpresa
                                                 AND C.Eliminado = 0
                                                 AND (P.PrefijoCuenta IS NULL OR C.CuentaContable LIKE P.PrefijoCuenta + '%')
                                                 AND UPPER(ISNULL(C.Nombre, '')) COLLATE Latin1_General_CI_AI LIKE UPPER(P.Patron) COLLATE Latin1_General_CI_AI
    )
    INSERT INTO @MapeoFinal(Clave, IdCuentaContable, CuentaContable, Nombre, Operacion, Orden)
    SELECT Clave, IdCuentaContable, CuentaContable, Nombre, Operacion, Orden
    FROM Coincidencias C
    WHERE C.Fila = 1
          AND NOT EXISTS (
              SELECT 1
              FROM @MapeoFinal M
              WHERE M.Clave = C.Clave
                    AND M.IdCuentaContable = C.IdCuentaContable
          );

    UPDATE DC
       SET Eliminado = 1,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalleCuentas DC
         INNER JOIN @Detalle D ON D.IdEstadoFinancieroDetalle = DC.IdEstadoFinancieroDetalle
    WHERE DC.IdEmpresa = @IdEmpresa
          AND DC.Eliminado = 0
          AND EXISTS (
              SELECT 1
              FROM @MapeoFinal M
              WHERE M.Clave = D.Clave
          )
          AND NOT EXISTS (
              SELECT 1
              FROM @MapeoFinal M
              WHERE M.Clave = D.Clave
                    AND M.IdCuentaContable = DC.IdCuentaContable
          );

    UPDATE DC
       SET CuentaContable = M.CuentaContable,
           NombreCuenta = M.Nombre,
           Operacion = M.Operacion,
           Orden = M.Orden,
           Eliminado = 0,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalleCuentas DC
         INNER JOIN @Detalle D ON D.IdEstadoFinancieroDetalle = DC.IdEstadoFinancieroDetalle
         INNER JOIN @MapeoFinal M ON M.Clave = D.Clave
                                 AND M.IdCuentaContable = DC.IdCuentaContable
    WHERE DC.IdEmpresa = @IdEmpresa;

    INSERT INTO dbo.CR_EstadosFinancierosDetalleCuentas
        (IdEstadoFinancieroDetalle, IdEmpresa, IdCuentaContable, CuentaContable, NombreCuenta, Operacion, Orden, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
    SELECT D.IdEstadoFinancieroDetalle, @IdEmpresa, M.IdCuentaContable, M.CuentaContable, M.Nombre, M.Operacion, M.Orden, 0, @Usuario, @FechaHora, @NombreEquipo, 0, NULL
    FROM @MapeoFinal M
         INNER JOIN @Detalle D ON D.Clave = M.Clave
    WHERE NOT EXISTS (
        SELECT 1
        FROM dbo.CR_EstadosFinancierosDetalleCuentas DC
        WHERE DC.IdEstadoFinancieroDetalle = D.IdEstadoFinancieroDetalle
              AND DC.IdEmpresa = @IdEmpresa
              AND DC.IdCuentaContable = M.IdCuentaContable
    );

    COMMIT TRANSACTION;

    SELECT @IdEstadoFinanciero AS IdEstadoFinanciero,
           D.Clave,
           L.Descripcion,
           M.IdCuentaContable,
           M.CuentaContable,
           M.Nombre
    FROM @MapeoFinal M
         INNER JOIN @Detalle D ON D.Clave = M.Clave
         INNER JOIN @Lineas L ON L.Clave = D.Clave
    ORDER BY L.Orden, M.Orden, M.CuentaContable;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage nvarchar(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN;
    END CATCH;
END
GO

DECLARE @EmpresasBalanceGeneral TABLE(
    IdEmpresa int NOT NULL PRIMARY KEY
);

INSERT INTO @EmpresasBalanceGeneral(IdEmpresa)
SELECT e.IdEmpresa
FROM dbo.AD_Empresas e
WHERE e.Activo = 1
  AND e.Eliminado = 0
  AND e.AplicaCR = 1
  AND e.IdEmpresa IS NOT NULL

UNION

SELECT el.IdEmpresa
FROM dbo.AD_EmpresaLocal el
WHERE el.Activo = 1
  AND el.AplicaCR = 1
  AND el.IdEmpresa IS NOT NULL;

DECLARE @IdEmpresaBalanceGeneral int;

DECLARE EmpresasBalanceGeneralCursor CURSOR LOCAL FAST_FORWARD FOR
SELECT IdEmpresa
FROM @EmpresasBalanceGeneral
ORDER BY IdEmpresa;

OPEN EmpresasBalanceGeneralCursor;
FETCH NEXT FROM EmpresasBalanceGeneralCursor INTO @IdEmpresaBalanceGeneral;

WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral
        @IdEmpresa = @IdEmpresaBalanceGeneral,
        @Usuario = 'SA',
        @NombreEquipo = 'ACTUALIZACION';

    FETCH NEXT FROM EmpresasBalanceGeneralCursor INTO @IdEmpresaBalanceGeneral;
END;

CLOSE EmpresasBalanceGeneralCursor;
DEALLOCATE EmpresasBalanceGeneralCursor;
GO

/*
    SG_ActualizacionesBaseDatos
    Tabla de control para no volver a ejecutar el mismo paquete de actualizacion.
*/
IF OBJECT_ID(N'dbo.SG_ActualizacionesBaseDatos', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SG_ActualizacionesBaseDatos
    (
        IdActualizacionBaseDatos int IDENTITY(1,1) NOT NULL CONSTRAINT PK_SG_ActualizacionesBaseDatos PRIMARY KEY,
        PaqueteSha256 varchar(64) NOT NULL,
        OrigenPaquete varchar(500) NULL,
        FechaHora datetime NOT NULL CONSTRAINT DF_SG_ActualizacionesBaseDatos_FechaHora DEFAULT(GETDATE()),
        Usuario varchar(100) NULL,
        NombreEquipo varchar(200) NULL,
        Exitoso bit NOT NULL CONSTRAINT DF_SG_ActualizacionesBaseDatos_Exitoso DEFAULT(1),
        Detalle nvarchar(MAX) NULL
    );
END
GO

IF COL_LENGTH('dbo.SG_ActualizacionesBaseDatos', 'PaqueteSha256') IS NULL
BEGIN
    RAISERROR('La tabla dbo.SG_ActualizacionesBaseDatos existe, pero no tiene la columna PaqueteSha256.', 16, 1);
END
GO

/*
    POS_AsientosVisor - filtro Activos / Anulados / Todos
    Corrige @Anulado para que:
    - 0 use A.Anulado = 0
    - 1 use A.Anulado = 1
    - NULL muestre ambos
*/
IF OBJECT_ID(N'dbo.POS_AsientosVisor', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_AsientosVisor AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_AsientosVisor]
    @IdEmpresa int,
    @FechaDesde date,
    @FechaHasta date,
    @IdTipo int,
    @Busqueda varchar(200),
    @Anulado bit = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @Busqueda = ISNULL(@Busqueda, '');

    SELECT A.IdAsiento,
           A.IdAsiento NoAsiento,
           A.FechaAsiento,
           ISNULL(A.NumeroReferencia, '') NumeroReferencia,
           ISNULL(B.TipoAsiento, 'ASIENTO MANUAL') TipoAsiento,
           ISNULL(A.Sinopsis, '') Sinopsis,
           ISNULL(A.Anulado, 0) Anulado,
           A.FechaHoraMayorizacion,
           ISNULL(A.Mayorizado, 0) Mayorizado,
           ISNULL(A.IdTipoAsiento, -1) IdTipoAsiento
    FROM dbo.CR_Asientos A
         LEFT JOIN dbo.CR_TipoAsiento B ON A.IdTipoAsiento = B.IdTipoAsiento
    WHERE ISNULL(A.Eliminado, 0) = 0
      AND A.IdEmpresa = @IdEmpresa
      AND A.FechaAsiento BETWEEN @FechaDesde AND @FechaHasta
      AND ISNULL(A.IdTipoAsiento, -1) = CASE
                                            WHEN ISNULL(@IdTipo, 0) = 0 THEN ISNULL(A.IdTipoAsiento, -1)
                                            WHEN @IdTipo > 0 THEN @IdTipo
                                            ELSE -1
                                        END
      AND (@Anulado IS NULL OR A.Anulado = @Anulado)
      AND ISNULL(A.NumeroReferencia, '') LIKE '%' + @Busqueda + '%';
END
GO

/*
    POS_CompraProveedor - FechaRegistro y fecha de compra distinta
    Agrega FechaRegistro, la registra desde el encabezado y evita que
    POS_CompraProveedor_Finalizar reemplace FechaCompra con GETDATE().
*/
IF COL_LENGTH('dbo.POS_CompraProveedor', 'FechaRegistro') IS NULL
BEGIN
    ALTER TABLE dbo.POS_CompraProveedor ADD FechaRegistro date NULL;
END
GO

UPDATE dbo.POS_CompraProveedor
SET FechaRegistro = CAST(ISNULL(FechaCompra, GETDATE()) AS date)
WHERE FechaRegistro IS NULL;
GO

IF COL_LENGTH('dbo.POS_CompraProveedor', 'FechaRegistro') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1
       FROM sys.default_constraints dc
            INNER JOIN sys.columns c
                ON c.object_id = dc.parent_object_id
               AND c.column_id = dc.parent_column_id
       WHERE dc.parent_object_id = OBJECT_ID(N'dbo.POS_CompraProveedor')
         AND c.name = N'FechaRegistro'
   )
BEGIN
    ALTER TABLE dbo.POS_CompraProveedor
    ADD CONSTRAINT DF_POS_CompraProveedor_FechaRegistro DEFAULT(CONVERT(date, GETDATE())) FOR FechaRegistro;
END
GO

IF OBJECT_ID(N'dbo.POS_CompraProveedor_IniciarHeader', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_CompraProveedor_IniciarHeader AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_CompraProveedor_IniciarHeader]
    @IdEmpresa INT,
    @IdProveedor INT,
    @FechaCompra DATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.POS_CompraProveedor
    (
        IdEmpresa,
        IdProveedor,
        NumDocumentoCompra,
        CAICompra,
        FechaCompra,
        FechaRegistro,
        IdTermino,
        Comentario,
        SubTotal,
        Descuento,
        Impuesto,
        Total,
        UsuarioRegistro,
        NombreEquipo,
        Finalizada,
        Eliminado,
        FechaHora,
        Sincronizado
    )
    VALUES
    (   @IdEmpresa,
        @IdProveedor,
        '',
        '',
        ISNULL(@FechaCompra, CONVERT(date, GETDATE())),
        CONVERT(date, GETDATE()),
        1,
        '',
        0,
        0,
        0,
        0,
        '',
        '',
        0,
        0,
        GETDATE(),
        0);

    SELECT CONVERT(INT, SCOPE_IDENTITY()) AS IdCompraGenerada;
END
GO

IF OBJECT_ID(N'dbo.POS_CompraProveedor_Finalizar', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_CompraProveedor_Finalizar AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_CompraProveedor_Finalizar]
    @IdEmpresa INT,
    @IdCompraProveedor INT,
    @IdProveedor INT,
    @IdTermino INT,
    @Comentario VARCHAR(150),
    @NumDocumentoCompra VARCHAR(30),
    @CaiCompra VARCHAR(30),
    @Usuario VARCHAR(20),
    @NombreEquipo VARCHAR(30)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRAN;

    DECLARE @Credito BIT = 0;

    SELECT @Credito = a.EsCredito
    FROM dbo.POS_Terminos a
    WHERE a.IdTermino = @IdTermino;

    ---- Calcular Desglose
    DECLARE @SubTotal DECIMAL(19, 4);
    DECLARE @Impuesto DECIMAL(19, 4);
    DECLARE @Total DECIMAL(19, 4);
    DECLARE @DesgExento DECIMAL(19, 4);
    DECLARE @DesgGravado15 DECIMAL(19, 4);
    DECLARE @DesgGravado18 DECIMAL(19, 4);
    DECLARE @DesgImp15 DECIMAL(19, 4);
    DECLARE @DesgImp18 DECIMAL(19, 4);

    SELECT @SubTotal = SUM(Resumen.SubTotal),
           @DesgExento = SUM(Resumen.SubExento),
           @DesgGravado15 = SUM(Resumen.Sub15),
           @DesgGravado18 = SUM(Resumen.Sub18)
    FROM
    (
        SELECT d.SubTotal,
               CASE
                   WHEN d.ValorISV = 0 THEN
                       d.SubTotal
                   ELSE
                       0
               END AS SubExento,
               CASE
                   WHEN d.ValorISV = 15 THEN
                       d.SubTotal
                   ELSE
                       0
               END AS Sub15,
               CASE
                   WHEN d.ValorISV = 18 THEN
                       d.SubTotal
                   ELSE
                       0
               END AS Sub18
        FROM dbo.POS_DetalleCompraProveedor d
        WHERE d.IdCompraProveedor = @IdCompraProveedor
    ) AS Resumen;

    SET @DesgImp15 = @DesgGravado15 * 0.15;
    SET @DesgImp18 = @DesgGravado18 * 0.18;
    SET @Impuesto = @DesgImp15 + @DesgImp18;
    SET @Total = @SubTotal + @Impuesto;

    --- actualizar valores Compra Proveedor
    UPDATE POS_CompraProveedor
    SET [IdProveedor] = @IdProveedor,
        [FechaRegistro] = CONVERT(date, GETDATE()),
        [IdTermino] = @IdTermino,
        [Comentario] = @Comentario,
        [NumDocumentoCompra] = @NumDocumentoCompra,
        [CAICompra] = @CaiCompra,
        [SubTotal] = @SubTotal,
        [Impuesto] = @Impuesto,
        [Total] = @Total,
        Finalizada = 1,
        UsuarioRegistro = @Usuario,
        NombreEquipo = @NombreEquipo,
        FechaHora = GETDATE(),
        Sincronizado = 0
    WHERE IdCompraProveedor = @IdCompraProveedor;

    --- realizar el ingreso a kardex

    DECLARE @IdCategoriaKardex INT;

    SELECT @IdCategoriaKardex = a.IdCategoriaMovKardex
    FROM dbo.POS_CategoriaMovKardex a
    WHERE a.EsCompra = 1;

    DECLARE @Referencia VARCHAR(300)
        = 'Ingreso segun Compra a Proveedor  Factura :' + @NumDocumentoCompra + ' Nro Interno:'
          + CAST(@IdCompraProveedor AS VARCHAR(10));
    DECLARE @IdProducto INT;
    DECLARE @Cantidad INT;
    DECLARE CURSOR_detallecompraproveedor CURSOR FAST_FORWARD READ_ONLY FOR
    SELECT d.IdProducto,
           d.Cantidad
    FROM dbo.POS_DetalleCompraProveedor d
    WHERE d.IdCompraProveedor = @IdCompraProveedor;

    OPEN CURSOR_detallecompraproveedor;

    FETCH NEXT FROM CURSOR_detallecompraproveedor
    INTO @IdProducto,
         @Cantidad;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC dbo.POS_Kardex_RegistrarMov @IdProducto = @IdProducto,
                                         @IdEmpresa = @IdEmpresa,
                                         @Cantidad = @Cantidad,
                                         @IdCategoriaMovKardex = @IdCategoriaKardex,
                                         @NumDocumento = @IdCompraProveedor,
                                         @Referencia = @Referencia,
                                         @Usuario = @Usuario,
                                         @NombreEquipo = @NombreEquipo;

        FETCH NEXT FROM CURSOR_detallecompraproveedor
        INTO @IdProducto,
             @Cantidad;
    END;

    CLOSE CURSOR_detallecompraproveedor;
    DEALLOCATE CURSOR_detallecompraproveedor;

    IF (@Credito = 1)
    BEGIN
        DECLARE @NroDias INT;
        SELECT @NroDias = a.NroDias
        FROM dbo.POS_Terminos a
        WHERE a.IdTermino = @IdTermino;

        DECLARE @fechavence DATETIME = DATEADD(DAY, @NroDias, GETDATE());

        INSERT INTO dbo.POS_CuentaPorPagar
        (
            IdEmpresa,
            IdCompraProveedor,
            IdProveedor,
            FechaEmision,
            FechaVencimiento,
            MontoOriginal,
            SaldoActual,
            IdEstadoCuentaporPagar,
            Eliminado,
            Usuario,
            FechaHora,
            NombreEquipo,
            Sincronizado,
            FechaHoraSincronizacion
        )
        VALUES
        (   @IdEmpresa,
            @IdCompraProveedor,
            @IdProveedor,
            DEFAULT,
            @fechavence,
            @Total,
            @Total,
            1,
            0,
            @Usuario,
            GETDATE(),
            @NombreEquipo,
            0,
            NULL);
    END;

    COMMIT TRAN;
END
GO

IF OBJECT_ID(N'dbo.POS_CompraProveedor_Visor', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_CompraProveedor_Visor AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_CompraProveedor_Visor]
    @Desde DATE,
    @Hasta DATE,
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT compra.IdCompraProveedor,
           compra.FechaCompra,
           ISNULL(compra.FechaRegistro, CAST(compra.FechaCompra AS date)) AS FechaRegistro,
           compra.Comentario,
           compra.NumDocumentoCompra,
           compra.CAICompra,
           compra.SubTotal,
           compra.Impuesto,
           compra.Total,
           compra.UsuarioRegistro,
           compra.NombreEquipo,
           proveedor.NombreProveedor AS Proveedor,
           terminos.Terminos
    FROM dbo.POS_CompraProveedor compra
         INNER JOIN dbo.POS_Proveedor proveedor
            ON proveedor.IdProveedor = compra.IdProveedor
         INNER JOIN dbo.POS_Terminos terminos
            ON terminos.IdTermino = compra.IdTermino
    WHERE compra.Finalizada = 1
      AND CAST(compra.FechaCompra AS DATE) BETWEEN @Desde AND @Hasta
      AND compra.Eliminado = 0
      AND compra.IdEmpresa = @IdEmpresa;
END
GO

/*
    POS_Producto - Precio por cantidad
    Permite configurar un precio unitario especial cuando la cantidad facturada
    de un producto alcanza un minimo, por ejemplo una docena.
*/
IF COL_LENGTH('dbo.POS_Producto', 'PrecioPorCantidadActivo') IS NULL
BEGIN
    ALTER TABLE dbo.POS_Producto
    ADD PrecioPorCantidadActivo bit NOT NULL
        CONSTRAINT DF_POS_Producto_PrecioPorCantidadActivo DEFAULT(0);
END
GO

IF COL_LENGTH('dbo.POS_Producto', 'CantidadPrecioEspecial') IS NULL
BEGIN
    ALTER TABLE dbo.POS_Producto
    ADD CantidadPrecioEspecial decimal(18, 2) NOT NULL
        CONSTRAINT DF_POS_Producto_CantidadPrecioEspecial DEFAULT(0);
END
GO

IF COL_LENGTH('dbo.POS_Producto', 'PrecioPorCantidad') IS NULL
BEGIN
    ALTER TABLE dbo.POS_Producto
    ADD PrecioPorCantidad decimal(19, 4) NOT NULL
        CONSTRAINT DF_POS_Producto_PrecioPorCantidad DEFAULT(0);
END
GO

UPDATE dbo.POS_Producto
SET PrecioPorCantidadActivo = ISNULL(PrecioPorCantidadActivo, 0),
    CantidadPrecioEspecial = ISNULL(CantidadPrecioEspecial, 0),
    PrecioPorCantidad = ISNULL(PrecioPorCantidad, 0)
WHERE PrecioPorCantidadActivo IS NULL
   OR CantidadPrecioEspecial IS NULL
   OR PrecioPorCantidad IS NULL;
GO

IF OBJECT_ID(N'dbo.POS_DetalleFactura_Insertar', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_DetalleFactura_Insertar AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_DetalleFactura_Insertar]
    @IdEmpresa INT,
    @IdFactura INT,
    @IdProducto INT,
    @Cantidad DECIMAL(18, 2),
    @usuario VARCHAR(50),
    @NombreEquipo VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PrecioUnitario DECIMAL(19, 4);
    DECLARE @PrecioVenta DECIMAL(19, 4);
    DECLARE @PrecioEspecial DECIMAL(19, 4);
    DECLARE @PrecioPorCantidadActivo BIT;
    DECLARE @CantidadPrecioEspecial DECIMAL(18, 2);
    DECLARE @ValorISV SMALLINT;
    DECLARE @CostoProducto DECIMAL(19, 4);
    DECLARE @IdDetalleFacturaExistente INT;
    DECLARE @PrecioLineaExistente DECIMAL(19, 4);
    DECLARE @CantidadExistente DECIMAL(18, 2);
    DECLARE @CantidadTotal DECIMAL(18, 2);

    SELECT @CostoProducto = p.Costo,
           @ValorISV = valosisv.ValorISV,
           @PrecioVenta = p.PrecioVenta,
           @PrecioPorCantidadActivo = ISNULL(p.PrecioPorCantidadActivo, 0),
           @CantidadPrecioEspecial = ISNULL(p.CantidadPrecioEspecial, 0),
           @PrecioEspecial = CASE
                                 WHEN ISNULL(p.PrecioPorCantidadActivo, 0) = 1
                                      AND ISNULL(p.CantidadPrecioEspecial, 0) > 0
                                      AND ISNULL(p.PrecioPorCantidad, 0) > 0 THEN
                                     p.PrecioPorCantidad
                                 ELSE
                                     p.PrecioVenta
                             END
    FROM dbo.POS_Producto p
         INNER JOIN dbo.POS_ValorISV valosisv
            ON valosisv.IdValorISV = p.IdValorISV
    WHERE p.IdProducto = @IdProducto
      AND p.IdEmpresa = @IdEmpresa;

    SELECT TOP 1
           @IdDetalleFacturaExistente = d.IdDetalleFactura,
           @CantidadExistente = d.Cantidad,
           @PrecioLineaExistente = d.PrecioUnitario
    FROM dbo.POS_DetalleFactura d
    WHERE d.IdEmpresa = @IdEmpresa
      AND d.IdFactura = @IdFactura
      AND d.IdProducto = @IdProducto
      AND ISNULL(d.Eliminado, 0) = 0
    ORDER BY d.IdDetalleFactura DESC;

    IF @IdDetalleFacturaExistente IS NOT NULL
    BEGIN
        IF @PrecioLineaExistente <> @PrecioVenta
           AND @PrecioLineaExistente <> @PrecioEspecial
        BEGIN
            SET @IdDetalleFacturaExistente = NULL;
        END
        ELSE
        BEGIN
            SET @CantidadTotal = @CantidadExistente + @Cantidad;
            SET @PrecioUnitario = CASE
                                     WHEN @PrecioPorCantidadActivo = 1
                                          AND @CantidadPrecioEspecial > 0
                                          AND @CantidadTotal >= @CantidadPrecioEspecial THEN
                                         @PrecioEspecial
                                     ELSE
                                         @PrecioVenta
                                 END;

            UPDATE dbo.POS_DetalleFactura
            SET Cantidad = @CantidadTotal,
                PrecioUnitario = @PrecioUnitario,
                SubtotalDetalle = @CantidadTotal * @PrecioUnitario,
                ValorISV = @ValorISV,
                CostoProducto = @CostoProducto,
                FechaHora = GETDATE(),
                Usuario = @usuario,
                NombreEquipo = @NombreEquipo,
                Sincronizado = 0,
                FechaHoraSincronizacion = NULL
            WHERE IdDetalleFactura = @IdDetalleFacturaExistente
              AND IdEmpresa = @IdEmpresa;

            RETURN;
        END
    END

    SET @CantidadTotal = @Cantidad;
    SET @PrecioUnitario = CASE
                             WHEN @PrecioPorCantidadActivo = 1
                                  AND @CantidadPrecioEspecial > 0
                                  AND @CantidadTotal >= @CantidadPrecioEspecial THEN
                                 @PrecioEspecial
                             ELSE
                                 @PrecioVenta
                         END;

    IF @IdDetalleFacturaExistente IS NOT NULL
    BEGIN
        UPDATE dbo.POS_DetalleFactura
        SET Cantidad = @CantidadTotal,
            PrecioUnitario = @PrecioUnitario,
            SubtotalDetalle = @CantidadTotal * @PrecioUnitario,
            ValorISV = @ValorISV,
            CostoProducto = @CostoProducto,
            FechaHora = GETDATE(),
            Usuario = @usuario,
            NombreEquipo = @NombreEquipo,
            Sincronizado = 0,
            FechaHoraSincronizacion = NULL
        WHERE IdDetalleFactura = @IdDetalleFacturaExistente
          AND IdEmpresa = @IdEmpresa;

        RETURN;
    END

    INSERT INTO dbo.POS_DetalleFactura
    (
        IdEmpresa,
        IdFactura,
        IdProducto,
        Cantidad,
        PrecioUnitario,
        ValorISV,
        SubtotalDetalle,
        CostoProducto,
        Eliminado,
        Usuario,
        FechaHora,
        NombreEquipo,
        Sincronizado,
        FechaHoraSincronizacion
    )
    VALUES
    (   @IdEmpresa,
        @IdFactura,
        @IdProducto,
        @Cantidad,
        @PrecioUnitario,
        @ValorISV,
        @Cantidad * @PrecioUnitario,
        @CostoProducto,
        0,
        @usuario,
        GETDATE(),
        @NombreEquipo,
        0,
        NULL);
END
GO
