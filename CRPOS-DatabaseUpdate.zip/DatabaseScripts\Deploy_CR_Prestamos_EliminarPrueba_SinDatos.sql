/*
    CR_Prestamos_EliminarPrueba
    Script portable para ejecutar en bases restauradas o en varias empresas.

    No crea tablas ni inserta datos operativos.
    Solo:
      1. Crea/actualiza el procedimiento dbo.CR_Prestamos_EliminarPrueba.
      2. Actualiza la validacion de autorizaciones para permitir Administrador/Soporte.
      3. Crea la autorizacion 00004 para empresas activas de Caja Rural.
      4. Asigna esa autorizacion a los usuarios que ya tienen la 00002.
*/

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.SG_AutorizacionesUsuarios_ValidarUsuario', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.SG_AutorizacionesUsuarios_ValidarUsuario AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE [dbo].[SG_AutorizacionesUsuarios_ValidarUsuario]
    @IdEmpresa INT,
    @CodigoAutorizacion VARCHAR(200),
    @Usuario VARCHAR(50),
    @Contrasena VARCHAR(50),
    @Justificacion VARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdUsuario INT = 0;
    DECLARE @IdAutorizacion INT = 0;
    DECLARE @Perfil VARCHAR(250) = '';
    DECLARE @Mensaje VARCHAR(MAX) = '';
    DECLARE @Error BIT = 0;

    SELECT TOP 1
           @IdUsuario = u.IdUsuario,
           @Perfil = UPPER(LTRIM(RTRIM(ISNULL(p.Perfil, ''))))
    FROM dbo.SG_Usuarios u
    LEFT JOIN dbo.SG_Perfiles p
        ON p.IdPerfil = u.IdPerfil
    WHERE LTRIM(RTRIM(u.NombreUsuario)) = LTRIM(RTRIM(@Usuario))
      AND dbo.DesencriptarClave(u.Contrasena) = @Contrasena
      AND u.Activo = 1
      AND u.Eliminado = 0
      AND (u.IdEmpresa = @IdEmpresa OR u.IdEmpresa IS NULL);

    SELECT TOP 1
           @IdAutorizacion = sa.IdAutorizacion
    FROM dbo.SG_Autorizaciones sa
    WHERE sa.IdEmpresa = @IdEmpresa
      AND LTRIM(RTRIM(sa.Codigo)) = LTRIM(RTRIM(@CodigoAutorizacion))
      AND sa.Activo = 1;

    IF @IdUsuario <= 0
    BEGIN
        SET @Mensaje = '¡Usuario o Contraseña incorrectos!';
        SET @Error = 1;
    END
    ELSE IF @IdAutorizacion <= 0
    BEGIN
        SET @Mensaje = '¡Autorización no configurada o inactiva!';
        SET @Error = 1;
    END
    ELSE IF @Perfil NOT LIKE '%ADMINISTRADOR%'
         AND @Perfil NOT LIKE '%SOPORTE%'
         AND NOT EXISTS (
             SELECT 1
             FROM dbo.SG_AutorizacionesUsuarios sau
             WHERE sau.IdUsuario = @IdUsuario
               AND sau.IdEmpresa = @IdEmpresa
               AND sau.IdAutorizacion = @IdAutorizacion
               AND sau.Eliminado = 0
         )
    BEGIN
        SET @Mensaje = '¡Usuario no autorizado!';
        SET @Error = 1;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.SG_AutorizacionesLogs
        (
            IdEmpresa,
            IdAutorizacion,
            Usuario,
            FechaHora,
            Justificacion
        )
        VALUES
        (
            @IdEmpresa,
            @IdAutorizacion,
            @Usuario,
            GETDATE(),
            @Justificacion
        );
    END;

    SELECT @Mensaje AS Mensaje,
           @Error AS HayError;
END;
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.CR_Prestamos_EliminarPrueba', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.CR_Prestamos_EliminarPrueba AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.CR_Prestamos_EliminarPrueba
    @IdPrestamo INT,
    @HayError BIT OUTPUT,
    @Mensaje VARCHAR(200) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SET @HayError = 0;
    SET @Mensaje = '';

    BEGIN TRY
        IF @IdPrestamo IS NULL OR @IdPrestamo <= 0
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'Debe seleccionar un prestamo valido.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF NOT EXISTS (SELECT 1 FROM dbo.CR_Prestamos WHERE IdPrestamo = @IdPrestamo)
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se encontro el prestamo seleccionado.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (SELECT 1 FROM dbo.CR_Prestamos WHERE IdPrestamo = @IdPrestamo AND Eliminado = 1)
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'El prestamo seleccionado ya esta eliminado.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM dbo.CR_Prestamos
            WHERE IdPrestamo = @IdPrestamo
              AND (PosteadoPrestamo = 1 OR IdAsiento <> 0)
        )
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se puede eliminar un prestamo posteado contablemente.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM dbo.CR_MovimientosPrestamos
            WHERE IdPrestamo = @IdPrestamo
              AND Eliminado = 0
        )
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se puede eliminar un prestamo con movimientos registrados.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        BEGIN TRANSACTION;

        UPDATE im
        SET Eliminado = 1,
            Sincronizado = 0
        FROM dbo.CR_PrestamosDetalle_InteresesMora im
        INNER JOIN dbo.CR_PrestamosDetalle pd
            ON pd.IdPrestamoDetalle = im.IdPrestamoDetalle
        WHERE pd.IdPrestamo = @IdPrestamo
          AND im.Eliminado = 0;

        UPDATE dbo.CR_PrestamosDetalle
        SET Eliminado = 1,
            Sincronizado = 0
        WHERE IdPrestamo = @IdPrestamo
          AND Eliminado = 0;

        UPDATE dbo.CR_Prestamos
        SET Eliminado = 1,
            Sincronizado = 0
        WHERE IdPrestamo = @IdPrestamo
          AND Eliminado = 0;

        COMMIT TRANSACTION;

        SET @HayError = 0;
        SET @Mensaje = 'El prestamo fue eliminado correctamente.';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @HayError = 1;
        SET @Mensaje = LEFT(ERROR_MESSAGE(), 200);
    END CATCH;

    SELECT @HayError AS HayError, @Mensaje AS Mensaje;
END;
GO

DECLARE @AutorizacionesNuevas TABLE (IdAutorizacion INT, IdEmpresa INT);

;WITH EmpresasObjetivo AS
(
    SELECT e.IdEmpresa
    FROM dbo.AD_Empresas e
    WHERE e.Activo = 1
      AND e.Eliminado = 0
      AND e.AplicaCR = 1

    UNION

    SELECT el.IdEmpresa
    FROM dbo.AD_EmpresaLocal el
    WHERE el.Activo = 1
      AND el.AplicaCR = 1
)
INSERT INTO dbo.SG_Autorizaciones
(
    IdEmpresa,
    Codigo,
    Nombre,
    CajaRural,
    PuntoVenta,
    Activo,
    Usuario,
    FechaHora,
    NombreEquipo,
    Sincronizado,
    FechaHoraSincronizado
)
OUTPUT inserted.IdAutorizacion, inserted.IdEmpresa
INTO @AutorizacionesNuevas (IdAutorizacion, IdEmpresa)
SELECT
    e.IdEmpresa,
    '00004',
    'ELIMINAR PRESTAMO DE PRUEBA',
    1,
    0,
    1,
    'SA',
    GETDATE(),
    HOST_NAME(),
    0,
    NULL
FROM EmpresasObjetivo e
WHERE e.IdEmpresa IS NOT NULL
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.SG_Autorizaciones a
      WHERE a.IdEmpresa = e.IdEmpresa
        AND LTRIM(RTRIM(a.Codigo)) = '00004'
  );

;WITH EmpresasObjetivo AS
(
    SELECT e.IdEmpresa
    FROM dbo.AD_Empresas e
    WHERE e.Activo = 1
      AND e.Eliminado = 0
      AND e.AplicaCR = 1

    UNION

    SELECT el.IdEmpresa
    FROM dbo.AD_EmpresaLocal el
    WHERE el.Activo = 1
      AND el.AplicaCR = 1
)
UPDATE a
SET Nombre = 'ELIMINAR PRESTAMO DE PRUEBA',
    CajaRural = 1,
    PuntoVenta = 0,
    Activo = 1,
    Usuario = 'SA',
    FechaHora = GETDATE(),
    NombreEquipo = HOST_NAME(),
    Sincronizado = 0
FROM dbo.SG_Autorizaciones a
INNER JOIN EmpresasObjetivo e
    ON e.IdEmpresa = a.IdEmpresa
WHERE LTRIM(RTRIM(a.Codigo)) = '00004'
  AND (
      a.Activo <> 1
      OR a.CajaRural <> 1
      OR a.PuntoVenta <> 0
      OR LTRIM(RTRIM(ISNULL(a.Nombre, ''))) <> 'ELIMINAR PRESTAMO DE PRUEBA'
  );

INSERT INTO dbo.SG_AutorizacionesUsuarios
(
    IdEmpresa,
    IdAutorizacion,
    IdUsuario,
    Eliminado,
    Usuario,
    FechaHora,
    NombreEquipo,
    Sincronizado,
    FechaHoraSincronizado
)
SELECT
    aDestino.IdEmpresa,
    aDestino.IdAutorizacion,
    au.IdUsuario,
    0,
    'SA',
    GETDATE(),
    HOST_NAME(),
    0,
    NULL
FROM dbo.SG_Autorizaciones aDestino
INNER JOIN dbo.SG_Autorizaciones aBase
    ON aBase.IdEmpresa = aDestino.IdEmpresa
   AND LTRIM(RTRIM(aBase.Codigo)) = '00002'
INNER JOIN dbo.SG_AutorizacionesUsuarios au
    ON au.IdEmpresa = aBase.IdEmpresa
   AND au.IdAutorizacion = aBase.IdAutorizacion
   AND au.Eliminado = 0
WHERE LTRIM(RTRIM(aDestino.Codigo)) = '00004'
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.SG_AutorizacionesUsuarios existente
      WHERE existente.IdEmpresa = aDestino.IdEmpresa
        AND existente.IdAutorizacion = aDestino.IdAutorizacion
        AND existente.IdUsuario = au.IdUsuario
        AND existente.Eliminado = 0
  );
GO

IF OBJECT_ID('dbo.SG_Menus', 'U') IS NOT NULL
   AND OBJECT_ID('dbo.SG_MenusPerfiles', 'U') IS NOT NULL
   AND OBJECT_ID('dbo.SG_Perfiles', 'U') IS NOT NULL
BEGIN
    DECLARE @IdMenuConfiguracion INT;
    DECLARE @IdMenuBaseDatosPagina INT;
    DECLARE @IdMenuBaseDatosGrupo INT;
    DECLARE @IdMenuActualizarBaseDatos INT;

    SELECT @IdMenuConfiguracion = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mConfiguracion';

    IF @IdMenuConfiguracion IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mConfiguracion', 'Configuracion', NULL, 1, 0, 0, 1, 1);

        SET @IdMenuConfiguracion = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1,
            Nivel = 1,
            IdMenuPadre = NULL
        WHERE IdMenu = @IdMenuConfiguracion;
    END;

    SELECT @IdMenuBaseDatosPagina = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mConfiguracionBaseDatos';

    IF @IdMenuBaseDatosPagina IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mConfiguracionBaseDatos', 'Base de datos', @IdMenuConfiguracion, 2, 0, 0, 1, 1);

        SET @IdMenuBaseDatosPagina = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Base de datos',
            IdMenuPadre = @IdMenuConfiguracion,
            Nivel = 2,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuBaseDatosPagina;
    END;

    SELECT @IdMenuBaseDatosGrupo = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mBaseDatosEmpresa';

    IF @IdMenuBaseDatosGrupo IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mBaseDatosEmpresa', 'Base de datos', @IdMenuBaseDatosPagina, 3, 0, 0, 1, 1);

        SET @IdMenuBaseDatosGrupo = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Base de datos',
            IdMenuPadre = @IdMenuBaseDatosPagina,
            Nivel = 3,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuBaseDatosGrupo;
    END;

    SELECT @IdMenuActualizarBaseDatos = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mActualizarBaseDatos';

    IF @IdMenuActualizarBaseDatos IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mActualizarBaseDatos', 'Actualizar base de datos', @IdMenuBaseDatosGrupo, 4, 0, 0, 1, 1);

        SET @IdMenuActualizarBaseDatos = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Actualizar base de datos',
            IdMenuPadre = @IdMenuBaseDatosGrupo,
            Nivel = 4,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuActualizarBaseDatos;
    END;

    INSERT INTO dbo.SG_MenusPerfiles(IdMenu, IdPerfil, IdEmpresa)
    SELECT menu.IdMenu,
           p.IdPerfil,
           p.IdEmpresa
    FROM dbo.SG_Perfiles p
    CROSS APPLY
    (
        SELECT @IdMenuConfiguracion AS IdMenu
        UNION ALL SELECT @IdMenuBaseDatosPagina
        UNION ALL SELECT @IdMenuBaseDatosGrupo
        UNION ALL SELECT @IdMenuActualizarBaseDatos
    ) menu
    WHERE p.Activo = 1
      AND p.Eliminado = 0
      AND (
          UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%ADMINISTRADOR%'
          OR UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%SOPORTE%'
      )
      AND NOT EXISTS (
          SELECT 1
          FROM dbo.SG_MenusPerfiles mp
          WHERE mp.IdMenu = menu.IdMenu
            AND mp.IdPerfil = p.IdPerfil
            AND (
                (mp.IdEmpresa IS NULL AND p.IdEmpresa IS NULL)
                OR mp.IdEmpresa = p.IdEmpresa
            )
      );

    DELETE mp
    FROM dbo.SG_MenusPerfiles mp
    INNER JOIN dbo.SG_Perfiles p
        ON p.IdPerfil = mp.IdPerfil
    WHERE mp.IdMenu IN (
          @IdMenuConfiguracion,
          @IdMenuBaseDatosPagina,
          @IdMenuBaseDatosGrupo,
          @IdMenuActualizarBaseDatos
      )
      AND mp.IdEmpresa IS NULL
      AND p.IdEmpresa IS NOT NULL
      AND p.Activo = 1
      AND p.Eliminado = 0
      AND (
          UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%ADMINISTRADOR%'
          OR UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%SOPORTE%'
      )
      AND EXISTS (
          SELECT 1
          FROM dbo.SG_MenusPerfiles mpEmpresa
          WHERE mpEmpresa.IdMenu = mp.IdMenu
            AND mpEmpresa.IdPerfil = mp.IdPerfil
            AND mpEmpresa.IdEmpresa = p.IdEmpresa
      );
END;
GO

SELECT
    a.IdEmpresa,
    a.Codigo,
    a.Nombre,
    a.Activo,
    COUNT(au.IdAutorizacionUsuario) AS UsuariosAsignados
FROM dbo.SG_Autorizaciones a
LEFT JOIN dbo.SG_AutorizacionesUsuarios au
    ON au.IdEmpresa = a.IdEmpresa
   AND au.IdAutorizacion = a.IdAutorizacion
   AND au.Eliminado = 0
WHERE LTRIM(RTRIM(a.Codigo)) = '00004'
GROUP BY a.IdEmpresa, a.Codigo, a.Nombre, a.Activo
ORDER BY a.IdEmpresa;
GO

ALTER PROCEDURE [dbo].[SG_MenusPerfiles_SelectEmpresa]
    @IdPerfil INT,
    @IdEmpresa INT
AS
BEGIN
    DECLARE @CajaRural BIT,
            @PuntoVenta BIT

    SELECT  @CajaRural = ae.AplicaCR,
            @PuntoVenta = ae.AplicaPOS
    FROM    dbo.AD_EmpresaLocal ae
    WHERE   ae.IdEmpresa = @IdEmpresa

    SELECT DISTINCT
           sm.IdMenu,
           sm.NombreLogico,
           sm.NombreHeader,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END AS Nivel,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos'
                THEN (SELECT TOP 1 IdMenu FROM dbo.SG_Menus WHERE NombreLogico = 'mConfiguracionBaseDatos')
                ELSE sm.IdMenuPadre
           END AS IdMenuPadre,
           CAST((CASE WHEN smp.IdMenu IS NULL THEN 0 ELSE 1 END) AS BIT) Seleccionado
    FROM    dbo.SG_Menus sm
    LEFT JOIN dbo.SG_MenusPerfiles smp
           ON sm.IdMenu = smp.IdMenu
          AND smp.IdPerfil = @IdPerfil
          AND smp.IdEmpresa = @IdEmpresa
    WHERE   EXISTS(SELECT 1 FROM dbo.SG_Perfiles sp WHERE sp.IdPerfil = @IdPerfil AND sp.IdEmpresa = @IdEmpresa)
        AND sm.Empresa = 1
        AND sm.NombreLogico <> 'mBaseDatosEmpresa'
        AND (
            (sm.CajaRural = 0 AND sm.PuntoVenta = 0)
            OR (sm.CajaRural = 1 AND sm.PuntoVenta = 0 AND @CajaRural = 1)
            OR (sm.CajaRural = 0 AND sm.PuntoVenta = 1 AND @PuntoVenta = 1)
        )
    ORDER BY CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END,
             sm.NombreHeader;
END;
GO

ALTER PROCEDURE [dbo].[SG_MenusPerfiles_SelectAdministracion]
    @IdPerfil INT
AS
BEGIN
    SELECT DISTINCT
           sm.IdMenu,
           sm.NombreLogico,
           sm.NombreHeader,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END AS Nivel,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos'
                THEN (SELECT TOP 1 IdMenu FROM dbo.SG_Menus WHERE NombreLogico = 'mConfiguracionBaseDatos')
                ELSE sm.IdMenuPadre
           END AS IdMenuPadre,
           CAST((CASE WHEN smp.IdMenu IS NULL THEN 0 ELSE 1 END) AS BIT) Seleccionado
    FROM   dbo.SG_Menus sm
    LEFT JOIN dbo.SG_MenusPerfiles smp
           ON sm.IdMenu = smp.IdMenu
          AND smp.IdPerfil = @IdPerfil
          AND smp.IdEmpresa IS NULL
    WHERE  EXISTS(SELECT 1 FROM dbo.SG_Perfiles sp WHERE sp.IdPerfil = @IdPerfil AND sp.IdEmpresa IS NULL)
      AND  sm.Administracion = 1
      AND  sm.NombreLogico <> 'mBaseDatosEmpresa'
    ORDER BY CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END,
             sm.NombreHeader;
END;
GO

/*
    CR_EstadosFinancieros - Balance General
    1. Corrige el procedimiento de reporte para validar meses numericamente.
    2. Crea/actualiza el procedimiento que asegura la plantilla de Balance General
       desde CR_CuentasContables.
    3. Ejecuta la configuracion para empresas activas de Caja Rural.
*/

IF OBJECT_ID(N'dbo.CR_AsientosMayorizacion_ReporteEstadoFinanciero', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.CR_AsientosMayorizacion_ReporteEstadoFinanciero AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero]
    @IdEmpresa int = 1,
    @Anio int = 2025,
    @Mes varchar(100) = '5,6,7',
    @IdEstadoFinanciero int = 1
AS
BEGIN
    SET NOCOUNT ON;
    SET LANGUAGE Spanish;

    DECLARE @Meses TABLE(
        Mes int NOT NULL PRIMARY KEY
    );

    INSERT INTO @Meses(Mes)
    SELECT DISTINCT TRY_CONVERT(int, Value)
    FROM [dbo].[SplitString](@Mes, ',')
    WHERE TRY_CONVERT(int, Value) BETWEEN 1 AND 12;

    IF NOT EXISTS(SELECT 1 FROM @Meses)
    BEGIN
        RAISERROR('Debe seleccionar al menos un mes valido para generar el estado financiero.', 16, 1);
        RETURN;
    END;

    DECLARE @UltimoMes int,
            @Sql varchar(MAX),
            @Fecha date,
            @Dia int,
            @MesLetra varchar(50),
            @Var_Meses varchar(MAX);

    SELECT @UltimoMes = MAX(Mes)
    FROM @Meses;

    SET @Fecha = DATEFROMPARTS(@Anio, @UltimoMes, 20);
    SET @Dia = DATEPART(DAY, EOMONTH(@Fecha));
    SET @MesLetra = DATENAME(MONTH, @Fecha);

    SELECT @Var_Meses = STUFF((
        SELECT ',' + CONVERT(varchar(2), Mes)
        FROM @Meses
        ORDER BY Mes
        FOR XML PATH(''), TYPE
    ).value('.', 'varchar(max)'), 1, 1, '');

    SET @Sql = '
        SELECT C.Titulo,
               CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END Acumulado,
               B.ParametroLinea,
               B.Negrita,
               B.Tabulacion,
               B.Columna,
               B.Fuente,
               B.Size,
               REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion NombreCuenta,
               B.Orden,
               ''' + CONVERT(varchar(10), @Anio) + ''' Anio,
               ''' + CONVERT(varchar(10), @UltimoMes) + ''' Mes,
               SUM(D.SaldoAnterior) SaldoAnterior,
               CASE WHEN B.ParametroLinea = 1 THEN NULL ELSE SUM(ISNULL(CASE WHEN C.Tipo = ''Acumulado'' THEN CASE WHEN A.Operacion = 2 THEN D.Saldo * -1 ELSE D.Saldo END ELSE CASE WHEN A.Operacion = 2 THEN D.SaldoActual * -1 ELSE D.SaldoActual END END,0)) END Saldo,
               B.Subtitulo,
               ''' + CONVERT(varchar(10), @Dia) + ''' DiaFinalMes,
               ''' + CONVERT(varchar(10), @MesLetra) + ''' MesLetra,
               E.NombreCR
        FROM CR_EstadosFinancierosDetalle B
             LEFT JOIN CR_EstadosFinancierosDetalleCuentas A ON B.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle AND A.Eliminado = 0
             LEFT JOIN CR_EstadosFinancieros C ON C.IdEstadoFinanciero = B.IdEstadoFinanciero AND C.IdEmpresa = B.IdEmpresa AND C.Eliminado = 0
             LEFT JOIN CR_AsientosMayorizacion D ON D.IdCuentaContable = A.IdCuentaContable AND D.IdEmpresa = A.IdEmpresa AND D.Anio = ' + CONVERT(varchar(10), @Anio) + ' AND D.Mes IN (' + @Var_Meses + ') AND D.Eliminado = 0
             LEFT JOIN AD_EmpresaLocal E ON E.IdEmpresa = B.IdEmpresa
        WHERE B.Eliminado = 0
              AND B.IdEmpresa = ' + CONVERT(varchar(10), @IdEmpresa) + '
              AND C.IdEstadoFinanciero = ' + CONVERT(varchar(10), @IdEstadoFinanciero) + '
        GROUP BY C.Titulo,
               CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END,
               B.ParametroLinea,
               B.Negrita,
               B.Tabulacion,
               B.Columna,
               B.Fuente,
               B.Size,
               REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion,
               B.Orden,
               B.Subtitulo,
               E.NombreCR
        ORDER BY B.Orden';

    EXEC(@Sql);
END
GO

IF OBJECT_ID(N'dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[CR_EstadosFinancieros_AsegurarBalanceGeneral]
    @IdEmpresa int,
    @Usuario varchar(50) = 'SISTEMA',
    @NombreEquipo varchar(200) = 'SCRIPT',
    @CrearEstadoFinanciero bit = 1
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRY
    IF @IdEmpresa IS NULL OR @IdEmpresa <= 0
    BEGIN
        RAISERROR('Debe indicar una empresa valida.', 16, 1);
        RETURN;
    END;

    SET @Usuario = ISNULL(NULLIF(LTRIM(RTRIM(@Usuario)), ''), 'SISTEMA');
    SET @NombreEquipo = ISNULL(NULLIF(LTRIM(RTRIM(@NombreEquipo)), ''), 'SCRIPT');

    DECLARE @FechaHora datetime = GETDATE(),
            @IdEstadoFinanciero int;

    BEGIN TRANSACTION;

    SELECT TOP (1) @IdEstadoFinanciero = E.IdEstadoFinanciero
    FROM dbo.CR_EstadosFinancieros E
    WHERE E.IdEmpresa = @IdEmpresa
          AND E.Eliminado = 0
          AND (
              UPPER(ISNULL(E.Codigo, '')) IN ('BG', 'BAL', 'BALGEN')
              OR UPPER(ISNULL(E.Nombre, '')) LIKE '%BALANCE%'
              OR UPPER(ISNULL(E.Titulo, '')) LIKE '%BALANCE%'
          )
    ORDER BY CASE
                 WHEN UPPER(ISNULL(E.Nombre, '')) = 'BALANCE GENERAL' THEN 0
                 WHEN UPPER(ISNULL(E.Titulo, '')) = 'BALANCE GENERAL' THEN 1
                 ELSE 2
             END,
             E.IdEstadoFinanciero;

    IF @IdEstadoFinanciero IS NULL AND @CrearEstadoFinanciero = 1
    BEGIN
        INSERT INTO dbo.CR_EstadosFinancieros
            (IdEmpresa, Codigo, Nombre, Titulo, Subtitulo, Tipo, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
        VALUES
            (@IdEmpresa, 'BG', 'Balance General', 'Balance General', '', 'Acumulado', 0, @Usuario, @FechaHora, @NombreEquipo, 0, NULL);

        SET @IdEstadoFinanciero = SCOPE_IDENTITY();
    END;

    IF @IdEstadoFinanciero IS NULL
    BEGIN
        RAISERROR('No se encontro un estado financiero de Balance General para la empresa indicada.', 16, 1);
        RETURN;
    END;

    UPDATE dbo.CR_EstadosFinancieros
       SET Tipo = 'Acumulado',
           Eliminado = 0,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    WHERE IdEstadoFinanciero = @IdEstadoFinanciero
          AND IdEmpresa = @IdEmpresa
          AND (Tipo <> 'Acumulado' OR Eliminado <> 0);

    DECLARE @Cuentas TABLE(
        Categoria varchar(20) NOT NULL PRIMARY KEY,
        IdCuentaContable int NOT NULL,
        CuentaContable varchar(100) NOT NULL,
        Nombre varchar(500) NOT NULL
    );

    INSERT INTO @Cuentas(Categoria, IdCuentaContable, CuentaContable, Nombre)
    SELECT TOP (1) 'ACTIVO', C.IdCuentaContable, C.CuentaContable, ISNULL(C.Nombre, '')
    FROM dbo.CR_CuentasContables C
    WHERE C.IdEmpresa = @IdEmpresa
          AND C.Eliminado = 0
          AND (C.CuentaContable LIKE '1%' OR UPPER(ISNULL(C.Nombre, '')) LIKE '%ACTIVO%')
    ORDER BY CASE
                 WHEN C.IdCuentaPadre IS NULL OR C.IdCuentaPadre = 0
                      OR NOT EXISTS (
                          SELECT 1
                          FROM dbo.CR_CuentasContables P
                          WHERE P.IdEmpresa = C.IdEmpresa
                                AND P.IdCuentaContable = C.IdCuentaPadre
                                AND P.Eliminado = 0
                      ) THEN 0
                 ELSE 1
             END,
             CASE WHEN C.Operable = 0 THEN 0 ELSE 1 END,
             CASE WHEN C.CuentaContable LIKE '1%' THEN 0 ELSE 1 END,
             LEN(C.CuentaContable),
             C.CuentaContable;

    INSERT INTO @Cuentas(Categoria, IdCuentaContable, CuentaContable, Nombre)
    SELECT TOP (1) 'PASIVO', C.IdCuentaContable, C.CuentaContable, ISNULL(C.Nombre, '')
    FROM dbo.CR_CuentasContables C
    WHERE C.IdEmpresa = @IdEmpresa
          AND C.Eliminado = 0
          AND (C.CuentaContable LIKE '2%' OR UPPER(ISNULL(C.Nombre, '')) LIKE '%PASIVO%')
    ORDER BY CASE
                 WHEN C.IdCuentaPadre IS NULL OR C.IdCuentaPadre = 0
                      OR NOT EXISTS (
                          SELECT 1
                          FROM dbo.CR_CuentasContables P
                          WHERE P.IdEmpresa = C.IdEmpresa
                                AND P.IdCuentaContable = C.IdCuentaPadre
                                AND P.Eliminado = 0
                      ) THEN 0
                 ELSE 1
             END,
             CASE WHEN C.Operable = 0 THEN 0 ELSE 1 END,
             CASE WHEN C.CuentaContable LIKE '2%' THEN 0 ELSE 1 END,
             LEN(C.CuentaContable),
             C.CuentaContable;

    INSERT INTO @Cuentas(Categoria, IdCuentaContable, CuentaContable, Nombre)
    SELECT TOP (1) 'PATRIMONIO', C.IdCuentaContable, C.CuentaContable, ISNULL(C.Nombre, '')
    FROM dbo.CR_CuentasContables C
    WHERE C.IdEmpresa = @IdEmpresa
          AND C.Eliminado = 0
          AND (
              C.CuentaContable LIKE '3%'
              OR UPPER(ISNULL(C.Nombre, '')) LIKE '%PATRIMONIO%'
              OR UPPER(ISNULL(C.Nombre, '')) LIKE '%CAPITAL%'
          )
    ORDER BY CASE
                 WHEN C.IdCuentaPadre IS NULL OR C.IdCuentaPadre = 0
                      OR NOT EXISTS (
                          SELECT 1
                          FROM dbo.CR_CuentasContables P
                          WHERE P.IdEmpresa = C.IdEmpresa
                                AND P.IdCuentaContable = C.IdCuentaPadre
                                AND P.Eliminado = 0
                      ) THEN 0
                 ELSE 1
             END,
             CASE WHEN C.Operable = 0 THEN 0 ELSE 1 END,
             CASE WHEN C.CuentaContable LIKE '3%' THEN 0 ELSE 1 END,
             LEN(C.CuentaContable),
             C.CuentaContable;

    DECLARE @Faltantes varchar(200) = '';

    IF NOT EXISTS (SELECT 1 FROM @Cuentas WHERE Categoria = 'ACTIVO')
        SET @Faltantes = @Faltantes + ' ACTIVO';

    IF NOT EXISTS (SELECT 1 FROM @Cuentas WHERE Categoria = 'PASIVO')
        SET @Faltantes = @Faltantes + ' PASIVO';

    IF NOT EXISTS (SELECT 1 FROM @Cuentas WHERE Categoria = 'PATRIMONIO')
        SET @Faltantes = @Faltantes + ' PATRIMONIO/CAPITAL';

    IF @Faltantes <> ''
    BEGIN
        RAISERROR('No se encontraron cuentas raiz para:%s. Revise CR_CuentasContables.', 16, 1, @Faltantes);
        RETURN;
    END;

    DECLARE @Lineas TABLE(
        Clave varchar(50) NOT NULL PRIMARY KEY,
        Orden int NOT NULL,
        ParametroLinea int NOT NULL,
        Descripcion varchar(200) NOT NULL,
        Subtitulo bit NOT NULL,
        Negrita bit NOT NULL,
        Tabulacion int NOT NULL,
        Columna int NOT NULL,
        Fuente varchar(50) NOT NULL,
        Size int NOT NULL
    );

    INSERT INTO @Lineas(Clave, Orden, ParametroLinea, Descripcion, Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size)
    VALUES
        ('ACTIVO_TITULO', 10, 1, 'ACTIVO', 1, 1, 0, 1, 'Cambria', 12),
        ('TOTAL_ACTIVO', 20, 2, 'TOTAL ACTIVO', 0, 1, 0, 3, 'Cambria', 12),
        ('PASIVO_PATRIMONIO_TITULO', 30, 1, 'PASIVO Y PATRIMONIO', 1, 1, 0, 1, 'Cambria', 12),
        ('TOTAL_PASIVO', 40, 2, 'TOTAL PASIVO', 0, 1, 0, 3, 'Cambria', 12),
        ('TOTAL_PATRIMONIO', 50, 2, 'TOTAL PATRIMONIO', 0, 1, 0, 3, 'Cambria', 12),
        ('TOTAL_PASIVO_PATRIMONIO', 60, 2, 'TOTAL PASIVO + PATRIMONIO', 0, 1, 0, 3, 'Cambria', 12);

    UPDATE D
       SET Orden = L.Orden,
           ParametroLinea = L.ParametroLinea,
           Subtitulo = L.Subtitulo,
           Negrita = L.Negrita,
           Tabulacion = L.Tabulacion,
           Columna = L.Columna,
           Fuente = L.Fuente,
           Size = L.Size,
           Eliminado = 0,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalle D
         INNER JOIN @Lineas L ON UPPER(LTRIM(RTRIM(D.Descripcion))) = UPPER(LTRIM(RTRIM(L.Descripcion)))
    WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
          AND D.IdEmpresa = @IdEmpresa;

    INSERT INTO dbo.CR_EstadosFinancierosDetalle
        (IdEstadoFinanciero, IdEmpresa, Orden, ParametroLinea, Descripcion, Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
    SELECT @IdEstadoFinanciero, @IdEmpresa, L.Orden, L.ParametroLinea, L.Descripcion, L.Subtitulo, L.Negrita, L.Tabulacion, L.Columna, L.Fuente, L.Size, 0, @Usuario, @FechaHora, @NombreEquipo, 0, NULL
    FROM @Lineas L
    WHERE NOT EXISTS (
        SELECT 1
        FROM dbo.CR_EstadosFinancierosDetalle D
        WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
              AND D.IdEmpresa = @IdEmpresa
              AND UPPER(LTRIM(RTRIM(D.Descripcion))) = UPPER(LTRIM(RTRIM(L.Descripcion)))
    );

    DECLARE @Detalle TABLE(
        Clave varchar(50) NOT NULL PRIMARY KEY,
        IdEstadoFinancieroDetalle int NOT NULL
    );

    INSERT INTO @Detalle(Clave, IdEstadoFinancieroDetalle)
    SELECT L.Clave, MIN(D.IdEstadoFinancieroDetalle)
    FROM @Lineas L
         INNER JOIN dbo.CR_EstadosFinancierosDetalle D ON UPPER(LTRIM(RTRIM(D.Descripcion))) = UPPER(LTRIM(RTRIM(L.Descripcion)))
    WHERE D.IdEstadoFinanciero = @IdEstadoFinanciero
          AND D.IdEmpresa = @IdEmpresa
          AND D.Eliminado = 0
    GROUP BY L.Clave;

    DECLARE @Mapeo TABLE(
        Clave varchar(50) NOT NULL,
        Categoria varchar(20) NOT NULL,
        Operacion int NOT NULL,
        Orden int NOT NULL
    );

    INSERT INTO @Mapeo(Clave, Categoria, Operacion, Orden)
    VALUES
        ('TOTAL_ACTIVO', 'ACTIVO', 1, 1),
        ('TOTAL_PASIVO', 'PASIVO', 1, 1),
        ('TOTAL_PATRIMONIO', 'PATRIMONIO', 1, 1),
        ('TOTAL_PASIVO_PATRIMONIO', 'PASIVO', 1, 1),
        ('TOTAL_PASIVO_PATRIMONIO', 'PATRIMONIO', 1, 2);

    UPDATE DC
       SET CuentaContable = C.CuentaContable,
           NombreCuenta = C.Nombre,
           Operacion = M.Operacion,
           Orden = M.Orden,
           Eliminado = 0,
           Usuario = @Usuario,
           FechaHora = @FechaHora,
           NombreEquipo = @NombreEquipo,
           Sincronizado = 0,
           FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalleCuentas DC
         INNER JOIN @Detalle D ON D.IdEstadoFinancieroDetalle = DC.IdEstadoFinancieroDetalle
         INNER JOIN @Mapeo M ON M.Clave = D.Clave
         INNER JOIN @Cuentas C ON C.Categoria = M.Categoria
    WHERE DC.IdEmpresa = @IdEmpresa
          AND DC.IdCuentaContable = C.IdCuentaContable;

    INSERT INTO dbo.CR_EstadosFinancierosDetalleCuentas
        (IdEstadoFinancieroDetalle, IdEmpresa, IdCuentaContable, CuentaContable, NombreCuenta, Operacion, Orden, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
    SELECT D.IdEstadoFinancieroDetalle, @IdEmpresa, C.IdCuentaContable, C.CuentaContable, C.Nombre, M.Operacion, M.Orden, 0, @Usuario, @FechaHora, @NombreEquipo, 0, NULL
    FROM @Mapeo M
         INNER JOIN @Detalle D ON D.Clave = M.Clave
         INNER JOIN @Cuentas C ON C.Categoria = M.Categoria
    WHERE NOT EXISTS (
        SELECT 1
        FROM dbo.CR_EstadosFinancierosDetalleCuentas DC
        WHERE DC.IdEstadoFinancieroDetalle = D.IdEstadoFinancieroDetalle
              AND DC.IdEmpresa = @IdEmpresa
              AND DC.IdCuentaContable = C.IdCuentaContable
    );

    COMMIT TRANSACTION;

    SELECT @IdEstadoFinanciero AS IdEstadoFinanciero,
           C.Categoria,
           C.IdCuentaContable,
           C.CuentaContable,
           C.Nombre
    FROM @Cuentas C
    ORDER BY CASE C.Categoria
                 WHEN 'ACTIVO' THEN 1
                 WHEN 'PASIVO' THEN 2
                 ELSE 3
             END;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage nvarchar(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN;
    END CATCH;
END
GO

DECLARE @EmpresasBalanceGeneral TABLE(
    IdEmpresa int NOT NULL PRIMARY KEY
);

INSERT INTO @EmpresasBalanceGeneral(IdEmpresa)
SELECT e.IdEmpresa
FROM dbo.AD_Empresas e
WHERE e.Activo = 1
  AND e.Eliminado = 0
  AND e.AplicaCR = 1
  AND e.IdEmpresa IS NOT NULL

UNION

SELECT el.IdEmpresa
FROM dbo.AD_EmpresaLocal el
WHERE el.Activo = 1
  AND el.AplicaCR = 1
  AND el.IdEmpresa IS NOT NULL;

DECLARE @IdEmpresaBalanceGeneral int;

DECLARE EmpresasBalanceGeneralCursor CURSOR LOCAL FAST_FORWARD FOR
SELECT IdEmpresa
FROM @EmpresasBalanceGeneral
ORDER BY IdEmpresa;

OPEN EmpresasBalanceGeneralCursor;
FETCH NEXT FROM EmpresasBalanceGeneralCursor INTO @IdEmpresaBalanceGeneral;

WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral
        @IdEmpresa = @IdEmpresaBalanceGeneral,
        @Usuario = 'SA',
        @NombreEquipo = 'ACTUALIZACION';

    FETCH NEXT FROM EmpresasBalanceGeneralCursor INTO @IdEmpresaBalanceGeneral;
END;

CLOSE EmpresasBalanceGeneralCursor;
DEALLOCATE EmpresasBalanceGeneralCursor;
GO

/*
    POS_AsientosVisor - filtro Activos / Anulados / Todos
    Corrige @Anulado para que:
    - 0 muestre solo asientos no anulados
    - 1 muestre solo asientos anulados
    - NULL muestre ambos
*/
IF OBJECT_ID(N'dbo.POS_AsientosVisor', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_AsientosVisor AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_AsientosVisor]
    @IdEmpresa int,
    @FechaDesde date,
    @FechaHasta date,
    @IdTipo int,
    @Busqueda varchar(200),
    @Anulado bit = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @Busqueda = ISNULL(@Busqueda, '');

    SELECT A.IdAsiento,
           A.IdAsiento NoAsiento,
           A.FechaAsiento,
           ISNULL(A.NumeroReferencia, '') NumeroReferencia,
           ISNULL(B.TipoAsiento, 'ASIENTO MANUAL') TipoAsiento,
           ISNULL(A.Sinopsis, '') Sinopsis,
           ISNULL(A.Anulado, 0) Anulado,
           A.FechaHoraMayorizacion,
           ISNULL(A.Mayorizado, 0) Mayorizado,
           ISNULL(A.IdTipoAsiento, -1) IdTipoAsiento
    FROM dbo.CR_Asientos A
         LEFT JOIN dbo.CR_TipoAsiento B ON A.IdTipoAsiento = B.IdTipoAsiento
    WHERE ISNULL(A.Eliminado, 0) = 0
      AND A.IdEmpresa = @IdEmpresa
      AND A.FechaAsiento BETWEEN @FechaDesde AND @FechaHasta
      AND ISNULL(A.IdTipoAsiento, -1) = CASE
                                            WHEN ISNULL(@IdTipo, 0) = 0 THEN ISNULL(A.IdTipoAsiento, -1)
                                            WHEN @IdTipo > 0 THEN @IdTipo
                                            ELSE -1
                                        END
      AND (@Anulado IS NULL OR ISNULL(A.Anulado, 0) = @Anulado)
      AND ISNULL(A.NumeroReferencia, '') LIKE '%' + @Busqueda + '%';
END
GO
