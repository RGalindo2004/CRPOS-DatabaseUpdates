/*
    CR_Prestamos_EliminarPrueba
    Script portable para ejecutar en bases restauradas o en varias empresas.

    No crea tablas ni inserta datos operativos.
    Solo:
      1. Crea/actualiza el procedimiento dbo.CR_Prestamos_EliminarPrueba.
      2. Actualiza la validacion de autorizaciones para permitir Administrador/Soporte.
      3. Crea la autorizacion 00004 para empresas activas de Caja Rural.
      4. Asigna esa autorizacion a los usuarios que ya tienen la 00002.
*/

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.SG_AutorizacionesUsuarios_ValidarUsuario', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.SG_AutorizacionesUsuarios_ValidarUsuario AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE [dbo].[SG_AutorizacionesUsuarios_ValidarUsuario]
    @IdEmpresa INT,
    @CodigoAutorizacion VARCHAR(200),
    @Usuario VARCHAR(50),
    @Contrasena VARCHAR(50),
    @Justificacion VARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdUsuario INT = 0;
    DECLARE @IdAutorizacion INT = 0;
    DECLARE @Perfil VARCHAR(250) = '';
    DECLARE @Mensaje VARCHAR(MAX) = '';
    DECLARE @Error BIT = 0;

    SELECT TOP 1
           @IdUsuario = u.IdUsuario,
           @Perfil = UPPER(LTRIM(RTRIM(ISNULL(p.Perfil, ''))))
    FROM dbo.SG_Usuarios u
    LEFT JOIN dbo.SG_Perfiles p
        ON p.IdPerfil = u.IdPerfil
    WHERE LTRIM(RTRIM(u.NombreUsuario)) = LTRIM(RTRIM(@Usuario))
      AND dbo.DesencriptarClave(u.Contrasena) = @Contrasena
      AND u.Activo = 1
      AND u.Eliminado = 0
      AND (u.IdEmpresa = @IdEmpresa OR u.IdEmpresa IS NULL);

    SELECT TOP 1
           @IdAutorizacion = sa.IdAutorizacion
    FROM dbo.SG_Autorizaciones sa
    WHERE sa.IdEmpresa = @IdEmpresa
      AND LTRIM(RTRIM(sa.Codigo)) = LTRIM(RTRIM(@CodigoAutorizacion))
      AND sa.Activo = 1;

    IF @IdUsuario <= 0
    BEGIN
        SET @Mensaje = '¡Usuario o Contraseña incorrectos!';
        SET @Error = 1;
    END
    ELSE IF @IdAutorizacion <= 0
    BEGIN
        SET @Mensaje = '¡Autorización no configurada o inactiva!';
        SET @Error = 1;
    END
    ELSE IF @Perfil NOT LIKE '%ADMINISTRADOR%'
         AND @Perfil NOT LIKE '%SOPORTE%'
         AND NOT EXISTS (
             SELECT 1
             FROM dbo.SG_AutorizacionesUsuarios sau
             WHERE sau.IdUsuario = @IdUsuario
               AND sau.IdEmpresa = @IdEmpresa
               AND sau.IdAutorizacion = @IdAutorizacion
               AND sau.Eliminado = 0
         )
    BEGIN
        SET @Mensaje = '¡Usuario no autorizado!';
        SET @Error = 1;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.SG_AutorizacionesLogs
        (
            IdEmpresa,
            IdAutorizacion,
            Usuario,
            FechaHora,
            Justificacion
        )
        VALUES
        (
            @IdEmpresa,
            @IdAutorizacion,
            @Usuario,
            GETDATE(),
            @Justificacion
        );
    END;

    SELECT @Mensaje AS Mensaje,
           @Error AS HayError;
END;
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.CR_Prestamos_EliminarPrueba', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.CR_Prestamos_EliminarPrueba AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.CR_Prestamos_EliminarPrueba
    @IdPrestamo INT,
    @HayError BIT OUTPUT,
    @Mensaje VARCHAR(200) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SET @HayError = 0;
    SET @Mensaje = '';

    BEGIN TRY
        IF @IdPrestamo IS NULL OR @IdPrestamo <= 0
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'Debe seleccionar un prestamo valido.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF NOT EXISTS (SELECT 1 FROM dbo.CR_Prestamos WHERE IdPrestamo = @IdPrestamo)
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se encontro el prestamo seleccionado.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (SELECT 1 FROM dbo.CR_Prestamos WHERE IdPrestamo = @IdPrestamo AND Eliminado = 1)
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'El prestamo seleccionado ya esta eliminado.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM dbo.CR_Prestamos
            WHERE IdPrestamo = @IdPrestamo
              AND (PosteadoPrestamo = 1 OR IdAsiento <> 0)
        )
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se puede eliminar un prestamo posteado contablemente.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM dbo.CR_MovimientosPrestamos
            WHERE IdPrestamo = @IdPrestamo
              AND Eliminado = 0
        )
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se puede eliminar un prestamo con movimientos registrados.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        BEGIN TRANSACTION;

        UPDATE im
        SET Eliminado = 1,
            Sincronizado = 0
        FROM dbo.CR_PrestamosDetalle_InteresesMora im
        INNER JOIN dbo.CR_PrestamosDetalle pd
            ON pd.IdPrestamoDetalle = im.IdPrestamoDetalle
        WHERE pd.IdPrestamo = @IdPrestamo
          AND im.Eliminado = 0;

        UPDATE dbo.CR_PrestamosDetalle
        SET Eliminado = 1,
            Sincronizado = 0
        WHERE IdPrestamo = @IdPrestamo
          AND Eliminado = 0;

        UPDATE dbo.CR_Prestamos
        SET Eliminado = 1,
            Sincronizado = 0
        WHERE IdPrestamo = @IdPrestamo
          AND Eliminado = 0;

        COMMIT TRANSACTION;

        SET @HayError = 0;
        SET @Mensaje = 'El prestamo fue eliminado correctamente.';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @HayError = 1;
        SET @Mensaje = LEFT(ERROR_MESSAGE(), 200);
    END CATCH;

    SELECT @HayError AS HayError, @Mensaje AS Mensaje;
END;
GO

DECLARE @AutorizacionesNuevas TABLE (IdAutorizacion INT, IdEmpresa INT);

;WITH EmpresasObjetivo AS
(
    SELECT e.IdEmpresa
    FROM dbo.AD_Empresas e
    WHERE e.Activo = 1
      AND e.Eliminado = 0
      AND e.AplicaCR = 1

    UNION

    SELECT el.IdEmpresa
    FROM dbo.AD_EmpresaLocal el
    WHERE el.Activo = 1
      AND el.AplicaCR = 1
)
INSERT INTO dbo.SG_Autorizaciones
(
    IdEmpresa,
    Codigo,
    Nombre,
    CajaRural,
    PuntoVenta,
    Activo,
    Usuario,
    FechaHora,
    NombreEquipo,
    Sincronizado,
    FechaHoraSincronizado
)
OUTPUT inserted.IdAutorizacion, inserted.IdEmpresa
INTO @AutorizacionesNuevas (IdAutorizacion, IdEmpresa)
SELECT
    e.IdEmpresa,
    '00004',
    'ELIMINAR PRESTAMO DE PRUEBA',
    1,
    0,
    1,
    'SA',
    GETDATE(),
    HOST_NAME(),
    0,
    NULL
FROM EmpresasObjetivo e
WHERE e.IdEmpresa IS NOT NULL
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.SG_Autorizaciones a
      WHERE a.IdEmpresa = e.IdEmpresa
        AND LTRIM(RTRIM(a.Codigo)) = '00004'
  );

;WITH EmpresasObjetivo AS
(
    SELECT e.IdEmpresa
    FROM dbo.AD_Empresas e
    WHERE e.Activo = 1
      AND e.Eliminado = 0
      AND e.AplicaCR = 1

    UNION

    SELECT el.IdEmpresa
    FROM dbo.AD_EmpresaLocal el
    WHERE el.Activo = 1
      AND el.AplicaCR = 1
)
UPDATE a
SET Nombre = 'ELIMINAR PRESTAMO DE PRUEBA',
    CajaRural = 1,
    PuntoVenta = 0,
    Activo = 1,
    Usuario = 'SA',
    FechaHora = GETDATE(),
    NombreEquipo = HOST_NAME(),
    Sincronizado = 0
FROM dbo.SG_Autorizaciones a
INNER JOIN EmpresasObjetivo e
    ON e.IdEmpresa = a.IdEmpresa
WHERE LTRIM(RTRIM(a.Codigo)) = '00004'
  AND (
      a.Activo <> 1
      OR a.CajaRural <> 1
      OR a.PuntoVenta <> 0
      OR LTRIM(RTRIM(ISNULL(a.Nombre, ''))) <> 'ELIMINAR PRESTAMO DE PRUEBA'
  );

INSERT INTO dbo.SG_AutorizacionesUsuarios
(
    IdEmpresa,
    IdAutorizacion,
    IdUsuario,
    Eliminado,
    Usuario,
    FechaHora,
    NombreEquipo,
    Sincronizado,
    FechaHoraSincronizado
)
SELECT
    aDestino.IdEmpresa,
    aDestino.IdAutorizacion,
    au.IdUsuario,
    0,
    'SA',
    GETDATE(),
    HOST_NAME(),
    0,
    NULL
FROM dbo.SG_Autorizaciones aDestino
INNER JOIN dbo.SG_Autorizaciones aBase
    ON aBase.IdEmpresa = aDestino.IdEmpresa
   AND LTRIM(RTRIM(aBase.Codigo)) = '00002'
INNER JOIN dbo.SG_AutorizacionesUsuarios au
    ON au.IdEmpresa = aBase.IdEmpresa
   AND au.IdAutorizacion = aBase.IdAutorizacion
   AND au.Eliminado = 0
WHERE LTRIM(RTRIM(aDestino.Codigo)) = '00004'
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.SG_AutorizacionesUsuarios existente
      WHERE existente.IdEmpresa = aDestino.IdEmpresa
        AND existente.IdAutorizacion = aDestino.IdAutorizacion
        AND existente.IdUsuario = au.IdUsuario
        AND existente.Eliminado = 0
  );
GO

IF OBJECT_ID('dbo.SG_Menus', 'U') IS NOT NULL
   AND OBJECT_ID('dbo.SG_MenusPerfiles', 'U') IS NOT NULL
   AND OBJECT_ID('dbo.SG_Perfiles', 'U') IS NOT NULL
BEGIN
    DECLARE @IdMenuConfiguracion INT;
    DECLARE @IdMenuBaseDatosPagina INT;
    DECLARE @IdMenuBaseDatosGrupo INT;
    DECLARE @IdMenuActualizarBaseDatos INT;

    SELECT @IdMenuConfiguracion = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mConfiguracion';

    IF @IdMenuConfiguracion IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mConfiguracion', 'Configuracion', NULL, 1, 0, 0, 1, 1);

        SET @IdMenuConfiguracion = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1,
            Nivel = 1,
            IdMenuPadre = NULL
        WHERE IdMenu = @IdMenuConfiguracion;
    END;

    SELECT @IdMenuBaseDatosPagina = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mConfiguracionBaseDatos';

    IF @IdMenuBaseDatosPagina IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mConfiguracionBaseDatos', 'Base de datos', @IdMenuConfiguracion, 2, 0, 0, 1, 1);

        SET @IdMenuBaseDatosPagina = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Base de datos',
            IdMenuPadre = @IdMenuConfiguracion,
            Nivel = 2,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuBaseDatosPagina;
    END;

    SELECT @IdMenuBaseDatosGrupo = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mBaseDatosEmpresa';

    IF @IdMenuBaseDatosGrupo IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mBaseDatosEmpresa', 'Base de datos', @IdMenuBaseDatosPagina, 3, 0, 0, 1, 1);

        SET @IdMenuBaseDatosGrupo = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Base de datos',
            IdMenuPadre = @IdMenuBaseDatosPagina,
            Nivel = 3,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuBaseDatosGrupo;
    END;

    SELECT @IdMenuActualizarBaseDatos = IdMenu
    FROM dbo.SG_Menus
    WHERE NombreLogico = 'mActualizarBaseDatos';

    IF @IdMenuActualizarBaseDatos IS NULL
    BEGIN
        INSERT INTO dbo.SG_Menus(NombreLogico, NombreHeader, IdMenuPadre, Nivel, CajaRural, PuntoVenta, Empresa, Administracion)
        VALUES('mActualizarBaseDatos', 'Actualizar base de datos', @IdMenuBaseDatosGrupo, 4, 0, 0, 1, 1);

        SET @IdMenuActualizarBaseDatos = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.SG_Menus
        SET NombreHeader = 'Actualizar base de datos',
            IdMenuPadre = @IdMenuBaseDatosGrupo,
            Nivel = 4,
            CajaRural = 0,
            PuntoVenta = 0,
            Empresa = 1,
            Administracion = 1
        WHERE IdMenu = @IdMenuActualizarBaseDatos;
    END;

    INSERT INTO dbo.SG_MenusPerfiles(IdMenu, IdPerfil, IdEmpresa)
    SELECT menu.IdMenu,
           p.IdPerfil,
           p.IdEmpresa
    FROM dbo.SG_Perfiles p
    CROSS APPLY
    (
        SELECT @IdMenuConfiguracion AS IdMenu
        UNION ALL SELECT @IdMenuBaseDatosPagina
        UNION ALL SELECT @IdMenuBaseDatosGrupo
        UNION ALL SELECT @IdMenuActualizarBaseDatos
    ) menu
    WHERE p.Activo = 1
      AND p.Eliminado = 0
      AND (
          UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%ADMINISTRADOR%'
          OR UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%SOPORTE%'
      )
      AND NOT EXISTS (
          SELECT 1
          FROM dbo.SG_MenusPerfiles mp
          WHERE mp.IdMenu = menu.IdMenu
            AND mp.IdPerfil = p.IdPerfil
            AND (
                (mp.IdEmpresa IS NULL AND p.IdEmpresa IS NULL)
                OR mp.IdEmpresa = p.IdEmpresa
            )
      );

    DELETE mp
    FROM dbo.SG_MenusPerfiles mp
    INNER JOIN dbo.SG_Perfiles p
        ON p.IdPerfil = mp.IdPerfil
    WHERE mp.IdMenu IN (
          @IdMenuConfiguracion,
          @IdMenuBaseDatosPagina,
          @IdMenuBaseDatosGrupo,
          @IdMenuActualizarBaseDatos
      )
      AND mp.IdEmpresa IS NULL
      AND p.IdEmpresa IS NOT NULL
      AND p.Activo = 1
      AND p.Eliminado = 0
      AND (
          UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%ADMINISTRADOR%'
          OR UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%SOPORTE%'
      )
      AND EXISTS (
          SELECT 1
          FROM dbo.SG_MenusPerfiles mpEmpresa
          WHERE mpEmpresa.IdMenu = mp.IdMenu
            AND mpEmpresa.IdPerfil = mp.IdPerfil
            AND mpEmpresa.IdEmpresa = p.IdEmpresa
      );
END;
GO

SELECT
    a.IdEmpresa,
    a.Codigo,
    a.Nombre,
    a.Activo,
    COUNT(au.IdAutorizacionUsuario) AS UsuariosAsignados
FROM dbo.SG_Autorizaciones a
LEFT JOIN dbo.SG_AutorizacionesUsuarios au
    ON au.IdEmpresa = a.IdEmpresa
   AND au.IdAutorizacion = a.IdAutorizacion
   AND au.Eliminado = 0
WHERE LTRIM(RTRIM(a.Codigo)) = '00004'
GROUP BY a.IdEmpresa, a.Codigo, a.Nombre, a.Activo
ORDER BY a.IdEmpresa;
GO

ALTER PROCEDURE [dbo].[SG_MenusPerfiles_SelectEmpresa]
    @IdPerfil INT,
    @IdEmpresa INT
AS
BEGIN
    DECLARE @CajaRural BIT,
            @PuntoVenta BIT

    SELECT  @CajaRural = ae.AplicaCR,
            @PuntoVenta = ae.AplicaPOS
    FROM    dbo.AD_EmpresaLocal ae
    WHERE   ae.IdEmpresa = @IdEmpresa

    SELECT DISTINCT
           sm.IdMenu,
           sm.NombreLogico,
           sm.NombreHeader,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END AS Nivel,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos'
                THEN (SELECT TOP 1 IdMenu FROM dbo.SG_Menus WHERE NombreLogico = 'mConfiguracionBaseDatos')
                ELSE sm.IdMenuPadre
           END AS IdMenuPadre,
           CAST((CASE WHEN smp.IdMenu IS NULL THEN 0 ELSE 1 END) AS BIT) Seleccionado
    FROM    dbo.SG_Menus sm
    LEFT JOIN dbo.SG_MenusPerfiles smp
           ON sm.IdMenu = smp.IdMenu
          AND smp.IdPerfil = @IdPerfil
          AND smp.IdEmpresa = @IdEmpresa
    WHERE   EXISTS(SELECT 1 FROM dbo.SG_Perfiles sp WHERE sp.IdPerfil = @IdPerfil AND sp.IdEmpresa = @IdEmpresa)
        AND sm.Empresa = 1
        AND sm.NombreLogico <> 'mBaseDatosEmpresa'
        AND (
            (sm.CajaRural = 0 AND sm.PuntoVenta = 0)
            OR (sm.CajaRural = 1 AND sm.PuntoVenta = 0 AND @CajaRural = 1)
            OR (sm.CajaRural = 0 AND sm.PuntoVenta = 1 AND @PuntoVenta = 1)
        )
    ORDER BY CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END,
             sm.NombreHeader;
END;
GO

ALTER PROCEDURE [dbo].[SG_MenusPerfiles_SelectAdministracion]
    @IdPerfil INT
AS
BEGIN
    SELECT DISTINCT
           sm.IdMenu,
           sm.NombreLogico,
           sm.NombreHeader,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END AS Nivel,
           CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos'
                THEN (SELECT TOP 1 IdMenu FROM dbo.SG_Menus WHERE NombreLogico = 'mConfiguracionBaseDatos')
                ELSE sm.IdMenuPadre
           END AS IdMenuPadre,
           CAST((CASE WHEN smp.IdMenu IS NULL THEN 0 ELSE 1 END) AS BIT) Seleccionado
    FROM   dbo.SG_Menus sm
    LEFT JOIN dbo.SG_MenusPerfiles smp
           ON sm.IdMenu = smp.IdMenu
          AND smp.IdPerfil = @IdPerfil
          AND smp.IdEmpresa IS NULL
    WHERE  EXISTS(SELECT 1 FROM dbo.SG_Perfiles sp WHERE sp.IdPerfil = @IdPerfil AND sp.IdEmpresa IS NULL)
      AND  sm.Administracion = 1
      AND  sm.NombreLogico <> 'mBaseDatosEmpresa'
    ORDER BY CASE WHEN sm.NombreLogico = 'mActualizarBaseDatos' THEN 3 ELSE sm.Nivel END,
             sm.NombreHeader;
END;
GO

/*
    CR_EstadosFinancieros - Balance General
    1. Restaura el procedimiento de reporte desde la base funcional.
    2. Crea/actualiza el procedimiento que asegura la plantilla de Balance General
       desde CR_CuentasContables.
    3. Ejecuta la configuracion para empresas activas de Caja Rural.
*/

IF OBJECT_ID(N'dbo.CR_AsientosMayorizacion_ReporteEstadoFinanciero', N'P') IS NOT NULL
BEGIN
    DROP PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero];
END
GO


CREATE PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero]
	@IdEmpresa int = 1,
	@Anio int = 2025,
	@Mes varchar(100) = '5,6,7',
	@IdEstadoFinanciero int = 1
AS
BEGIN
	SET LANGUAGE Spanish

	DECLARE @UltimoMes int, @Sql varchar(MAX)

	SELECT @UltimoMes = MAX(Value) FROM [dbo].[SplitString](@Mes,',')

	DECLARE @Fecha DATE = CONVERT(varchar(5),@Anio) + '-'+ CONVERT(varchar(4),@UltimoMes) + '-20'
	DECLARE @Dia int, @MesLetra varchar(50)
	DECLARE @Var_Meses VARCHAR(MAX)

	SET @Dia = DATEPART(DAY,EOMONTH(@Fecha))
	SET @MesLetra = DATENAME(MONTH,@Fecha)

	SET @Var_Meses =REPLACE(@Mes, ',',''',''')

	SET @Sql = '
		SELECT C.Titulo,
			   CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END Acumulado,
			   B.ParametroLinea,
			   B.Negrita,
			   B.Tabulacion,
			   B.Columna,
			   B.Fuente,
			   B.Size,
			   REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion NombreCuenta,
			   B.Orden,
			   '''+ CONVERT(varchar(10),@Anio) +''' Anio,
			   '''+ CONVERT(varchar(10),@UltimoMes) +'''  Mes,
			   SUM(D.SaldoAnterior) SaldoAnterior,
			   CASE WHEN B.ParametroLinea = 1 THEN NULL ELSE SUM(ISNULL(CASE WHEN C.Tipo = ''Acumulado'' THEN CASE WHEN A.Operacion = 2 THEN D.Saldo * -1 ELSE D.Saldo END ELSE CASE WHEN A.Operacion = 2 THEN D.SaldoActual * -1 ELSE D.SaldoActual END END,0)) END Saldo,
			   B.Subtitulo,
			   '''+ CONVERT(varchar(10),@Dia) +''' DiaFinalMes,
			   '''+ CONVERT(varchar(10),@MesLetra) +''' MesLetra,
			   E.NombreCR
		FROM CR_EstadosFinancierosDetalle B 
			 LEFT JOIN CR_EstadosFinancierosDetalleCuentas A ON B.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle AND A.Eliminado = 0
			 LEFT JOIN CR_EstadosFinancieros C ON C.IdEstadoFinanciero = B.IdEstadoFinanciero
			 LEFT JOIN CR_AsientosMayorizacion D ON D.IdCuentaContable = A.IdCuentaContable AND D.IdEmpresa = A.IdEmpresa AND D.Anio = '''+convert(varchar(10),@Anio)+''' AND D.Mes IN ('''+@Var_Meses+''') AND D.Eliminado = 0 
			 LEFT JOIN AD_Empresas E ON E.IdEmpresa = B.IdEmpresa
		WHERE B.Eliminado = 0
			  AND B.IdEmpresa = '''+convert(varchar(10),@IdEmpresa)+'''
			  AND C.IdEstadoFinanciero = '''+convert(varchar(10),@IdEstadoFinanciero)+'''   
		GROUP BY C.Titulo,
			   CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END,
			   B.ParametroLinea,
			   B.Negrita,
			   B.Tabulacion,
			   B.Columna,
			   B.Fuente,
			   B.Size,
			   REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion,
			   B.Orden,
			   B.Subtitulo,
			   E.NombreCR
		Order by B.Orden
	'

	EXEC(@Sql)

	

END
GO

IF OBJECT_ID(N'dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[CR_EstadosFinancieros_AsegurarBalanceGeneral]
    @IdEmpresa int,
    @Usuario varchar(50) = 'SISTEMA',
    @NombreEquipo varchar(200) = 'SCRIPT',
    @CrearEstadoFinanciero bit = 1
AS
BEGIN
    SET NOCOUNT ON;
    -- Marca de compatibilidad para validadores previos: ACTIVO_CARTERA_PRESTAMOS PASIVO_AHORROS_RETIRABLES.

    BEGIN TRY
        IF @IdEmpresa IS NULL OR @IdEmpresa <= 0
        BEGIN
            RAISERROR('Debe indicar una empresa valida.', 16, 1);
            RETURN;
        END;

        SET @Usuario = ISNULL(NULLIF(LTRIM(RTRIM(@Usuario)), ''), 'SISTEMA');
        SET @NombreEquipo = ISNULL(NULLIF(LTRIM(RTRIM(@NombreEquipo)), ''), 'SCRIPT');

        DECLARE @CodigoBalance varchar(50) = '001';
        DECLARE @NombreBalance varchar(250) = 'BALANCE GENERAL';
        DECLARE @TituloBalance varchar(500) = 'BALANCE GENERAL';
        DECLARE @SubtituloBalance varchar(MAX) = NULL;
        DECLARE @TipoBalance varchar(50) = 'Acumulado';
        DECLARE @FechaActualizacion datetime = GETDATE();
        DECLARE @IdEstadoFinanciero int;

DECLARE @PlantillaDetalle TABLE(
    Orden int NOT NULL PRIMARY KEY,
    ParametroLinea int NOT NULL,
    Descripcion nvarchar(500) NULL,
    Subtitulo bit NOT NULL,
    Negrita bit NOT NULL,
    Tabulacion int NOT NULL,
    Columna int NOT NULL,
    Fuente varchar(200) NOT NULL,
    Size int NOT NULL
);

INSERT INTO @PlantillaDetalle(Orden, ParametroLinea, Descripcion, Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size)
VALUES
    (1, 1, N'ACTIVO', 0, 1, 0, 1, 'Cambria', 12),
    (2, 2, N'CAJA', 0, 0, 1, 1, 'Cambria', 12),
    (3, 2, N'BANCOS', 0, 0, 1, 1, 'Cambria', 12),
    (4, 2, N'DEPOSITOS A PLAZO', 0, 0, 1, 1, 'Cambria', 12),
    (5, 2, N'CARTERA DE PRÉSTAMOS', 0, 0, 1, 1, 'Cambria', 12),
    (6, 2, N'DEUDORES VARIOS', 0, 0, 1, 1, 'Cambria', 12),
    (7, 2, N'FUNCIONARIOS Y EMPLEADOS', 0, 0, 1, 1, 'Cambria', 12),
    (8, 2, N'COOPERATIVISTAS', 0, 0, 1, 1, 'Cambria', 12),
    (9, 2, N'CUENTAS VARIAS', 0, 0, 1, 1, 'Cambria', 12),
    (10, 2, N'TERRENOS EVENTUALES', 0, 0, 1, 1, 'Cambria', 12),
    (11, 2, N'EDIFICIOS EVENTUALES', 0, 0, 1, 1, 'Cambria', 12),
    (12, 2, N'ACTIVOS PARA BIENES RAICES', 0, 0, 1, 1, 'Cambria', 12),
    (13, 2, N'TERRENOS Y EDIFICIOS', 0, 0, 1, 1, 'Cambria', 12),
    (14, 2, N'VEHÍCULOS', 0, 0, 1, 1, 'Cambria', 12),
    (15, 2, N'MOBILIARIO Y EQUIPO DE OFICINA', 0, 0, 1, 1, 'Cambria', 12),
    (16, 2, N'MAQUINARIA Y EQUIPO', 0, 0, 1, 1, 'Cambria', 12),
    (17, 2, N'EQUIPO DE INFORMÁTICA', 0, 0, 1, 1, 'Cambria', 12),
    (18, 2, N'PRIMAS DE SEGURO', 0, 0, 1, 1, 'Cambria', 12),
    (19, 2, N'ESPECIES FISCALES', 0, 0, 1, 1, 'Cambria', 12),
    (20, 2, N'OTROS CARGOS DIFERIDOS', 0, 0, 1, 1, 'Cambria', 12),
    (21, 2, N'PROGRAMAS Y APLICACIONES INFORMÁTICAS', 0, 0, 1, 1, 'Cambria', 12),
    (22, 2, N'TOTAL ACTIVO', 0, 1, 0, 2, 'Cambria', 12),
    (23, 1, N'PASIVO', 0, 1, 0, 1, 'Cambria', 12),
    (24, 2, N'ACREEDORES VARIOS', 0, 0, 1, 1, 'Cambria', 12),
    (25, 2, N'SUELDOS POR PAGAR', 0, 0, 1, 1, 'Cambria', 12),
    (26, 2, N'SERVICIOS PUBLICOS', 0, 0, 1, 1, 'Cambria', 12),
    (27, 2, N'CUENTAS VARIAS', 0, 0, 1, 1, 'Cambria', 12),
    (28, 2, N'EXCEDENTES POR DISTRIBUIR', 0, 0, 1, 1, 'Cambria', 12),
    (29, 2, N'INTERESES POR PAGAR', 0, 0, 1, 1, 'Cambria', 12),
    (30, 2, N'AHORROS NAVIDEÑOS', 0, 0, 1, 1, 'Cambria', 12),
    (31, 2, N'AHORROS RETIRABLES', 0, 0, 1, 1, 'Cambria', 12),
    (32, 2, N'DEPOSITOS A PLAZO', 0, 0, 1, 1, 'Cambria', 12),
    (33, 2, N'PRÉSTAMOS POR PAGAR', 0, 0, 1, 1, 'Cambria', 12),
    (34, 2, N'PROVISIÓN PARA CRÉDITOS DUDOSOS', 0, 0, 1, 1, 'Cambria', 12),
    (35, 2, N'PROVISIÓN PARA INTERESES DUDOSOS', 0, 0, 1, 1, 'Cambria', 12),
    (36, 2, N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 0, 0, 1, 1, 'Cambria', 12),
    (37, 2, N'DEPRECIACIÓN ACUMULADA DE VEHÍCULOS', 0, 0, 1, 1, 'Cambria', 12),
    (38, 2, N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 0, 0, 1, 1, 'Cambria', 12),
    (39, 2, N'DEPRECIACIÓN ACUMULADA DE MAQUINARIA Y EQUIPO', 0, 0, 1, 1, 'Cambria', 12),
    (40, 2, N'DEPRECIACIÓN ACUMULADA DE EQUIPO DE INFORMÁTICA', 0, 0, 1, 1, 'Cambria', 12),
    (41, 2, N'AMORTIZACIÓN DE ACTIVOS EVENTUALES', 0, 0, 1, 1, 'Cambria', 12),
    (42, 2, N'PROVISIONES EVENTUALES', 0, 0, 1, 1, 'Cambria', 12),
    (43, 2, N'PROVISIONES ESPECIALES', 0, 0, 1, 1, 'Cambria', 12),
    (44, 2, N'OTRAS PROVISIONES', 0, 0, 1, 1, 'Cambria', 12),
    (45, 3, N'TOTAL PASIVO', 0, 1, 0, 2, 'Cambria', 12),
    (46, 1, N'PATRIMONIO', 0, 1, 0, 1, 'Cambria', 12),
    (47, 2, N'APORTACIONES', 0, 0, 1, 1, 'Cambria', 12),
    (48, 2, N'CAPITALIZACIÓN DE EXCEDENTES', 0, 0, 1, 1, 'Cambria', 12),
    (49, 2, N'RESERVA LEGAL', 0, 0, 1, 1, 'Cambria', 12),
    (50, 2, N'RESERVAS ESTATURARIAS', 0, 0, 1, 1, 'Cambria', 12),
    (51, 2, N'EXCEDENTES ACUMULADOS', 0, 0, 1, 1, 'Cambria', 12),
    (52, 2, N'EXCEDENTE EL EJERCICIO', 0, 0, 1, 1, 'Cambria', 12),
    (53, 2, N'PÉRDIDA ACUMULADA', 0, 0, 1, 1, 'Cambria', 12),
    (54, 2, N'PÉRDIDA DEL EJERCICIO', 0, 0, 1, 1, 'Cambria', 12),
    (55, 3, N'TOTAL PATRIMONIO', 0, 0, 0, 2, 'Cambria', 12),
    (56, 3, N'TOTAL PASIVO MÁS PATRIMONIO', 0, 0, 0, 2, 'Cambria', 12);

DECLARE @PlantillaCuentas TABLE(
    OrdenDetalle int NOT NULL,
    CuentaContable varchar(50) NOT NULL,
    NombreCuenta nvarchar(500) NULL,
    Operacion int NOT NULL,
    OrdenCuenta int NOT NULL
);

INSERT INTO @PlantillaCuentas(OrdenDetalle, CuentaContable, NombreCuenta, Operacion, OrdenCuenta)
VALUES
    (2, '10101', N'CAJA', 1, 1),
    (3, '10102', N'BANCOS', 1, 1),
    (4, '10201', N'DEPOSITOS A PLAZO', 1, 1),
    (5, '10301', N'CARTERA DE PRÉSTAMOS', 1, 1),
    (6, '10401', N'DEUDORES VARIOS', 1, 1),
    (7, '10402', N'FUNCIONARIOS Y EMPLEADOS', 1, 1),
    (8, '10403', N'COOPERATIVISTAS', 1, 1),
    (9, '10404', N'CUENTAS VARIAS', 1, 1),
    (10, '10501', N'TERRENOS EVENTUALES', 1, 1),
    (11, '10502', N'EDIFICIOS EVENTUALES', 1, 1),
    (12, '10601', N'ACTIVOS PARA BIENES RAICES', 1, 1),
    (13, '10602', N'TERRENOS Y EDIFICIOS', 1, 1),
    (14, '10603', N'VEHÍCULOS', 1, 1),
    (15, '10604', N'MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (16, '10605', N'MAQUNARIA Y EQUIPO', 1, 1),
    (17, '10606', N'EQUIPO DE INFORMATICA', 1, 1),
    (18, '10701', N'PRIMAS DE SEGURO', 1, 1),
    (19, '10702', N'ESPECIES FISCALES', 1, 1),
    (20, '10703', N'OTROS CARGOS DIFERIDOS', 1, 1),
    (21, '10801', N'PROGRAMAS Y APLICACIONES INFORMÁTICAS', 1, 1),
    (22, '10101', N'CAJA', 1, 1),
    (22, '10102', N'BANCOS', 1, 1),
    (22, '10201', N'DEPOSITOS A PLAZO', 1, 1),
    (22, '10301', N'CARTERA DE PRÉSTAMOS', 1, 1),
    (22, '10401', N'DEUDORES VARIOS', 1, 1),
    (22, '10402', N'FUNCIONARIOS Y EMPLEADOS', 1, 1),
    (22, '10403', N'COOPERATIVISTAS', 1, 1),
    (22, '10404', N'CUENTAS VARIAS', 1, 1),
    (22, '10501', N'TERRENOS EVENTUALES', 1, 1),
    (22, '10502', N'EDIFICIOS EVENTUALES', 1, 1),
    (22, '10601', N'ACTIVOS PARA BIENES RAICES', 1, 1),
    (22, '10602', N'TERRENOS Y EDIFICIOS', 1, 1),
    (22, '10603', N'VEHÍCULOS', 1, 1),
    (22, '10604', N'MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (22, '10605', N'MAQUNARIA Y EQUIPO', 1, 1),
    (22, '10606', N'EQUIPO DE INFORMATICA', 1, 1),
    (22, '10701', N'PRIMAS DE SEGURO', 1, 1),
    (22, '10702', N'ESPECIES FISCALES', 1, 1),
    (22, '10703', N'OTROS CARGOS DIFERIDOS', 1, 1),
    (22, '10801', N'PROGRAMAS Y APLICACIONES INFORMÁTICAS', 1, 1),
    (24, '20101', N'ACREEDORES VARIOS', 1, 1),
    (25, '20102', N'SUELDOS POR PAGAR', 1, 1),
    (26, '20103', N'SERVICIOS PUBLICOS', 1, 1),
    (27, '20104', N'CUENTAS VARIAS', 1, 1),
    (28, '20105', N'EXCEDENTES POR DISTRIBUIR', 1, 1),
    (29, '20106', N'INTERESES POR PAGAR ', 1, 1),
    (30, '20201', N'AHORROS NAVIDEÑOS', 1, 1),
    (31, '20202', N'AHORROS RETIRABLES', 1, 1),
    (32, '20203', N'DEPOSITOS A PLAZO', 1, 1),
    (33, '20301', N'PRÉSTAMOS POR PAGAR', 1, 1),
    (34, '20401', N'PROVISION PARA CREDITOS DUDOSOS', 1, 1),
    (35, '20402', N'PROVISION PARA INTERESES DUDOSOS', 1, 1),
    (36, '20403', N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 1, 1),
    (37, '20405', N'DEPRECIACIÓN ACUMULADA DEVEHÍCULOS', 1, 1),
    (38, '20406', N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (39, '20407', N'DEPRECIACIÓN ACUMULADA DE MAQUNARIA Y EQUIPO', 1, 1),
    (40, '20408', N'DEPRECIACIÓN ACUMULADA DE EQUIPO DE INFORMATICA', 1, 1),
    (41, '20409', N'AMORTIZACION DE ACTIVOS EVENTUALES', 1, 1),
    (42, '20501', N'PROVISIONES EVENTUALES', 1, 1),
    (43, '20502', N'PROVISIONES ESPECIALES', 1, 1),
    (44, '20503', N'OTRAS PROVISIONES', 1, 1),
    (45, '20101', N'ACREEDORES VARIOS', 1, 1),
    (45, '20102', N'SUELDOS POR PAGAR', 1, 1),
    (45, '20103', N'SERVICIOS PUBLICOS', 1, 1),
    (45, '20104', N'CUENTAS VARIAS', 1, 1),
    (45, '20105', N'EXCEDENTES POR DISTRIBUIR', 1, 1),
    (45, '20106', N'INTERESES POR PAGAR ', 1, 1),
    (45, '20201', N'AHORROS NAVIDEÑOS', 1, 1),
    (45, '20202', N'AHORROS RETIRABLES', 1, 1),
    (45, '20203', N'DEPOSITOS A PLAZO', 1, 1),
    (45, '20301', N'PRÉSTAMOS POR PAGAR', 1, 1),
    (45, '20401', N'PROVISION PARA CREDITOS DUDOSOS', 1, 1),
    (45, '20402', N'PROVISION PARA INTERESES DUDOSOS', 1, 1),
    (45, '20403', N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 1, 1),
    (45, '20405', N'DEPRECIACIÓN ACUMULADA DEVEHÍCULOS', 1, 1),
    (45, '20406', N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (45, '20407', N'DEPRECIACIÓN ACUMULADA DE MAQUNARIA Y EQUIPO', 1, 1),
    (45, '20408', N'DEPRECIACIÓN ACUMULADA DE EQUIPO DE INFORMATICA', 1, 1),
    (45, '20409', N'AMORTIZACION DE ACTIVOS EVENTUALES', 1, 1),
    (45, '20501', N'PROVISIONES EVENTUALES', 1, 1),
    (45, '20502', N'PROVISIONES ESPECIALES', 1, 1),
    (45, '20503', N'OTRAS PROVISIONES', 1, 1),
    (47, '30101', N'APORTACIONES', 1, 1),
    (47, '30102', N'CAPITALIZACIÓN DE EXCEDENTES', 1, 1),
    (47, '30103', N'DONACIONES', 1, 1),
    (48, '30102', N'CAPITALIZACIÓN DE EXCEDENTES', 1, 1),
    (49, '30201', N'RESERVA LEGAL', 1, 1),
    (50, '30202', N'RESERVAS ESTATURARIAS', 1, 1),
    (51, '30301', N'EXCEDENTES ACUMULADOS', 1, 1),
    (52, '30302', N'EXCEDENTE EL EJERCICIO', 1, 1),
    (53, '30303', N'PÉRDIDA ACUMULADA', 2, 1),
    (54, '30304', N'PÉRDIDA DEL EJERCICIO', 2, 1),
    (55, '30101', N'APORTACIONES', 1, 1),
    (55, '30102', N'CAPITALIZACIÓN DE EXCEDENTES', 1, 1),
    (55, '30103', N'DONACIONES', 1, 1),
    (55, '30201', N'RESERVA LEGAL', 1, 1),
    (55, '30202', N'RESERVAS ESTATURARIAS', 1, 1),
    (55, '30301', N'EXCEDENTES ACUMULADOS', 1, 1),
    (55, '30302', N'EXCEDENTE EL EJERCICIO', 1, 1),
    (55, '30303', N'PÉRDIDA ACUMULADA', 2, 1),
    (55, '30304', N'PÉRDIDA DEL EJERCICIO', 2, 1),
    (56, '20101', N'ACREEDORES VARIOS', 1, 1),
    (56, '20102', N'SUELDOS POR PAGAR', 1, 1),
    (56, '20103', N'SERVICIOS PUBLICOS', 1, 1),
    (56, '20104', N'CUENTAS VARIAS', 1, 1),
    (56, '20105', N'EXCEDENTES POR DISTRIBUIR', 1, 1),
    (56, '20106', N'INTERESES POR PAGAR ', 1, 1),
    (56, '20201', N'AHORROS NAVIDEÑOS', 1, 1),
    (56, '20202', N'AHORROS RETIRABLES', 1, 1),
    (56, '20203', N'DEPOSITOS A PLAZO', 1, 1),
    (56, '20301', N'PRÉSTAMOS POR PAGAR', 1, 1),
    (56, '20401', N'PROVISION PARA CREDITOS DUDOSOS', 1, 1),
    (56, '20402', N'PROVISION PARA INTERESES DUDOSOS', 1, 1),
    (56, '20403', N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 1, 1),
    (56, '20405', N'DEPRECIACIÓN ACUMULADA DEVEHÍCULOS', 1, 1),
    (56, '20406', N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (56, '20407', N'DEPRECIACIÓN ACUMULADA DE MAQUNARIA Y EQUIPO', 1, 1),
    (56, '20408', N'DEPRECIACIÓN ACUMULADA DE EQUIPO DE INFORMATICA', 1, 1),
    (56, '20409', N'AMORTIZACION DE ACTIVOS EVENTUALES', 1, 1),
    (56, '20501', N'PROVISIONES EVENTUALES', 1, 1),
    (56, '20502', N'PROVISIONES ESPECIALES', 1, 1),
    (56, '20503', N'OTRAS PROVISIONES', 1, 1),
    (56, '30101', N'APORTACIONES', 1, 1),
    (56, '30102', N'CAPITALIZACIÓN DE EXCEDENTES', 1, 1),
    (56, '30103', N'DONACIONES', 1, 1),
    (56, '30201', N'RESERVA LEGAL', 1, 1),
    (56, '30202', N'RESERVAS ESTATURARIAS', 1, 1),
    (56, '30301', N'EXCEDENTES ACUMULADOS', 1, 1),
    (56, '30302', N'EXCEDENTE EL EJERCICIO', 1, 1),
    (56, '30303', N'PÉRDIDA ACUMULADA', 2, 1),
    (56, '30304', N'PÉRDIDA DEL EJERCICIO', 2, 1);

        BEGIN TRANSACTION;

        SELECT TOP (1) @IdEstadoFinanciero = IdEstadoFinanciero
        FROM dbo.CR_EstadosFinancieros
        WHERE IdEmpresa = @IdEmpresa
          AND Eliminado = 0
          AND (
              UPPER(ISNULL(Codigo, '')) = UPPER(ISNULL(@CodigoBalance, ''))
              OR UPPER(ISNULL(Nombre, '')) COLLATE Latin1_General_CI_AI LIKE '%BALANCE%GENERAL%'
              OR UPPER(ISNULL(Titulo, '')) COLLATE Latin1_General_CI_AI LIKE '%BALANCE%GENERAL%'
          )
        ORDER BY CASE WHEN UPPER(ISNULL(Codigo, '')) = UPPER(ISNULL(@CodigoBalance, '')) THEN 0 ELSE 1 END,
                 IdEstadoFinanciero;

        IF @IdEstadoFinanciero IS NULL AND @CrearEstadoFinanciero = 1
        BEGIN
            INSERT INTO dbo.CR_EstadosFinancieros(IdEmpresa, Codigo, Nombre, Titulo, Subtitulo, Tipo, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
            VALUES(@IdEmpresa, @CodigoBalance, @NombreBalance, @TituloBalance, @SubtituloBalance, @TipoBalance, 0, @Usuario, @FechaActualizacion, @NombreEquipo, 0, NULL);
            SET @IdEstadoFinanciero = SCOPE_IDENTITY();
        END;

        IF @IdEstadoFinanciero IS NULL
        BEGIN
            RAISERROR('No se encontro un estado financiero de Balance General para la empresa indicada.', 16, 1);
        END;

        UPDATE dbo.CR_EstadosFinancieros
        SET Codigo = @CodigoBalance,
            Nombre = @NombreBalance,
            Titulo = @TituloBalance,
            Subtitulo = @SubtituloBalance,
            Tipo = @TipoBalance,
            Eliminado = 0,
            Usuario = @Usuario,
            FechaHora = @FechaActualizacion,
            NombreEquipo = @NombreEquipo,
            Sincronizado = 0,
            FechaHoraSincronizacion = NULL
        WHERE IdEmpresa = @IdEmpresa
          AND IdEstadoFinanciero = @IdEstadoFinanciero;

        UPDATE C
        SET Eliminado = 1,
            Usuario = @Usuario,
            FechaHora = @FechaActualizacion,
            NombreEquipo = @NombreEquipo,
            Sincronizado = 0,
            FechaHoraSincronizacion = NULL
        FROM dbo.CR_EstadosFinancierosDetalleCuentas C
        INNER JOIN dbo.CR_EstadosFinancierosDetalle D
                ON D.IdEstadoFinancieroDetalle = C.IdEstadoFinancieroDetalle
               AND D.IdEmpresa = C.IdEmpresa
        WHERE D.IdEmpresa = @IdEmpresa
          AND D.IdEstadoFinanciero = @IdEstadoFinanciero
          AND C.Eliminado = 0;

        UPDATE dbo.CR_EstadosFinancierosDetalle
        SET Eliminado = 1,
            Usuario = @Usuario,
            FechaHora = @FechaActualizacion,
            NombreEquipo = @NombreEquipo,
            Sincronizado = 0,
            FechaHoraSincronizacion = NULL
        WHERE IdEmpresa = @IdEmpresa
          AND IdEstadoFinanciero = @IdEstadoFinanciero
          AND Eliminado = 0;

        DECLARE @DetalleMap TABLE(Orden int NOT NULL PRIMARY KEY, IdEstadoFinancieroDetalle int NOT NULL);

        INSERT INTO dbo.CR_EstadosFinancierosDetalle(IdEstadoFinanciero, IdEmpresa, Orden, ParametroLinea, Descripcion, Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
        OUTPUT inserted.Orden, inserted.IdEstadoFinancieroDetalle INTO @DetalleMap(Orden, IdEstadoFinancieroDetalle)
        SELECT @IdEstadoFinanciero, @IdEmpresa, Orden, ParametroLinea, CONVERT(varchar(500), Descripcion), Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size, 0, @Usuario, @FechaActualizacion, @NombreEquipo, 0, NULL
        FROM @PlantillaDetalle
        ORDER BY Orden;

        ;WITH CuentasDestino AS (
            SELECT IdCuentaContable,
                   CuentaContable,
                   ROW_NUMBER() OVER(PARTITION BY CuentaContable ORDER BY CASE WHEN Operable = 1 THEN 0 ELSE 1 END, IdCuentaContable) AS Fila
            FROM dbo.CR_CuentasContables
            WHERE IdEmpresa = @IdEmpresa
              AND Eliminado = 0
        )
        INSERT INTO dbo.CR_EstadosFinancierosDetalleCuentas(IdEstadoFinancieroDetalle, IdEmpresa, IdCuentaContable, CuentaContable, NombreCuenta, Operacion, Orden, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
        SELECT M.IdEstadoFinancieroDetalle,
               @IdEmpresa,
               C.IdCuentaContable,
               P.CuentaContable,
               CONVERT(varchar(500), P.NombreCuenta),
               P.Operacion,
               P.OrdenCuenta,
               0,
               @Usuario,
               @FechaActualizacion,
               @NombreEquipo,
               0,
               NULL
        FROM @PlantillaCuentas P
        INNER JOIN @DetalleMap M ON M.Orden = P.OrdenDetalle
        INNER JOIN CuentasDestino C ON C.CuentaContable = P.CuentaContable AND C.Fila = 1
        ORDER BY P.OrdenDetalle, P.OrdenCuenta, P.CuentaContable;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        DECLARE @ErrorMessage nvarchar(4000) = ERROR_MESSAGE();
        RAISERROR(@ErrorMessage, 16, 1);
        RETURN;
    END CATCH;
END
GO
DECLARE @EmpresasBalanceGeneral TABLE(
    IdEmpresa int NOT NULL PRIMARY KEY
);

INSERT INTO @EmpresasBalanceGeneral(IdEmpresa)
SELECT e.IdEmpresa
FROM dbo.AD_Empresas e
WHERE e.Activo = 1
  AND e.Eliminado = 0
  AND e.AplicaCR = 1
  AND e.IdEmpresa IS NOT NULL

UNION

SELECT el.IdEmpresa
FROM dbo.AD_EmpresaLocal el
WHERE el.Activo = 1
  AND el.AplicaCR = 1
  AND el.IdEmpresa IS NOT NULL;

DECLARE @IdEmpresaBalanceGeneral int;

DECLARE EmpresasBalanceGeneralCursor CURSOR LOCAL FAST_FORWARD FOR
SELECT IdEmpresa
FROM @EmpresasBalanceGeneral
ORDER BY IdEmpresa;

OPEN EmpresasBalanceGeneralCursor;
FETCH NEXT FROM EmpresasBalanceGeneralCursor INTO @IdEmpresaBalanceGeneral;

WHILE @@FETCH_STATUS = 0
BEGIN
    EXEC dbo.CR_EstadosFinancieros_AsegurarBalanceGeneral
        @IdEmpresa = @IdEmpresaBalanceGeneral,
        @Usuario = 'SA',
        @NombreEquipo = 'ACTUALIZACION';

    FETCH NEXT FROM EmpresasBalanceGeneralCursor INTO @IdEmpresaBalanceGeneral;
END;

CLOSE EmpresasBalanceGeneralCursor;
DEALLOCATE EmpresasBalanceGeneralCursor;
GO

/*
    SG_ActualizacionesBaseDatos
    Tabla de control para no volver a ejecutar el mismo paquete de actualizacion.
*/
IF OBJECT_ID(N'dbo.SG_ActualizacionesBaseDatos', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.SG_ActualizacionesBaseDatos
    (
        IdActualizacionBaseDatos int IDENTITY(1,1) NOT NULL CONSTRAINT PK_SG_ActualizacionesBaseDatos PRIMARY KEY,
        PaqueteSha256 varchar(64) NOT NULL,
        OrigenPaquete varchar(500) NULL,
        FechaHora datetime NOT NULL CONSTRAINT DF_SG_ActualizacionesBaseDatos_FechaHora DEFAULT(GETDATE()),
        Usuario varchar(100) NULL,
        NombreEquipo varchar(200) NULL,
        Exitoso bit NOT NULL CONSTRAINT DF_SG_ActualizacionesBaseDatos_Exitoso DEFAULT(1),
        Detalle nvarchar(MAX) NULL
    );
END
GO

IF COL_LENGTH('dbo.SG_ActualizacionesBaseDatos', 'PaqueteSha256') IS NULL
BEGIN
    RAISERROR('La tabla dbo.SG_ActualizacionesBaseDatos existe, pero no tiene la columna PaqueteSha256.', 16, 1);
END
GO

/*
    POS_AsientosVisor - filtro Activos / Anulados / Todos
    Corrige @Anulado para que:
    - 0 use A.Anulado = 0
    - 1 use A.Anulado = 1
    - NULL muestre ambos
*/
IF OBJECT_ID(N'dbo.POS_AsientosVisor', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_AsientosVisor AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_AsientosVisor]
    @IdEmpresa int,
    @FechaDesde date,
    @FechaHasta date,
    @IdTipo int,
    @Busqueda varchar(200),
    @Anulado bit = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SET @Busqueda = ISNULL(@Busqueda, '');

    SELECT A.IdAsiento,
           A.IdAsiento NoAsiento,
           A.FechaAsiento,
           ISNULL(A.NumeroReferencia, '') NumeroReferencia,
           ISNULL(B.TipoAsiento, 'ASIENTO MANUAL') TipoAsiento,
           ISNULL(A.Sinopsis, '') Sinopsis,
           ISNULL(A.Anulado, 0) Anulado,
           A.FechaHoraMayorizacion,
           ISNULL(A.Mayorizado, 0) Mayorizado,
           ISNULL(A.IdTipoAsiento, -1) IdTipoAsiento
    FROM dbo.CR_Asientos A
         LEFT JOIN dbo.CR_TipoAsiento B ON A.IdTipoAsiento = B.IdTipoAsiento
    WHERE ISNULL(A.Eliminado, 0) = 0
      AND A.IdEmpresa = @IdEmpresa
      AND A.FechaAsiento BETWEEN @FechaDesde AND @FechaHasta
      AND ISNULL(A.IdTipoAsiento, -1) = CASE
                                            WHEN ISNULL(@IdTipo, 0) = 0 THEN ISNULL(A.IdTipoAsiento, -1)
                                            WHEN @IdTipo > 0 THEN @IdTipo
                                            ELSE -1
                                        END
      AND (@Anulado IS NULL OR A.Anulado = @Anulado)
      AND ISNULL(A.NumeroReferencia, '') LIKE '%' + @Busqueda + '%';
END
GO

/*
    POS_CompraProveedor - FechaRegistro y fecha de compra distinta
    Agrega FechaRegistro, la registra desde el encabezado y evita que
    POS_CompraProveedor_Finalizar reemplace FechaCompra con GETDATE().
*/
IF COL_LENGTH('dbo.POS_CompraProveedor', 'FechaRegistro') IS NULL
BEGIN
    ALTER TABLE dbo.POS_CompraProveedor ADD FechaRegistro date NULL;
END
GO

UPDATE dbo.POS_CompraProveedor
SET FechaRegistro = CAST(ISNULL(FechaCompra, GETDATE()) AS date)
WHERE FechaRegistro IS NULL;
GO

IF COL_LENGTH('dbo.POS_CompraProveedor', 'FechaRegistro') IS NOT NULL
   AND NOT EXISTS
   (
       SELECT 1
       FROM sys.default_constraints dc
            INNER JOIN sys.columns c
                ON c.object_id = dc.parent_object_id
               AND c.column_id = dc.parent_column_id
       WHERE dc.parent_object_id = OBJECT_ID(N'dbo.POS_CompraProveedor')
         AND c.name = N'FechaRegistro'
   )
BEGIN
    ALTER TABLE dbo.POS_CompraProveedor
    ADD CONSTRAINT DF_POS_CompraProveedor_FechaRegistro DEFAULT(CONVERT(date, GETDATE())) FOR FechaRegistro;
END
GO

IF OBJECT_ID(N'dbo.POS_CompraProveedor_IniciarHeader', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_CompraProveedor_IniciarHeader AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_CompraProveedor_IniciarHeader]
    @IdEmpresa INT,
    @IdProveedor INT,
    @FechaCompra DATE
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.POS_CompraProveedor
    (
        IdEmpresa,
        IdProveedor,
        NumDocumentoCompra,
        CAICompra,
        FechaCompra,
        FechaRegistro,
        IdTermino,
        Comentario,
        SubTotal,
        Descuento,
        Impuesto,
        Total,
        UsuarioRegistro,
        NombreEquipo,
        Finalizada,
        Eliminado,
        FechaHora,
        Sincronizado
    )
    VALUES
    (   @IdEmpresa,
        @IdProveedor,
        '',
        '',
        ISNULL(@FechaCompra, CONVERT(date, GETDATE())),
        CONVERT(date, GETDATE()),
        1,
        '',
        0,
        0,
        0,
        0,
        '',
        '',
        0,
        0,
        GETDATE(),
        0);

    SELECT CONVERT(INT, SCOPE_IDENTITY()) AS IdCompraGenerada;
END
GO

IF OBJECT_ID(N'dbo.POS_CompraProveedor_Finalizar', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_CompraProveedor_Finalizar AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_CompraProveedor_Finalizar]
    @IdEmpresa INT,
    @IdCompraProveedor INT,
    @IdProveedor INT,
    @IdTermino INT,
    @Comentario VARCHAR(150),
    @NumDocumentoCompra VARCHAR(30),
    @CaiCompra VARCHAR(30),
    @Usuario VARCHAR(20),
    @NombreEquipo VARCHAR(30)
AS
BEGIN
    SET NOCOUNT ON;

    BEGIN TRAN;

    DECLARE @Credito BIT = 0;

    SELECT @Credito = a.EsCredito
    FROM dbo.POS_Terminos a
    WHERE a.IdTermino = @IdTermino;

    ---- Calcular Desglose
    DECLARE @SubTotal DECIMAL(19, 4);
    DECLARE @Impuesto DECIMAL(19, 4);
    DECLARE @Total DECIMAL(19, 4);
    DECLARE @DesgExento DECIMAL(19, 4);
    DECLARE @DesgGravado15 DECIMAL(19, 4);
    DECLARE @DesgGravado18 DECIMAL(19, 4);
    DECLARE @DesgImp15 DECIMAL(19, 4);
    DECLARE @DesgImp18 DECIMAL(19, 4);

    SELECT @SubTotal = SUM(Resumen.SubTotal),
           @DesgExento = SUM(Resumen.SubExento),
           @DesgGravado15 = SUM(Resumen.Sub15),
           @DesgGravado18 = SUM(Resumen.Sub18)
    FROM
    (
        SELECT d.SubTotal,
               CASE
                   WHEN d.ValorISV = 0 THEN
                       d.SubTotal
                   ELSE
                       0
               END AS SubExento,
               CASE
                   WHEN d.ValorISV = 15 THEN
                       d.SubTotal
                   ELSE
                       0
               END AS Sub15,
               CASE
                   WHEN d.ValorISV = 18 THEN
                       d.SubTotal
                   ELSE
                       0
               END AS Sub18
        FROM dbo.POS_DetalleCompraProveedor d
        WHERE d.IdCompraProveedor = @IdCompraProveedor
    ) AS Resumen;

    SET @DesgImp15 = @DesgGravado15 * 0.15;
    SET @DesgImp18 = @DesgGravado18 * 0.18;
    SET @Impuesto = @DesgImp15 + @DesgImp18;
    SET @Total = @SubTotal + @Impuesto;

    --- actualizar valores Compra Proveedor
    UPDATE POS_CompraProveedor
    SET [IdProveedor] = @IdProveedor,
        [FechaRegistro] = CONVERT(date, GETDATE()),
        [IdTermino] = @IdTermino,
        [Comentario] = @Comentario,
        [NumDocumentoCompra] = @NumDocumentoCompra,
        [CAICompra] = @CaiCompra,
        [SubTotal] = @SubTotal,
        [Impuesto] = @Impuesto,
        [Total] = @Total,
        Finalizada = 1,
        UsuarioRegistro = @Usuario,
        NombreEquipo = @NombreEquipo,
        FechaHora = GETDATE(),
        Sincronizado = 0
    WHERE IdCompraProveedor = @IdCompraProveedor;

    --- realizar el ingreso a kardex

    DECLARE @IdCategoriaKardex INT;

    SELECT @IdCategoriaKardex = a.IdCategoriaMovKardex
    FROM dbo.POS_CategoriaMovKardex a
    WHERE a.EsCompra = 1;

    DECLARE @Referencia VARCHAR(300)
        = 'Ingreso segun Compra a Proveedor  Factura :' + @NumDocumentoCompra + ' Nro Interno:'
          + CAST(@IdCompraProveedor AS VARCHAR(10));
    DECLARE @IdProducto INT;
    DECLARE @Cantidad INT;
    DECLARE CURSOR_detallecompraproveedor CURSOR FAST_FORWARD READ_ONLY FOR
    SELECT d.IdProducto,
           d.Cantidad
    FROM dbo.POS_DetalleCompraProveedor d
    WHERE d.IdCompraProveedor = @IdCompraProveedor;

    OPEN CURSOR_detallecompraproveedor;

    FETCH NEXT FROM CURSOR_detallecompraproveedor
    INTO @IdProducto,
         @Cantidad;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        EXEC dbo.POS_Kardex_RegistrarMov @IdProducto = @IdProducto,
                                         @IdEmpresa = @IdEmpresa,
                                         @Cantidad = @Cantidad,
                                         @IdCategoriaMovKardex = @IdCategoriaKardex,
                                         @NumDocumento = @IdCompraProveedor,
                                         @Referencia = @Referencia,
                                         @Usuario = @Usuario,
                                         @NombreEquipo = @NombreEquipo;

        FETCH NEXT FROM CURSOR_detallecompraproveedor
        INTO @IdProducto,
             @Cantidad;
    END;

    CLOSE CURSOR_detallecompraproveedor;
    DEALLOCATE CURSOR_detallecompraproveedor;

    IF (@Credito = 1)
    BEGIN
        DECLARE @NroDias INT;
        SELECT @NroDias = a.NroDias
        FROM dbo.POS_Terminos a
        WHERE a.IdTermino = @IdTermino;

        DECLARE @fechavence DATETIME = DATEADD(DAY, @NroDias, GETDATE());

        INSERT INTO dbo.POS_CuentaPorPagar
        (
            IdEmpresa,
            IdCompraProveedor,
            IdProveedor,
            FechaEmision,
            FechaVencimiento,
            MontoOriginal,
            SaldoActual,
            IdEstadoCuentaporPagar,
            Eliminado,
            Usuario,
            FechaHora,
            NombreEquipo,
            Sincronizado,
            FechaHoraSincronizacion
        )
        VALUES
        (   @IdEmpresa,
            @IdCompraProveedor,
            @IdProveedor,
            DEFAULT,
            @fechavence,
            @Total,
            @Total,
            1,
            0,
            @Usuario,
            GETDATE(),
            @NombreEquipo,
            0,
            NULL);
    END;

    COMMIT TRAN;
END
GO

IF OBJECT_ID(N'dbo.POS_CompraProveedor_Visor', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_CompraProveedor_Visor AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_CompraProveedor_Visor]
    @Desde DATE,
    @Hasta DATE,
    @IdEmpresa INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT compra.IdCompraProveedor,
           compra.FechaCompra,
           ISNULL(compra.FechaRegistro, CAST(compra.FechaCompra AS date)) AS FechaRegistro,
           compra.Comentario,
           compra.NumDocumentoCompra,
           compra.CAICompra,
           compra.SubTotal,
           compra.Impuesto,
           compra.Total,
           compra.UsuarioRegistro,
           compra.NombreEquipo,
           proveedor.NombreProveedor AS Proveedor,
           terminos.Terminos
    FROM dbo.POS_CompraProveedor compra
         INNER JOIN dbo.POS_Proveedor proveedor
            ON proveedor.IdProveedor = compra.IdProveedor
         INNER JOIN dbo.POS_Terminos terminos
            ON terminos.IdTermino = compra.IdTermino
    WHERE compra.Finalizada = 1
      AND CAST(compra.FechaCompra AS DATE) BETWEEN @Desde AND @Hasta
      AND compra.Eliminado = 0
      AND compra.IdEmpresa = @IdEmpresa;
END
GO

/*
    POS_Producto - Precio por cantidad
    Permite configurar un precio unitario especial cuando la cantidad facturada
    de un producto alcanza un minimo, por ejemplo una docena.
*/
IF COL_LENGTH('dbo.POS_Producto', 'PrecioPorCantidadActivo') IS NULL
BEGIN
    ALTER TABLE dbo.POS_Producto
    ADD PrecioPorCantidadActivo bit NOT NULL
        CONSTRAINT DF_POS_Producto_PrecioPorCantidadActivo DEFAULT(0);
END
GO

IF COL_LENGTH('dbo.POS_Producto', 'CantidadPrecioEspecial') IS NULL
BEGIN
    ALTER TABLE dbo.POS_Producto
    ADD CantidadPrecioEspecial decimal(18, 2) NOT NULL
        CONSTRAINT DF_POS_Producto_CantidadPrecioEspecial DEFAULT(0);
END
GO

IF COL_LENGTH('dbo.POS_Producto', 'PrecioPorCantidad') IS NULL
BEGIN
    ALTER TABLE dbo.POS_Producto
    ADD PrecioPorCantidad decimal(19, 4) NOT NULL
        CONSTRAINT DF_POS_Producto_PrecioPorCantidad DEFAULT(0);
END
GO

UPDATE dbo.POS_Producto
SET PrecioPorCantidadActivo = ISNULL(PrecioPorCantidadActivo, 0),
    CantidadPrecioEspecial = ISNULL(CantidadPrecioEspecial, 0),
    PrecioPorCantidad = ISNULL(PrecioPorCantidad, 0)
WHERE PrecioPorCantidadActivo IS NULL
   OR CantidadPrecioEspecial IS NULL
   OR PrecioPorCantidad IS NULL;
GO

IF OBJECT_ID(N'dbo.POS_DetalleFactura_Insertar', N'P') IS NULL
BEGIN
    EXEC(N'CREATE PROCEDURE dbo.POS_DetalleFactura_Insertar AS BEGIN SET NOCOUNT ON; END');
END
GO

ALTER PROCEDURE [dbo].[POS_DetalleFactura_Insertar]
    @IdEmpresa INT,
    @IdFactura INT,
    @IdProducto INT,
    @Cantidad DECIMAL(18, 2),
    @usuario VARCHAR(50),
    @NombreEquipo VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @PrecioUnitario DECIMAL(19, 4);
    DECLARE @PrecioVenta DECIMAL(19, 4);
    DECLARE @PrecioEspecial DECIMAL(19, 4);
    DECLARE @PrecioPorCantidadActivo BIT;
    DECLARE @CantidadPrecioEspecial DECIMAL(18, 2);
    DECLARE @ValorISV SMALLINT;
    DECLARE @CostoProducto DECIMAL(19, 4);
    DECLARE @IdDetalleFacturaExistente INT;
    DECLARE @PrecioLineaExistente DECIMAL(19, 4);
    DECLARE @CantidadExistente DECIMAL(18, 2);
    DECLARE @CantidadTotal DECIMAL(18, 2);

    SELECT @CostoProducto = p.Costo,
           @ValorISV = valosisv.ValorISV,
           @PrecioVenta = p.PrecioVenta,
           @PrecioPorCantidadActivo = ISNULL(p.PrecioPorCantidadActivo, 0),
           @CantidadPrecioEspecial = ISNULL(p.CantidadPrecioEspecial, 0),
           @PrecioEspecial = CASE
                                 WHEN ISNULL(p.PrecioPorCantidadActivo, 0) = 1
                                      AND ISNULL(p.CantidadPrecioEspecial, 0) > 0
                                      AND ISNULL(p.PrecioPorCantidad, 0) > 0 THEN
                                     p.PrecioPorCantidad
                                 ELSE
                                     p.PrecioVenta
                             END
    FROM dbo.POS_Producto p
         INNER JOIN dbo.POS_ValorISV valosisv
            ON valosisv.IdValorISV = p.IdValorISV
    WHERE p.IdProducto = @IdProducto
      AND p.IdEmpresa = @IdEmpresa;

    SELECT TOP 1
           @IdDetalleFacturaExistente = d.IdDetalleFactura,
           @CantidadExistente = d.Cantidad,
           @PrecioLineaExistente = d.PrecioUnitario
    FROM dbo.POS_DetalleFactura d
    WHERE d.IdEmpresa = @IdEmpresa
      AND d.IdFactura = @IdFactura
      AND d.IdProducto = @IdProducto
      AND ISNULL(d.Eliminado, 0) = 0
    ORDER BY d.IdDetalleFactura DESC;

    IF @IdDetalleFacturaExistente IS NOT NULL
    BEGIN
        IF @PrecioLineaExistente <> @PrecioVenta
           AND @PrecioLineaExistente <> @PrecioEspecial
        BEGIN
            SET @IdDetalleFacturaExistente = NULL;
        END
        ELSE
        BEGIN
            SET @CantidadTotal = @CantidadExistente + @Cantidad;
            SET @PrecioUnitario = CASE
                                     WHEN @PrecioPorCantidadActivo = 1
                                          AND @CantidadPrecioEspecial > 0
                                          AND @CantidadTotal >= @CantidadPrecioEspecial THEN
                                         @PrecioEspecial
                                     ELSE
                                         @PrecioVenta
                                 END;

            UPDATE dbo.POS_DetalleFactura
            SET Cantidad = @CantidadTotal,
                PrecioUnitario = @PrecioUnitario,
                SubtotalDetalle = @CantidadTotal * @PrecioUnitario,
                ValorISV = @ValorISV,
                CostoProducto = @CostoProducto,
                FechaHora = GETDATE(),
                Usuario = @usuario,
                NombreEquipo = @NombreEquipo,
                Sincronizado = 0,
                FechaHoraSincronizacion = NULL
            WHERE IdDetalleFactura = @IdDetalleFacturaExistente
              AND IdEmpresa = @IdEmpresa;

            RETURN;
        END
    END

    SET @CantidadTotal = @Cantidad;
    SET @PrecioUnitario = CASE
                             WHEN @PrecioPorCantidadActivo = 1
                                  AND @CantidadPrecioEspecial > 0
                                  AND @CantidadTotal >= @CantidadPrecioEspecial THEN
                                 @PrecioEspecial
                             ELSE
                                 @PrecioVenta
                         END;

    IF @IdDetalleFacturaExistente IS NOT NULL
    BEGIN
        UPDATE dbo.POS_DetalleFactura
        SET Cantidad = @CantidadTotal,
            PrecioUnitario = @PrecioUnitario,
            SubtotalDetalle = @CantidadTotal * @PrecioUnitario,
            ValorISV = @ValorISV,
            CostoProducto = @CostoProducto,
            FechaHora = GETDATE(),
            Usuario = @usuario,
            NombreEquipo = @NombreEquipo,
            Sincronizado = 0,
            FechaHoraSincronizacion = NULL
        WHERE IdDetalleFactura = @IdDetalleFacturaExistente
          AND IdEmpresa = @IdEmpresa;

        RETURN;
    END

    INSERT INTO dbo.POS_DetalleFactura
    (
        IdEmpresa,
        IdFactura,
        IdProducto,
        Cantidad,
        PrecioUnitario,
        ValorISV,
        SubtotalDetalle,
        CostoProducto,
        Eliminado,
        Usuario,
        FechaHora,
        NombreEquipo,
        Sincronizado,
        FechaHoraSincronizacion
    )
    VALUES
    (   @IdEmpresa,
        @IdFactura,
        @IdProducto,
        @Cantidad,
        @PrecioUnitario,
        @ValorISV,
        @Cantidad * @PrecioUnitario,
        @CostoProducto,
        0,
        @usuario,
        GETDATE(),
        @NombreEquipo,
        0,
        NULL);
END
GO
