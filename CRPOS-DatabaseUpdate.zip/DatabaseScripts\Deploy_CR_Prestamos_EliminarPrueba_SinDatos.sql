/*
    CR_Prestamos_EliminarPrueba
    Script portable para ejecutar en bases restauradas o en varias empresas.

    No crea tablas ni inserta datos operativos.
    Solo:
      1. Crea/actualiza el procedimiento dbo.CR_Prestamos_EliminarPrueba.
      2. Actualiza la validacion de autorizaciones para permitir Administrador/Soporte.
      3. Crea la autorizacion 00004 para empresas activas de Caja Rural.
      4. Asigna esa autorizacion a los usuarios que ya tienen la 00002.
*/

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.SG_AutorizacionesUsuarios_ValidarUsuario', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.SG_AutorizacionesUsuarios_ValidarUsuario AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE [dbo].[SG_AutorizacionesUsuarios_ValidarUsuario]
    @IdEmpresa INT,
    @CodigoAutorizacion VARCHAR(200),
    @Usuario VARCHAR(50),
    @Contrasena VARCHAR(50),
    @Justificacion VARCHAR(MAX)
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @IdUsuario INT = 0;
    DECLARE @IdAutorizacion INT = 0;
    DECLARE @Perfil VARCHAR(250) = '';
    DECLARE @Mensaje VARCHAR(MAX) = '';
    DECLARE @Error BIT = 0;

    SELECT TOP 1
           @IdUsuario = u.IdUsuario,
           @Perfil = UPPER(LTRIM(RTRIM(ISNULL(p.Perfil, ''))))
    FROM dbo.SG_Usuarios u
    LEFT JOIN dbo.SG_Perfiles p
        ON p.IdPerfil = u.IdPerfil
    WHERE LTRIM(RTRIM(u.NombreUsuario)) = LTRIM(RTRIM(@Usuario))
      AND dbo.DesencriptarClave(u.Contrasena) = @Contrasena
      AND u.Activo = 1
      AND u.Eliminado = 0
      AND (u.IdEmpresa = @IdEmpresa OR u.IdEmpresa IS NULL);

    SELECT TOP 1
           @IdAutorizacion = sa.IdAutorizacion
    FROM dbo.SG_Autorizaciones sa
    WHERE sa.IdEmpresa = @IdEmpresa
      AND LTRIM(RTRIM(sa.Codigo)) = LTRIM(RTRIM(@CodigoAutorizacion))
      AND sa.Activo = 1;

    IF @IdUsuario <= 0
    BEGIN
        SET @Mensaje = '¡Usuario o Contraseña incorrectos!';
        SET @Error = 1;
    END
    ELSE IF @IdAutorizacion <= 0
    BEGIN
        SET @Mensaje = '¡Autorización no configurada o inactiva!';
        SET @Error = 1;
    END
    ELSE IF @Perfil NOT LIKE '%ADMINISTRADOR%'
         AND @Perfil NOT LIKE '%SOPORTE%'
         AND NOT EXISTS (
             SELECT 1
             FROM dbo.SG_AutorizacionesUsuarios sau
             WHERE sau.IdUsuario = @IdUsuario
               AND sau.IdEmpresa = @IdEmpresa
               AND sau.IdAutorizacion = @IdAutorizacion
               AND sau.Eliminado = 0
         )
    BEGIN
        SET @Mensaje = '¡Usuario no autorizado!';
        SET @Error = 1;
    END
    ELSE
    BEGIN
        INSERT INTO dbo.SG_AutorizacionesLogs
        (
            IdEmpresa,
            IdAutorizacion,
            Usuario,
            FechaHora,
            Justificacion
        )
        VALUES
        (
            @IdEmpresa,
            @IdAutorizacion,
            @Usuario,
            GETDATE(),
            @Justificacion
        );
    END;

    SELECT @Mensaje AS Mensaje,
           @Error AS HayError;
END;
GO

SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF OBJECT_ID('dbo.CR_Prestamos_EliminarPrueba', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.CR_Prestamos_EliminarPrueba AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.CR_Prestamos_EliminarPrueba
    @IdPrestamo INT,
    @HayError BIT OUTPUT,
    @Mensaje VARCHAR(200) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    SET @HayError = 0;
    SET @Mensaje = '';

    BEGIN TRY
        IF @IdPrestamo IS NULL OR @IdPrestamo <= 0
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'Debe seleccionar un prestamo valido.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF NOT EXISTS (SELECT 1 FROM dbo.CR_Prestamos WHERE IdPrestamo = @IdPrestamo)
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se encontro el prestamo seleccionado.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (SELECT 1 FROM dbo.CR_Prestamos WHERE IdPrestamo = @IdPrestamo AND Eliminado = 1)
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'El prestamo seleccionado ya esta eliminado.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM dbo.CR_Prestamos
            WHERE IdPrestamo = @IdPrestamo
              AND (PosteadoPrestamo = 1 OR IdAsiento <> 0)
        )
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se puede eliminar un prestamo posteado contablemente.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        IF EXISTS (
            SELECT 1
            FROM dbo.CR_MovimientosPrestamos
            WHERE IdPrestamo = @IdPrestamo
              AND Eliminado = 0
        )
        BEGIN
            SET @HayError = 1;
            SET @Mensaje = 'No se puede eliminar un prestamo con movimientos registrados.';
            SELECT @HayError AS HayError, @Mensaje AS Mensaje;
            RETURN;
        END;

        BEGIN TRANSACTION;

        UPDATE im
        SET Eliminado = 1,
            Sincronizado = 0
        FROM dbo.CR_PrestamosDetalle_InteresesMora im
        INNER JOIN dbo.CR_PrestamosDetalle pd
            ON pd.IdPrestamoDetalle = im.IdPrestamoDetalle
        WHERE pd.IdPrestamo = @IdPrestamo
          AND im.Eliminado = 0;

        UPDATE dbo.CR_PrestamosDetalle
        SET Eliminado = 1,
            Sincronizado = 0
        WHERE IdPrestamo = @IdPrestamo
          AND Eliminado = 0;

        UPDATE dbo.CR_Prestamos
        SET Eliminado = 1,
            Sincronizado = 0
        WHERE IdPrestamo = @IdPrestamo
          AND Eliminado = 0;

        COMMIT TRANSACTION;

        SET @HayError = 0;
        SET @Mensaje = 'El prestamo fue eliminado correctamente.';
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0
            ROLLBACK TRANSACTION;

        SET @HayError = 1;
        SET @Mensaje = LEFT(ERROR_MESSAGE(), 200);
    END CATCH;

    SELECT @HayError AS HayError, @Mensaje AS Mensaje;
END;
GO

DECLARE @AutorizacionesNuevas TABLE (IdAutorizacion INT, IdEmpresa INT);

;WITH EmpresasObjetivo AS
(
    SELECT e.IdEmpresa
    FROM dbo.AD_Empresas e
    WHERE e.Activo = 1
      AND e.Eliminado = 0
      AND e.AplicaCR = 1

    UNION

    SELECT el.IdEmpresa
    FROM dbo.AD_EmpresaLocal el
    WHERE el.Activo = 1
      AND el.AplicaCR = 1
)
INSERT INTO dbo.SG_Autorizaciones
(
    IdEmpresa,
    Codigo,
    Nombre,
    CajaRural,
    PuntoVenta,
    Activo,
    Usuario,
    FechaHora,
    NombreEquipo,
    Sincronizado,
    FechaHoraSincronizado
)
OUTPUT inserted.IdAutorizacion, inserted.IdEmpresa
INTO @AutorizacionesNuevas (IdAutorizacion, IdEmpresa)
SELECT
    e.IdEmpresa,
    '00004',
    'ELIMINAR PRESTAMO DE PRUEBA',
    1,
    0,
    1,
    'SA',
    GETDATE(),
    HOST_NAME(),
    0,
    NULL
FROM EmpresasObjetivo e
WHERE e.IdEmpresa IS NOT NULL
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.SG_Autorizaciones a
      WHERE a.IdEmpresa = e.IdEmpresa
        AND LTRIM(RTRIM(a.Codigo)) = '00004'
  );

;WITH EmpresasObjetivo AS
(
    SELECT e.IdEmpresa
    FROM dbo.AD_Empresas e
    WHERE e.Activo = 1
      AND e.Eliminado = 0
      AND e.AplicaCR = 1

    UNION

    SELECT el.IdEmpresa
    FROM dbo.AD_EmpresaLocal el
    WHERE el.Activo = 1
      AND el.AplicaCR = 1
)
UPDATE a
SET Nombre = 'ELIMINAR PRESTAMO DE PRUEBA',
    CajaRural = 1,
    PuntoVenta = 0,
    Activo = 1,
    Usuario = 'SA',
    FechaHora = GETDATE(),
    NombreEquipo = HOST_NAME(),
    Sincronizado = 0
FROM dbo.SG_Autorizaciones a
INNER JOIN EmpresasObjetivo e
    ON e.IdEmpresa = a.IdEmpresa
WHERE LTRIM(RTRIM(a.Codigo)) = '00004'
  AND (
      a.Activo <> 1
      OR a.CajaRural <> 1
      OR a.PuntoVenta <> 0
      OR LTRIM(RTRIM(ISNULL(a.Nombre, ''))) <> 'ELIMINAR PRESTAMO DE PRUEBA'
  );

INSERT INTO dbo.SG_AutorizacionesUsuarios
(
    IdEmpresa,
    IdAutorizacion,
    IdUsuario,
    Eliminado,
    Usuario,
    FechaHora,
    NombreEquipo,
    Sincronizado,
    FechaHoraSincronizado
)
SELECT
    aDestino.IdEmpresa,
    aDestino.IdAutorizacion,
    au.IdUsuario,
    0,
    'SA',
    GETDATE(),
    HOST_NAME(),
    0,
    NULL
FROM dbo.SG_Autorizaciones aDestino
INNER JOIN dbo.SG_Autorizaciones aBase
    ON aBase.IdEmpresa = aDestino.IdEmpresa
   AND LTRIM(RTRIM(aBase.Codigo)) = '00002'
INNER JOIN dbo.SG_AutorizacionesUsuarios au
    ON au.IdEmpresa = aBase.IdEmpresa
   AND au.IdAutorizacion = aBase.IdAutorizacion
   AND au.Eliminado = 0
WHERE LTRIM(RTRIM(aDestino.Codigo)) = '00004'
  AND NOT EXISTS (
      SELECT 1
      FROM dbo.SG_AutorizacionesUsuarios existente
      WHERE existente.IdEmpresa = aDestino.IdEmpresa
        AND existente.IdAutorizacion = aDestino.IdAutorizacion
        AND existente.IdUsuario = au.IdUsuario
        AND existente.Eliminado = 0
  );
GO

SELECT
    a.IdEmpresa,
    a.Codigo,
    a.Nombre,
    a.Activo,
    COUNT(au.IdAutorizacionUsuario) AS UsuariosAsignados
FROM dbo.SG_Autorizaciones a
LEFT JOIN dbo.SG_AutorizacionesUsuarios au
    ON au.IdEmpresa = a.IdEmpresa
   AND au.IdAutorizacion = a.IdAutorizacion
   AND au.Eliminado = 0
WHERE LTRIM(RTRIM(a.Codigo)) = '00004'
GROUP BY a.IdEmpresa, a.Codigo, a.Nombre, a.Activo
ORDER BY a.IdEmpresa;
GO
