IF OBJECT_ID(N'dbo.CR_AsientosMayorizacion_ReporteEstadoFinanciero', N'P') IS NOT NULL
BEGIN
    DROP PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero];
END
GO


CREATE PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero]
	@IdEmpresa int = 1,
	@Anio int = 2025,
	@Mes varchar(100) = '5,6,7',
	@IdEstadoFinanciero int = 1
AS
BEGIN
	SET LANGUAGE Spanish

	DECLARE @UltimoMes int, @Sql varchar(MAX)

	SELECT @UltimoMes = MAX(Value) FROM [dbo].[SplitString](@Mes,',')

	DECLARE @Fecha DATE = CONVERT(varchar(5),@Anio) + '-'+ CONVERT(varchar(4),@UltimoMes) + '-20'
	DECLARE @Dia int, @MesLetra varchar(50)
	DECLARE @Var_Meses VARCHAR(MAX)

	SET @Dia = DATEPART(DAY,EOMONTH(@Fecha))
	SET @MesLetra = DATENAME(MONTH,@Fecha)

	SET @Var_Meses =REPLACE(@Mes, ',',''',''')

	SET @Sql = '
		SELECT C.Titulo,
			   CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END Acumulado,
			   B.ParametroLinea,
			   B.Negrita,
			   B.Tabulacion,
			   B.Columna,
			   B.Fuente,
			   B.Size,
			   REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion NombreCuenta,
			   B.Orden,
			   '''+ CONVERT(varchar(10),@Anio) +''' Anio,
			   '''+ CONVERT(varchar(10),@UltimoMes) +'''  Mes,
			   SUM(D.SaldoAnterior) SaldoAnterior,
			   CASE WHEN B.ParametroLinea = 1 THEN NULL ELSE SUM(ISNULL(CASE WHEN C.Tipo = ''Acumulado'' THEN CASE WHEN A.Operacion = 2 THEN D.Saldo * -1 ELSE D.Saldo END ELSE CASE WHEN A.Operacion = 2 THEN D.SaldoActual * -1 ELSE D.SaldoActual END END,0)) END Saldo,
			   B.Subtitulo,
			   '''+ CONVERT(varchar(10),@Dia) +''' DiaFinalMes,
			   '''+ CONVERT(varchar(10),@MesLetra) +''' MesLetra,
			   E.NombreCR
		FROM CR_EstadosFinancierosDetalle B 
			 LEFT JOIN CR_EstadosFinancierosDetalleCuentas A ON B.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle AND A.Eliminado = 0
			 LEFT JOIN CR_EstadosFinancieros C ON C.IdEstadoFinanciero = B.IdEstadoFinanciero
			 LEFT JOIN CR_AsientosMayorizacion D ON D.IdCuentaContable = A.IdCuentaContable AND D.IdEmpresa = A.IdEmpresa AND D.Anio = '''+convert(varchar(10),@Anio)+''' AND D.Mes IN ('''+@Var_Meses+''') AND D.Eliminado = 0 
			 LEFT JOIN AD_Empresas E ON E.IdEmpresa = B.IdEmpresa
		WHERE B.Eliminado = 0
			  AND B.IdEmpresa = '''+convert(varchar(10),@IdEmpresa)+'''
			  AND C.IdEstadoFinanciero = '''+convert(varchar(10),@IdEstadoFinanciero)+'''   
		GROUP BY C.Titulo,
			   CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END,
			   B.ParametroLinea,
			   B.Negrita,
			   B.Tabulacion,
			   B.Columna,
			   B.Fuente,
			   B.Size,
			   REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion,
			   B.Orden,
			   B.Subtitulo,
			   E.NombreCR
		Order by B.Orden
	'

	EXEC(@Sql)

	

END
GO

SET NOCOUNT ON;
GO

DECLARE @CodigoBalance varchar(50) = '001';
DECLARE @NombreBalance varchar(250) = 'BALANCE GENERAL';
DECLARE @TituloBalance varchar(500) = 'BALANCE GENERAL';
DECLARE @SubtituloBalance varchar(MAX) = NULL;
DECLARE @TipoBalance varchar(50) = 'Acumulado';
DECLARE @UsuarioActualizacion varchar(50) = 'SISTEMA';
DECLARE @EquipoActualizacion varchar(200) = 'SCRIPT_BALANCE_GENERAL';
DECLARE @FechaActualizacion datetime = GETDATE();

DECLARE @PlantillaDetalle TABLE(
    Orden int NOT NULL PRIMARY KEY,
    ParametroLinea int NOT NULL,
    Descripcion nvarchar(500) NULL,
    Subtitulo bit NOT NULL,
    Negrita bit NOT NULL,
    Tabulacion int NOT NULL,
    Columna int NOT NULL,
    Fuente varchar(200) NOT NULL,
    Size int NOT NULL
);

INSERT INTO @PlantillaDetalle(Orden, ParametroLinea, Descripcion, Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size)
VALUES
    (1, 1, N'ACTIVO', 0, 1, 0, 1, 'Cambria', 12),
    (2, 2, N'CAJA', 0, 0, 1, 1, 'Cambria', 12),
    (3, 2, N'BANCOS', 0, 0, 1, 1, 'Cambria', 12),
    (4, 2, N'DEPOSITOS A PLAZO', 0, 0, 1, 1, 'Cambria', 12),
    (5, 2, N'CARTERA DE PRÉSTAMOS', 0, 0, 1, 1, 'Cambria', 12),
    (6, 2, N'DEUDORES VARIOS', 0, 0, 1, 1, 'Cambria', 12),
    (7, 2, N'FUNCIONARIOS Y EMPLEADOS', 0, 0, 1, 1, 'Cambria', 12),
    (8, 2, N'COOPERATIVISTAS', 0, 0, 1, 1, 'Cambria', 12),
    (9, 2, N'CUENTAS VARIAS', 0, 0, 1, 1, 'Cambria', 12),
    (10, 2, N'TERRENOS EVENTUALES', 0, 0, 1, 1, 'Cambria', 12),
    (11, 2, N'EDIFICIOS EVENTUALES', 0, 0, 1, 1, 'Cambria', 12),
    (12, 2, N'ACTIVOS PARA BIENES RAICES', 0, 0, 1, 1, 'Cambria', 12),
    (13, 2, N'TERRENOS Y EDIFICIOS', 0, 0, 1, 1, 'Cambria', 12),
    (14, 2, N'VEHÍCULOS', 0, 0, 1, 1, 'Cambria', 12),
    (15, 2, N'MOBILIARIO Y EQUIPO DE OFICINA', 0, 0, 1, 1, 'Cambria', 12),
    (16, 2, N'MAQUINARIA Y EQUIPO', 0, 0, 1, 1, 'Cambria', 12),
    (17, 2, N'EQUIPO DE INFORMÁTICA', 0, 0, 1, 1, 'Cambria', 12),
    (18, 2, N'PRIMAS DE SEGURO', 0, 0, 1, 1, 'Cambria', 12),
    (19, 2, N'ESPECIES FISCALES', 0, 0, 1, 1, 'Cambria', 12),
    (20, 2, N'OTROS CARGOS DIFERIDOS', 0, 0, 1, 1, 'Cambria', 12),
    (21, 2, N'PROGRAMAS Y APLICACIONES INFORMÁTICAS', 0, 0, 1, 1, 'Cambria', 12),
    (22, 2, N'TOTAL ACTIVO', 0, 1, 0, 2, 'Cambria', 12),
    (23, 1, N'PASIVO', 0, 1, 0, 1, 'Cambria', 12),
    (24, 2, N'ACREEDORES VARIOS', 0, 0, 1, 1, 'Cambria', 12),
    (25, 2, N'SUELDOS POR PAGAR', 0, 0, 1, 1, 'Cambria', 12),
    (26, 2, N'SERVICIOS PUBLICOS', 0, 0, 1, 1, 'Cambria', 12),
    (27, 2, N'CUENTAS VARIAS', 0, 0, 1, 1, 'Cambria', 12),
    (28, 2, N'EXCEDENTES POR DISTRIBUIR', 0, 0, 1, 1, 'Cambria', 12),
    (29, 2, N'INTERESES POR PAGAR', 0, 0, 1, 1, 'Cambria', 12),
    (30, 2, N'AHORROS NAVIDEÑOS', 0, 0, 1, 1, 'Cambria', 12),
    (31, 2, N'AHORROS RETIRABLES', 0, 0, 1, 1, 'Cambria', 12),
    (32, 2, N'DEPOSITOS A PLAZO', 0, 0, 1, 1, 'Cambria', 12),
    (33, 2, N'PRÉSTAMOS POR PAGAR', 0, 0, 1, 1, 'Cambria', 12),
    (34, 2, N'PROVISIÓN PARA CRÉDITOS DUDOSOS', 0, 0, 1, 1, 'Cambria', 12),
    (35, 2, N'PROVISIÓN PARA INTERESES DUDOSOS', 0, 0, 1, 1, 'Cambria', 12),
    (36, 2, N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 0, 0, 1, 1, 'Cambria', 12),
    (37, 2, N'DEPRECIACIÓN ACUMULADA DE VEHÍCULOS', 0, 0, 1, 1, 'Cambria', 12),
    (38, 2, N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 0, 0, 1, 1, 'Cambria', 12),
    (39, 2, N'DEPRECIACIÓN ACUMULADA DE MAQUINARIA Y EQUIPO', 0, 0, 1, 1, 'Cambria', 12),
    (40, 2, N'DEPRECIACIÓN ACUMULADA DE EQUIPO DE INFORMÁTICA', 0, 0, 1, 1, 'Cambria', 12),
    (41, 2, N'AMORTIZACIÓN DE ACTIVOS EVENTUALES', 0, 0, 1, 1, 'Cambria', 12),
    (42, 2, N'PROVISIONES EVENTUALES', 0, 0, 1, 1, 'Cambria', 12),
    (43, 2, N'PROVISIONES ESPECIALES', 0, 0, 1, 1, 'Cambria', 12),
    (44, 2, N'OTRAS PROVISIONES', 0, 0, 1, 1, 'Cambria', 12),
    (45, 3, N'TOTAL PASIVO', 0, 1, 0, 2, 'Cambria', 12),
    (46, 1, N'PATRIMONIO', 0, 1, 0, 1, 'Cambria', 12),
    (47, 2, N'APORTACIONES', 0, 0, 1, 1, 'Cambria', 12),
    (48, 2, N'CAPITALIZACIÓN DE EXCEDENTES', 0, 0, 1, 1, 'Cambria', 12),
    (49, 2, N'RESERVA LEGAL', 0, 0, 1, 1, 'Cambria', 12),
    (50, 2, N'RESERVAS ESTATURARIAS', 0, 0, 1, 1, 'Cambria', 12),
    (51, 2, N'EXCEDENTES ACUMULADOS', 0, 0, 1, 1, 'Cambria', 12),
    (52, 2, N'EXCEDENTE EL EJERCICIO', 0, 0, 1, 1, 'Cambria', 12),
    (53, 2, N'PÉRDIDA ACUMULADA', 0, 0, 1, 1, 'Cambria', 12),
    (54, 2, N'PÉRDIDA DEL EJERCICIO', 0, 0, 1, 1, 'Cambria', 12),
    (55, 3, N'TOTAL PATRIMONIO', 0, 0, 0, 2, 'Cambria', 12),
    (56, 3, N'TOTAL PASIVO MÁS PATRIMONIO', 0, 0, 0, 2, 'Cambria', 12);

DECLARE @PlantillaCuentas TABLE(
    OrdenDetalle int NOT NULL,
    CuentaContable varchar(50) NOT NULL,
    NombreCuenta nvarchar(500) NULL,
    Operacion int NOT NULL,
    OrdenCuenta int NOT NULL
);

INSERT INTO @PlantillaCuentas(OrdenDetalle, CuentaContable, NombreCuenta, Operacion, OrdenCuenta)
VALUES
    (2, '10101', N'CAJA', 1, 1),
    (3, '10102', N'BANCOS', 1, 1),
    (4, '10201', N'DEPOSITOS A PLAZO', 1, 1),
    (5, '10301', N'CARTERA DE PRÉSTAMOS', 1, 1),
    (6, '10401', N'DEUDORES VARIOS', 1, 1),
    (7, '10402', N'FUNCIONARIOS Y EMPLEADOS', 1, 1),
    (8, '10403', N'COOPERATIVISTAS', 1, 1),
    (9, '10404', N'CUENTAS VARIAS', 1, 1),
    (10, '10501', N'TERRENOS EVENTUALES', 1, 1),
    (11, '10502', N'EDIFICIOS EVENTUALES', 1, 1),
    (12, '10601', N'ACTIVOS PARA BIENES RAICES', 1, 1),
    (13, '10602', N'TERRENOS Y EDIFICIOS', 1, 1),
    (14, '10603', N'VEHÍCULOS', 1, 1),
    (15, '10604', N'MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (16, '10605', N'MAQUNARIA Y EQUIPO', 1, 1),
    (17, '10606', N'EQUIPO DE INFORMATICA', 1, 1),
    (18, '10701', N'PRIMAS DE SEGURO', 1, 1),
    (19, '10702', N'ESPECIES FISCALES', 1, 1),
    (20, '10703', N'OTROS CARGOS DIFERIDOS', 1, 1),
    (21, '10801', N'PROGRAMAS Y APLICACIONES INFORMÁTICAS', 1, 1),
    (22, '10101', N'CAJA', 1, 1),
    (22, '10102', N'BANCOS', 1, 1),
    (22, '10201', N'DEPOSITOS A PLAZO', 1, 1),
    (22, '10301', N'CARTERA DE PRÉSTAMOS', 1, 1),
    (22, '10401', N'DEUDORES VARIOS', 1, 1),
    (22, '10402', N'FUNCIONARIOS Y EMPLEADOS', 1, 1),
    (22, '10403', N'COOPERATIVISTAS', 1, 1),
    (22, '10404', N'CUENTAS VARIAS', 1, 1),
    (22, '10501', N'TERRENOS EVENTUALES', 1, 1),
    (22, '10502', N'EDIFICIOS EVENTUALES', 1, 1),
    (22, '10601', N'ACTIVOS PARA BIENES RAICES', 1, 1),
    (22, '10602', N'TERRENOS Y EDIFICIOS', 1, 1),
    (22, '10603', N'VEHÍCULOS', 1, 1),
    (22, '10604', N'MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (22, '10605', N'MAQUNARIA Y EQUIPO', 1, 1),
    (22, '10606', N'EQUIPO DE INFORMATICA', 1, 1),
    (22, '10701', N'PRIMAS DE SEGURO', 1, 1),
    (22, '10702', N'ESPECIES FISCALES', 1, 1),
    (22, '10703', N'OTROS CARGOS DIFERIDOS', 1, 1),
    (22, '10801', N'PROGRAMAS Y APLICACIONES INFORMÁTICAS', 1, 1),
    (24, '20101', N'ACREEDORES VARIOS', 1, 1),
    (25, '20102', N'SUELDOS POR PAGAR', 1, 1),
    (26, '20103', N'SERVICIOS PUBLICOS', 1, 1),
    (27, '20104', N'CUENTAS VARIAS', 1, 1),
    (28, '20105', N'EXCEDENTES POR DISTRIBUIR', 1, 1),
    (29, '20106', N'INTERESES POR PAGAR ', 1, 1),
    (30, '20201', N'AHORROS NAVIDEÑOS', 1, 1),
    (31, '20202', N'AHORROS RETIRABLES', 1, 1),
    (32, '20203', N'DEPOSITOS A PLAZO', 1, 1),
    (33, '20301', N'PRÉSTAMOS POR PAGAR', 1, 1),
    (34, '20401', N'PROVISION PARA CREDITOS DUDOSOS', 1, 1),
    (35, '20402', N'PROVISION PARA INTERESES DUDOSOS', 1, 1),
    (36, '20403', N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 1, 1),
    (37, '20405', N'DEPRECIACIÓN ACUMULADA DEVEHÍCULOS', 1, 1),
    (38, '20406', N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (39, '20407', N'DEPRECIACIÓN ACUMULADA DE MAQUNARIA Y EQUIPO', 1, 1),
    (40, '20408', N'DEPRECIACIÓN ACUMULADA DE EQUIPO DE INFORMATICA', 1, 1),
    (41, '20409', N'AMORTIZACION DE ACTIVOS EVENTUALES', 1, 1),
    (42, '20501', N'PROVISIONES EVENTUALES', 1, 1),
    (43, '20502', N'PROVISIONES ESPECIALES', 1, 1),
    (44, '20503', N'OTRAS PROVISIONES', 1, 1),
    (45, '20101', N'ACREEDORES VARIOS', 1, 1),
    (45, '20102', N'SUELDOS POR PAGAR', 1, 1),
    (45, '20103', N'SERVICIOS PUBLICOS', 1, 1),
    (45, '20104', N'CUENTAS VARIAS', 1, 1),
    (45, '20105', N'EXCEDENTES POR DISTRIBUIR', 1, 1),
    (45, '20106', N'INTERESES POR PAGAR ', 1, 1),
    (45, '20201', N'AHORROS NAVIDEÑOS', 1, 1),
    (45, '20202', N'AHORROS RETIRABLES', 1, 1),
    (45, '20203', N'DEPOSITOS A PLAZO', 1, 1),
    (45, '20301', N'PRÉSTAMOS POR PAGAR', 1, 1),
    (45, '20401', N'PROVISION PARA CREDITOS DUDOSOS', 1, 1),
    (45, '20402', N'PROVISION PARA INTERESES DUDOSOS', 1, 1),
    (45, '20403', N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 1, 1),
    (45, '20405', N'DEPRECIACIÓN ACUMULADA DEVEHÍCULOS', 1, 1),
    (45, '20406', N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (45, '20407', N'DEPRECIACIÓN ACUMULADA DE MAQUNARIA Y EQUIPO', 1, 1),
    (45, '20408', N'DEPRECIACIÓN ACUMULADA DE EQUIPO DE INFORMATICA', 1, 1),
    (45, '20409', N'AMORTIZACION DE ACTIVOS EVENTUALES', 1, 1),
    (45, '20501', N'PROVISIONES EVENTUALES', 1, 1),
    (45, '20502', N'PROVISIONES ESPECIALES', 1, 1),
    (45, '20503', N'OTRAS PROVISIONES', 1, 1),
    (47, '30101', N'APORTACIONES', 1, 1),
    (47, '30102', N'CAPITALIZACIÓN DE EXCEDENTES', 1, 1),
    (47, '30103', N'DONACIONES', 1, 1),
    (48, '30102', N'CAPITALIZACIÓN DE EXCEDENTES', 1, 1),
    (49, '30201', N'RESERVA LEGAL', 1, 1),
    (50, '30202', N'RESERVAS ESTATURARIAS', 1, 1),
    (51, '30301', N'EXCEDENTES ACUMULADOS', 1, 1),
    (52, '30302', N'EXCEDENTE EL EJERCICIO', 1, 1),
    (53, '30303', N'PÉRDIDA ACUMULADA', 2, 1),
    (54, '30304', N'PÉRDIDA DEL EJERCICIO', 2, 1),
    (55, '30101', N'APORTACIONES', 1, 1),
    (55, '30102', N'CAPITALIZACIÓN DE EXCEDENTES', 1, 1),
    (55, '30103', N'DONACIONES', 1, 1),
    (55, '30201', N'RESERVA LEGAL', 1, 1),
    (55, '30202', N'RESERVAS ESTATURARIAS', 1, 1),
    (55, '30301', N'EXCEDENTES ACUMULADOS', 1, 1),
    (55, '30302', N'EXCEDENTE EL EJERCICIO', 1, 1),
    (55, '30303', N'PÉRDIDA ACUMULADA', 2, 1),
    (55, '30304', N'PÉRDIDA DEL EJERCICIO', 2, 1),
    (56, '20101', N'ACREEDORES VARIOS', 1, 1),
    (56, '20102', N'SUELDOS POR PAGAR', 1, 1),
    (56, '20103', N'SERVICIOS PUBLICOS', 1, 1),
    (56, '20104', N'CUENTAS VARIAS', 1, 1),
    (56, '20105', N'EXCEDENTES POR DISTRIBUIR', 1, 1),
    (56, '20106', N'INTERESES POR PAGAR ', 1, 1),
    (56, '20201', N'AHORROS NAVIDEÑOS', 1, 1),
    (56, '20202', N'AHORROS RETIRABLES', 1, 1),
    (56, '20203', N'DEPOSITOS A PLAZO', 1, 1),
    (56, '20301', N'PRÉSTAMOS POR PAGAR', 1, 1),
    (56, '20401', N'PROVISION PARA CREDITOS DUDOSOS', 1, 1),
    (56, '20402', N'PROVISION PARA INTERESES DUDOSOS', 1, 1),
    (56, '20403', N'DEPRECIACIÓN ACUMULADA DE EDIFICIOS', 1, 1),
    (56, '20405', N'DEPRECIACIÓN ACUMULADA DEVEHÍCULOS', 1, 1),
    (56, '20406', N'DEPRECIACIÓN ACUMULADA DE MOBILIARIO Y EQUIPO DE OFICINA', 1, 1),
    (56, '20407', N'DEPRECIACIÓN ACUMULADA DE MAQUNARIA Y EQUIPO', 1, 1),
    (56, '20408', N'DEPRECIACIÓN ACUMULADA DE EQUIPO DE INFORMATICA', 1, 1),
    (56, '20409', N'AMORTIZACION DE ACTIVOS EVENTUALES', 1, 1),
    (56, '20501', N'PROVISIONES EVENTUALES', 1, 1),
    (56, '20502', N'PROVISIONES ESPECIALES', 1, 1),
    (56, '20503', N'OTRAS PROVISIONES', 1, 1),
    (56, '30101', N'APORTACIONES', 1, 1),
    (56, '30102', N'CAPITALIZACIÓN DE EXCEDENTES', 1, 1),
    (56, '30103', N'DONACIONES', 1, 1),
    (56, '30201', N'RESERVA LEGAL', 1, 1),
    (56, '30202', N'RESERVAS ESTATURARIAS', 1, 1),
    (56, '30301', N'EXCEDENTES ACUMULADOS', 1, 1),
    (56, '30302', N'EXCEDENTE EL EJERCICIO', 1, 1),
    (56, '30303', N'PÉRDIDA ACUMULADA', 2, 1),
    (56, '30304', N'PÉRDIDA DEL EJERCICIO', 2, 1);

DECLARE @Empresas TABLE(IdEmpresa int NOT NULL PRIMARY KEY);

INSERT INTO @Empresas(IdEmpresa)
SELECT DISTINCT IdEmpresa
FROM dbo.CR_CuentasContables
WHERE Eliminado = 0
UNION
SELECT DISTINCT IdEmpresa
FROM dbo.CR_EstadosFinancieros
WHERE Eliminado = 0;

DECLARE @IdEmpresa int, @IdEstadoFinanciero int;
DECLARE empresas_cursor CURSOR LOCAL FAST_FORWARD FOR SELECT IdEmpresa FROM @Empresas ORDER BY IdEmpresa;
OPEN empresas_cursor;
FETCH NEXT FROM empresas_cursor INTO @IdEmpresa;

WHILE @@FETCH_STATUS = 0
BEGIN
    SET @IdEstadoFinanciero = NULL;

    SELECT TOP (1) @IdEstadoFinanciero = IdEstadoFinanciero
    FROM dbo.CR_EstadosFinancieros
    WHERE IdEmpresa = @IdEmpresa
      AND Eliminado = 0
      AND (
          UPPER(ISNULL(Codigo, '')) = UPPER(ISNULL(@CodigoBalance, ''))
          OR UPPER(ISNULL(Nombre, '')) COLLATE Latin1_General_CI_AI LIKE '%BALANCE%GENERAL%'
          OR UPPER(ISNULL(Titulo, '')) COLLATE Latin1_General_CI_AI LIKE '%BALANCE%GENERAL%'
      )
    ORDER BY CASE WHEN UPPER(ISNULL(Codigo, '')) = UPPER(ISNULL(@CodigoBalance, '')) THEN 0 ELSE 1 END,
             IdEstadoFinanciero;

    IF @IdEstadoFinanciero IS NULL
    BEGIN
        INSERT INTO dbo.CR_EstadosFinancieros(IdEmpresa, Codigo, Nombre, Titulo, Subtitulo, Tipo, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
        VALUES(@IdEmpresa, @CodigoBalance, @NombreBalance, @TituloBalance, @SubtituloBalance, @TipoBalance, 0, @UsuarioActualizacion, @FechaActualizacion, @EquipoActualizacion, 0, NULL);
        SET @IdEstadoFinanciero = SCOPE_IDENTITY();
    END
    ELSE
    BEGIN
        UPDATE dbo.CR_EstadosFinancieros
        SET Codigo = @CodigoBalance,
            Nombre = @NombreBalance,
            Titulo = @TituloBalance,
            Subtitulo = @SubtituloBalance,
            Tipo = @TipoBalance,
            Eliminado = 0,
            Usuario = @UsuarioActualizacion,
            FechaHora = @FechaActualizacion,
            NombreEquipo = @EquipoActualizacion,
            Sincronizado = 0,
            FechaHoraSincronizacion = NULL
        WHERE IdEmpresa = @IdEmpresa
          AND IdEstadoFinanciero = @IdEstadoFinanciero;
    END

    UPDATE C
    SET Eliminado = 1,
        Usuario = @UsuarioActualizacion,
        FechaHora = @FechaActualizacion,
        NombreEquipo = @EquipoActualizacion,
        Sincronizado = 0,
        FechaHoraSincronizacion = NULL
    FROM dbo.CR_EstadosFinancierosDetalleCuentas C
    INNER JOIN dbo.CR_EstadosFinancierosDetalle D
            ON D.IdEstadoFinancieroDetalle = C.IdEstadoFinancieroDetalle
           AND D.IdEmpresa = C.IdEmpresa
    WHERE D.IdEmpresa = @IdEmpresa
      AND D.IdEstadoFinanciero = @IdEstadoFinanciero
      AND C.Eliminado = 0;

    UPDATE dbo.CR_EstadosFinancierosDetalle
    SET Eliminado = 1,
        Usuario = @UsuarioActualizacion,
        FechaHora = @FechaActualizacion,
        NombreEquipo = @EquipoActualizacion,
        Sincronizado = 0,
        FechaHoraSincronizacion = NULL
    WHERE IdEmpresa = @IdEmpresa
      AND IdEstadoFinanciero = @IdEstadoFinanciero
      AND Eliminado = 0;

    DECLARE @DetalleMap TABLE(Orden int NOT NULL PRIMARY KEY, IdEstadoFinancieroDetalle int NOT NULL);

    INSERT INTO dbo.CR_EstadosFinancierosDetalle(IdEstadoFinanciero, IdEmpresa, Orden, ParametroLinea, Descripcion, Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
    OUTPUT inserted.Orden, inserted.IdEstadoFinancieroDetalle INTO @DetalleMap(Orden, IdEstadoFinancieroDetalle)
    SELECT @IdEstadoFinanciero, @IdEmpresa, Orden, ParametroLinea, CONVERT(varchar(500), Descripcion), Subtitulo, Negrita, Tabulacion, Columna, Fuente, Size, 0, @UsuarioActualizacion, @FechaActualizacion, @EquipoActualizacion, 0, NULL
    FROM @PlantillaDetalle
    ORDER BY Orden;

    ;WITH CuentasDestino AS (
        SELECT IdCuentaContable,
               CuentaContable,
               ROW_NUMBER() OVER(PARTITION BY CuentaContable ORDER BY CASE WHEN Operable = 1 THEN 0 ELSE 1 END, IdCuentaContable) AS Fila
        FROM dbo.CR_CuentasContables
        WHERE IdEmpresa = @IdEmpresa
          AND Eliminado = 0
    )
    INSERT INTO dbo.CR_EstadosFinancierosDetalleCuentas(IdEstadoFinancieroDetalle, IdEmpresa, IdCuentaContable, CuentaContable, NombreCuenta, Operacion, Orden, Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion)
    SELECT M.IdEstadoFinancieroDetalle,
           @IdEmpresa,
           C.IdCuentaContable,
           P.CuentaContable,
           CONVERT(varchar(500), P.NombreCuenta),
           P.Operacion,
           P.OrdenCuenta,
           0,
           @UsuarioActualizacion,
           @FechaActualizacion,
           @EquipoActualizacion,
           0,
           NULL
    FROM @PlantillaCuentas P
    INNER JOIN @DetalleMap M ON M.Orden = P.OrdenDetalle
    INNER JOIN CuentasDestino C ON C.CuentaContable = P.CuentaContable AND C.Fila = 1
    ORDER BY P.OrdenDetalle, P.OrdenCuenta, P.CuentaContable;

    FETCH NEXT FROM empresas_cursor INTO @IdEmpresa;
END

CLOSE empresas_cursor;
DEALLOCATE empresas_cursor;
GO
