IF OBJECT_ID(N'dbo.CR_AsientosMayorizacion_ReporteEstadoFinanciero', N'P') IS NOT NULL
BEGIN
    DROP PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero];
END
GO


CREATE PROCEDURE [dbo].[CR_AsientosMayorizacion_ReporteEstadoFinanciero]
	@IdEmpresa int = 1,
	@Anio int = 2025,
	@Mes varchar(100) = '5,6,7',
	@IdEstadoFinanciero int = 1
AS
BEGIN
	SET LANGUAGE Spanish

	DECLARE @UltimoMes int, @Sql varchar(MAX)

	SELECT @UltimoMes = MAX(Value) FROM [dbo].[SplitString](@Mes,',')

	DECLARE @Fecha DATE = CONVERT(varchar(5),@Anio) + '-'+ CONVERT(varchar(4),@UltimoMes) + '-20'
	DECLARE @Dia int, @MesLetra varchar(50)
	DECLARE @Var_Meses VARCHAR(MAX)

	SET @Dia = DATEPART(DAY,EOMONTH(@Fecha))
	SET @MesLetra = DATENAME(MONTH,@Fecha)

	SET @Var_Meses =REPLACE(@Mes, ',',''',''')

	SET @Sql = '
		SELECT C.Titulo,
			   CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END Acumulado,
			   B.ParametroLinea,
			   B.Negrita,
			   B.Tabulacion,
			   B.Columna,
			   B.Fuente,
			   B.Size,
			   REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion NombreCuenta,
			   B.Orden,
			   '''+ CONVERT(varchar(10),@Anio) +''' Anio,
			   '''+ CONVERT(varchar(10),@UltimoMes) +'''  Mes,
			   SUM(D.SaldoAnterior) SaldoAnterior,
			   CASE WHEN B.ParametroLinea = 1 THEN NULL ELSE SUM(ISNULL(CASE WHEN C.Tipo = ''Acumulado'' THEN CASE WHEN A.Operacion = 2 THEN D.Saldo * -1 ELSE D.Saldo END ELSE CASE WHEN A.Operacion = 2 THEN D.SaldoActual * -1 ELSE D.SaldoActual END END,0)) END Saldo,
			   B.Subtitulo,
			   '''+ CONVERT(varchar(10),@Dia) +''' DiaFinalMes,
			   '''+ CONVERT(varchar(10),@MesLetra) +''' MesLetra,
			   E.NombreCR
		FROM CR_EstadosFinancierosDetalle B 
			 LEFT JOIN CR_EstadosFinancierosDetalleCuentas A ON B.IdEstadoFinancieroDetalle = A.IdEstadoFinancieroDetalle AND A.Eliminado = 0
			 LEFT JOIN CR_EstadosFinancieros C ON C.IdEstadoFinanciero = B.IdEstadoFinanciero
			 LEFT JOIN CR_AsientosMayorizacion D ON D.IdCuentaContable = A.IdCuentaContable AND D.IdEmpresa = A.IdEmpresa AND D.Anio = '''+convert(varchar(10),@Anio)+''' AND D.Mes IN ('''+@Var_Meses+''') AND D.Eliminado = 0 
			 LEFT JOIN AD_Empresas E ON E.IdEmpresa = B.IdEmpresa
		WHERE B.Eliminado = 0
			  AND B.IdEmpresa = '''+convert(varchar(10),@IdEmpresa)+'''
			  AND C.IdEstadoFinanciero = '''+convert(varchar(10),@IdEstadoFinanciero)+'''   
		GROUP BY C.Titulo,
			   CASE WHEN C.Tipo = ''Acumulado'' THEN CONVERT(bit,1) ELSE CONVERT(bit,0) END,
			   B.ParametroLinea,
			   B.Negrita,
			   B.Tabulacion,
			   B.Columna,
			   B.Fuente,
			   B.Size,
			   REPLICATE(CHAR(9),B.Tabulacion) + B.Descripcion,
			   B.Orden,
			   B.Subtitulo,
			   E.NombreCR
		Order by B.Orden
	'

	EXEC(@Sql)

	

END
GO
