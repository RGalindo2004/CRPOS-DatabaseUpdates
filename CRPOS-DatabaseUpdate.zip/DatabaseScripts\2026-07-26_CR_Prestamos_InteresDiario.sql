/*
    Calcula los intereses por días reales transcurridos sobre el saldo de capital.
    Conserva la base financiera de 360 días que ya usa CRPOS.
*/
SET XACT_ABORT ON;
GO

IF COL_LENGTH(N'dbo.CR_Prestamos', N'FechaBaseInteres') IS NULL
    ALTER TABLE dbo.CR_Prestamos ADD FechaBaseInteres DATE NULL;
GO

IF OBJECT_ID(N'dbo.fn_CR_Prestamos_InteresDiario', N'FN') IS NULL
    EXEC(N'CREATE FUNCTION dbo.fn_CR_Prestamos_InteresDiario(@IdPrestamo INT, @FechaCalculo DATE) RETURNS DECIMAL(18, 2) AS BEGIN RETURN 0; END');
GO

ALTER FUNCTION [dbo].[fn_CR_Prestamos_InteresDiario]
(
    @IdPrestamo INT,
    @FechaCalculo DATE
)
RETURNS DECIMAL(18, 2)
AS
BEGIN
    DECLARE @FechaInicio DATE,
            @FechaBaseInteres DATE,
            @FechaUltimoAbono DATE,
            @SaldoCapital DECIMAL(18, 2),
            @SaldoInteresAnterior DECIMAL(18, 2) = 0,
            @TasaInteres DECIMAL(18, 6),
            @Dias INT;

    SELECT @FechaInicio = prestamo.FechaInicio,
           @FechaBaseInteres = prestamo.FechaBaseInteres,
           @SaldoCapital = prestamo.SaldoCapital,
           @TasaInteres = prestamo.TasaInteres
    FROM dbo.CR_Prestamos prestamo
    WHERE prestamo.IdPrestamo = @IdPrestamo
      AND prestamo.Eliminado = 0;

    IF @FechaInicio IS NULL OR @FechaCalculo IS NULL
        RETURN 0;

    SELECT @FechaUltimoAbono = MAX(CONVERT(DATE, movimiento.FechaMovimiento))
    FROM dbo.CR_MovimientosPrestamos movimiento
    INNER JOIN dbo.CR_TiposMovimientosPrestamos tipoMovimiento
        ON tipoMovimiento.IdTipoMovimientoPrestamo = movimiento.IdTipoMovimientoPrestamo
    WHERE movimiento.IdPrestamo = @IdPrestamo
      AND movimiento.Eliminado = 0
      AND movimiento.Reversado = 0
      AND movimiento.EsReversion = 0
      AND tipoMovimiento.EsAbono = 1
      AND CONVERT(DATE, movimiento.FechaMovimiento) <= @FechaCalculo;

    SET @FechaUltimoAbono = COALESCE(@FechaUltimoAbono, @FechaBaseInteres, @FechaInicio);
    IF @FechaBaseInteres IS NOT NULL AND @FechaBaseInteres > @FechaUltimoAbono
        SET @FechaUltimoAbono = @FechaBaseInteres;
    SET @Dias = CASE
                    WHEN @FechaCalculo > @FechaUltimoAbono
                        THEN DATEDIFF(DAY, @FechaUltimoAbono, @FechaCalculo)
                    ELSE 0
                END;

    SELECT TOP (1)
           @SaldoInteresAnterior = COALESCE(detalle.SaldoInteres, 0)
    FROM dbo.CR_PrestamosDetalle detalle
    WHERE detalle.IdPrestamo = @IdPrestamo
      AND detalle.Cancelada = 0
      AND detalle.Eliminado = 0
    ORDER BY detalle.FechaCuota, detalle.NumeroCuota;

    RETURN ROUND(
        COALESCE(@SaldoInteresAnterior, 0)
        + COALESCE(@SaldoCapital, 0) * COALESCE(@TasaInteres, 0) / 100.0 / 360.0 * @Dias,
        2
    );
END;
GO

IF OBJECT_ID(N'dbo.FN_CR_Asientos_Prestamos_AbonoCuota', N'TF') IS NULL
    EXEC(N'CREATE FUNCTION dbo.FN_CR_Asientos_Prestamos_AbonoCuota(@IdEmpresa INT, @IdTipoAsiento INT, @Desde DATE, @Hasta DATE)
           RETURNS @Asientos TABLE
           (
               Fecha DATE,
               IdCuentaContable INT,
               CuentaContable VARCHAR(MAX),
               NombreCuentaContable VARCHAR(MAX),
               MontoDebito NUMERIC(18, 6),
               MontoCredito NUMERIC(18, 6)
           )
           AS BEGIN RETURN; END');
GO

ALTER FUNCTION [dbo].[FN_CR_Asientos_Prestamos_AbonoCuota]
(
    @IdEmpresa INT,
    @IdTipoAsiento INT,
    @Desde DATE,
    @Hasta DATE
)
RETURNS @Asientos TABLE
(
    Fecha DATE,
    IdCuentaContable INT,
    CuentaContable VARCHAR(MAX),
    NombreCuentaContable VARCHAR(MAX),
    MontoDebito NUMERIC(18, 6),
    MontoCredito NUMERIC(18, 6)
)
AS
BEGIN
    INSERT INTO @Asientos
    (
        Fecha, IdCuentaContable, CuentaContable, NombreCuentaContable,
        MontoDebito, MontoCredito
    )
    SELECT CONVERT(DATE, movimiento.FechaMovimiento),
           cuenta.IdCuentaContable,
           cuenta.CuentaContable,
           cuenta.Nombre,
           SUM(CASE
                   WHEN (movimiento.EsReversion = 0 AND plantilla.Debito = 1)
                     OR (movimiento.EsReversion = 1 AND plantilla.Debito = 0)
                       THEN concepto.Monto
                   ELSE 0
               END),
           SUM(CASE
                   WHEN (movimiento.EsReversion = 0 AND plantilla.Debito = 0)
                     OR (movimiento.EsReversion = 1 AND plantilla.Debito = 1)
                       THEN concepto.Monto
                   ELSE 0
               END)
    FROM dbo.CR_MovimientosPrestamos movimiento
    INNER JOIN dbo.CR_TiposMovimientosPrestamos tipoMovimiento
        ON tipoMovimiento.IdTipoMovimientoPrestamo = movimiento.IdTipoMovimientoPrestamo
       AND tipoMovimiento.EsAbono = 1
    INNER JOIN dbo.CR_Prestamos prestamo
        ON prestamo.IdPrestamo = movimiento.IdPrestamo
       AND prestamo.IdEmpresa = movimiento.IdEmpresa
    INNER JOIN dbo.CR_TiposPrestamos tipoPrestamo
        ON tipoPrestamo.IdTipoPrestamo = prestamo.IdTipoPrestamo
       AND tipoPrestamo.IdEmpresa = prestamo.IdEmpresa
    CROSS APPLY
    (
        VALUES
            ('004-001', ABS(movimiento.MontoCapital), NULLIF(LTRIM(RTRIM(tipoPrestamo.CuentaContable)), '')),
            ('004-002', ABS(movimiento.MontoInteres), NULLIF(LTRIM(RTRIM(tipoPrestamo.CuentaContableIntereses)), '')),
            ('004-003', ABS(movimiento.MontoCapital + movimiento.MontoInteres + movimiento.MontoMora), NULL),
            ('004-004', ABS(movimiento.MontoMora), NULL)
    ) concepto(Codigo, Monto, CuentaTipoPrestamo)
    INNER JOIN dbo.CR_TipoAsientoCuentasContables plantilla
        ON plantilla.IdTipoAsiento = @IdTipoAsiento
       AND plantilla.IdEmpresa = @IdEmpresa
       AND plantilla.Codigo = concepto.Codigo
    OUTER APPLY
    (
        SELECT TOP (1)
               cuentaCandidata.IdCuentaContable,
               cuentaCandidata.CuentaContable,
               cuentaCandidata.Nombre
        FROM dbo.CR_CuentasContables cuentaCandidata
        WHERE cuentaCandidata.IdEmpresa = @IdEmpresa
          AND
          (
              cuentaCandidata.CuentaContable = concepto.CuentaTipoPrestamo
              OR cuentaCandidata.IdCuentaContable = plantilla.IdCuentaContable
          )
        ORDER BY CASE
                     WHEN cuentaCandidata.CuentaContable = concepto.CuentaTipoPrestamo THEN 0
                     ELSE 1
                 END
    ) cuenta
    WHERE movimiento.IdEmpresa = @IdEmpresa
      AND movimiento.Eliminado = 0
      AND CONVERT(DATE, movimiento.FechaMovimiento) BETWEEN @Desde AND @Hasta
      AND concepto.Monto > 0
      AND cuenta.IdCuentaContable IS NOT NULL
    GROUP BY CONVERT(DATE, movimiento.FechaMovimiento),
             cuenta.IdCuentaContable,
             cuenta.CuentaContable,
             cuenta.Nombre;

    RETURN;
END;
GO

ALTER PROCEDURE [dbo].[CR_Prestamos_VisorPorIdPrestamo]
    @IdPrestamo INT
AS
BEGIN
    SET NOCOUNT ON;

    DECLARE @FechaCalculo DATE = CONVERT(DATE, GETDATE());

    SELECT prestamo.IdPrestamo,
           prestamo.TasaInteres,
           prestamo.ValorFijoInteres,
           prestamo.TasaMora,
           prestamo.MontoPrestamo,
           prestamo.SaldoCapital,
           prestamo.ValorFijoMoratorio,
           prestamo.UsaTasaInteres,
           prestamo.UsaTasaMoratoria,
           prestamo.NumeroCuotas,
           prestamo.FechaInicio,
           prestamo.FechaFin,
           afiliado.CodigoAfiliado,
           afiliado.Nombres + ' ' + afiliado.Apellidos AS NombreAfiliado,
           frecuencia.Nombre AS FrecuenciaPago,
           tipoPrestamo.Nombre AS TipoPrestamo,
           tipoCalculo.Nombre AS TipoCalculo,
           estado.NombreEstado AS EstadoPrestamo,
           prestamo.Observaciones,
           prestamo.Usuario,
           afiliado.TelefonoPrincipal,
           afiliado.TelefonoCelular,
           afiliado.DireccionAfiliado,
           afiliado.NumeroIdentificacion,
           prestamo.MontoPrestamo - prestamo.SaldoCapital AS PagoCapital,
           detalle.CuotasVencidas,
           detalle.CuotasPendientes,
           detalle.SiguienteCuota,
           ultimoPago.Fecha AS UltimoPago,
           CASE
               WHEN prestamo.SaldoCapital = 0 THEN 'FINALIZADO'
               WHEN detalle.CuotasVencidas = 0 THEN 'AL DIA'
               WHEN detalle.CuotasVencidas < detalle.CuotasPendientes THEN 'EN MORA'
               ELSE 'VENCIDO'
           END AS SubEstado,
           CASE
               WHEN prestamo.UsaTasaInteres = 1
                   THEN dbo.fn_CR_Prestamos_InteresDiario(prestamo.IdPrestamo, @FechaCalculo)
               ELSE detalle.InteresPendiente
           END AS InteresPendientePrestamo,
           dbo.fn_CR_Prestamos_CalcularMoraTotal(prestamo.IdPrestamo) AS MoraTotalPrestamo,
           DATEDIFF(DAY, ultimoPago.Fecha, @FechaCalculo) AS DiasUltimoMovimiento,
           CONVERT(DECIMAL(10, 2), DATEDIFF(DAY, ultimoPago.Fecha, @FechaCalculo)) AS FrecuenciaDias,
           detalle.IdPrestamoSiguienteCuota,
           CASE
               WHEN prestamo.TasaInteres > 0
                AND DATEDIFF(DAY, ultimoPago.Fecha, @FechaCalculo) = 0
                AND detalle.CuotasVencidas = 0
                AND detalle.SiguienteCuota > @FechaCalculo
                   THEN CONVERT(BIT, 1)
               ELSE CONVERT(BIT, 0)
           END AS PermiteAbonoCapital
    FROM dbo.CR_Prestamos prestamo
    INNER JOIN dbo.V_CR_Afiliados afiliado
        ON afiliado.IdAfiliado = prestamo.IdAfiliado
    INNER JOIN dbo.CR_TiposPrestamos tipoPrestamo
        ON tipoPrestamo.IdTipoPrestamo = prestamo.IdTipoPrestamo
    INNER JOIN dbo.CR_TipoCalculosPrestamos tipoCalculo
        ON tipoCalculo.IdTipoCalculoPrestamo = prestamo.IdTipoCalculoPrestamo
    INNER JOIN dbo.CR_EstadosPrestamos estado
        ON estado.IdEstadoPrestamo = prestamo.IdEstadoPrestamo
    INNER JOIN dbo.CR_FrecuenciasPagosPrestamos frecuencia
        ON frecuencia.IdFrecuenciaPagoPrestamo = prestamo.IdFrecuenciaPago
    OUTER APPLY
    (
        SELECT COUNT(*) AS CuotasPendientes,
               COALESCE(SUM(CASE WHEN d.FechaCuota < @FechaCalculo THEN 1 ELSE 0 END), 0) AS CuotasVencidas,
               MIN(d.FechaCuota) AS SiguienteCuota,
               MIN(d.IdPrestamoDetalle) AS IdPrestamoSiguienteCuota,
               SUM(COALESCE(d.SaldoInteres, d.InteresProyectado - d.InteresCobrado, 0)) AS InteresPendiente
        FROM dbo.CR_PrestamosDetalle d
        WHERE d.IdPrestamo = prestamo.IdPrestamo
          AND d.Cancelada = 0
          AND d.Eliminado = 0
    ) detalle
    OUTER APPLY
    (
        SELECT COALESCE(
                   MAX(CONVERT(DATE, movimiento.FechaMovimiento)),
                   prestamo.FechaInicio
               ) AS Fecha
        FROM dbo.CR_MovimientosPrestamos movimiento
        INNER JOIN dbo.CR_TiposMovimientosPrestamos tipoMovimiento
            ON tipoMovimiento.IdTipoMovimientoPrestamo = movimiento.IdTipoMovimientoPrestamo
        WHERE movimiento.IdPrestamo = prestamo.IdPrestamo
          AND movimiento.Eliminado = 0
          AND movimiento.Reversado = 0
          AND movimiento.EsReversion = 0
          AND tipoMovimiento.EsAbono = 1
    ) ultimoPago
    WHERE prestamo.Readecuado = 0
      AND prestamo.Eliminado = 0
      AND prestamo.IdPrestamo = @IdPrestamo;
END;
GO

ALTER PROCEDURE [dbo].[CR_PrestamosDetalle_SiguienteCuota]
    @IdPrestamo INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (1)
           detalle.IdPrestamoDetalle,
           detalle.IdEmpresa,
           detalle.IdPrestamo,
           detalle.NumeroCuota,
           detalle.FechaCuota,
           detalle.FechaPagoPrestamo,
           detalle.MontoCapitalBase,
           detalle.InteresProyectado,
           detalle.SaldoCapital,
           detalle.InteresCobrado,
           detalle.MoraCuota,
           detalle.AbonoCapital,
           detalle.CuotaVencida,
           mora.DiasMora,
           mora.Moradiaria,
           detalle.MoraCuota AS ValorMora,
           detalle.SaldoCapital
               + CASE
                     WHEN prestamo.UsaTasaInteres = 1
                         THEN dbo.fn_CR_Prestamos_InteresDiario(detalle.IdPrestamo, CONVERT(DATE, GETDATE()))
                     ELSE COALESCE(detalle.SaldoInteres, detalle.InteresProyectado)
                 END AS MontoCuota,
           CASE
               WHEN prestamo.UsaTasaInteres = 1
                   THEN dbo.fn_CR_Prestamos_InteresDiario(detalle.IdPrestamo, CONVERT(DATE, GETDATE()))
               ELSE detalle.SaldoInteres
           END AS SaldoInteres
    FROM dbo.CR_PrestamosDetalle detalle
    INNER JOIN dbo.CR_Prestamos prestamo
        ON prestamo.IdPrestamo = detalle.IdPrestamo
    CROSS APPLY dbo.fn_CR_PrestamosDetalle_MoraCuota(detalle.IdPrestamoDetalle) mora
    WHERE detalle.IdPrestamo = @IdPrestamo
      AND detalle.Cancelada = 0
      AND detalle.Eliminado = 0
    ORDER BY detalle.NumeroCuota;
END;
GO

ALTER PROCEDURE [dbo].[CR_MovimientosPrestamos_Abonar]
    @IdPrestamo INT,
    @IdPrestamoSiguienteCuota INT,
    @Abonar DECIMAL(10, 2),
    @PagoMora DECIMAL(10, 2),
    @Referencia VARCHAR(200),
    @Capital DECIMAL(10, 2),
    @Intereses DECIMAL(10, 2),
    @Usuario VARCHAR(50),
    @Equipo VARCHAR(200),
    @FechaBase DATE,
    @FechaContabilizacion DATE,
    @Abono_Pago DECIMAL(18, 2),
    @Abono_Cambio DECIMAL(18, 2),
    @SoloPagoCapital BIT,
    @IdMovimientoPrestamo INT OUTPUT,
    @HayError BIT OUTPUT,
    @Mensaje VARCHAR(200) OUTPUT
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    SET @Mensaje = 'Generación correcta';
    SET @HayError = 0;

    BEGIN TRY
        IF @FechaContabilizacion IS NULL
            THROW 51301, 'La fecha del abono es obligatoria.', 1;

        DECLARE @UsaTasaInteres BIT,
                @FechaInicio DATE,
                @FechaBaseInteres DATE,
                @UltimoAbono DATE;

        SELECT @UsaTasaInteres = prestamo.UsaTasaInteres,
               @FechaInicio = prestamo.FechaInicio,
               @FechaBaseInteres = prestamo.FechaBaseInteres
        FROM dbo.CR_Prestamos prestamo
        WHERE prestamo.IdPrestamo = @IdPrestamo
          AND prestamo.Eliminado = 0;

        IF @FechaInicio IS NULL
            THROW 51302, 'El préstamo no existe o está eliminado.', 1;

        SELECT @UltimoAbono = MAX(CONVERT(DATE, movimiento.FechaMovimiento))
        FROM dbo.CR_MovimientosPrestamos movimiento
        INNER JOIN dbo.CR_TiposMovimientosPrestamos tipoMovimiento
            ON tipoMovimiento.IdTipoMovimientoPrestamo = movimiento.IdTipoMovimientoPrestamo
        WHERE movimiento.IdPrestamo = @IdPrestamo
          AND movimiento.Eliminado = 0
          AND movimiento.Reversado = 0
          AND movimiento.EsReversion = 0
          AND tipoMovimiento.EsAbono = 1;

        SET @UltimoAbono = COALESCE(@UltimoAbono, @FechaBaseInteres, @FechaInicio);
        IF @FechaBaseInteres IS NOT NULL AND @FechaBaseInteres > @UltimoAbono
            SET @UltimoAbono = @FechaBaseInteres;

        IF @FechaContabilizacion < COALESCE(@UltimoAbono, @FechaInicio)
            THROW 51303, 'La fecha del abono no puede ser anterior al último movimiento del préstamo.', 1;

        IF @UsaTasaInteres = 1 AND @SoloPagoCapital = 0
            SET @Intereses = dbo.fn_CR_Prestamos_InteresDiario(@IdPrestamo, @FechaContabilizacion);

        BEGIN TRANSACTION;

        DECLARE @ValorAbonar DECIMAL(10, 2) = @Abonar,
                @PagaCuotaCompleta BIT = 0,
                @SaldoCapital DECIMAL(10, 2),
                @SaldoInteres DECIMAL(10, 2),
                @ValorMoraIndividual DECIMAL(10, 2),
                @IdPrestamoDetalle INT,
                @IdTipoMovimiento INT,
                @Correlativo INT;

        SELECT @IdTipoMovimiento = tipo.IdTipoMovimientoPrestamo,
               @Correlativo = tipo.Correlativo
        FROM dbo.CR_TiposMovimientosPrestamos tipo
        WHERE tipo.EsAbono = 1;

        IF @IdTipoMovimiento IS NULL
            THROW 51304, 'No existe un tipo de movimiento para abonos.', 1;

        IF @UsaTasaInteres = 1 AND @SoloPagoCapital = 0
        BEGIN
            UPDATE dbo.CR_PrestamosDetalle
            SET SaldoInteres = @Intereses
            WHERE IdPrestamoDetalle = @IdPrestamoSiguienteCuota
              AND IdPrestamo = @IdPrestamo
              AND Cancelada = 0
              AND Eliminado = 0;
        END
        ELSE
        BEGIN
            UPDATE dbo.CR_PrestamosDetalle
            SET SaldoInteres = @Intereses
            WHERE IdPrestamoDetalle = @IdPrestamoSiguienteCuota
              AND SaldoInteres IS NULL;
        END;

        INSERT INTO dbo.CR_MovimientosPrestamos
        (
            IdEmpresa, IdPrestamo, IdTipoMovimientoPrestamo, FechaMovimiento,
            Correlativo, MontoTotal, MontoCapital, MontoInteres, MontoMora,
            SaldoCapitalActual, SaldoCapitalFinal, Comentario, Reversado,
            Usuario, NombreEquipo, Fecha_Base, Abono_Pago, Abono_Cambio
        )
        SELECT prestamo.IdEmpresa, @IdPrestamo, @IdTipoMovimiento, @FechaContabilizacion,
               @Correlativo, @Abonar, @Capital, @Intereses, @PagoMora,
               prestamo.SaldoCapital, prestamo.SaldoCapital - @Capital,
               @Referencia, 0, @Usuario, @Equipo, @FechaBase, @Abono_Pago, @Abono_Cambio
        FROM dbo.CR_Prestamos prestamo
        WHERE prestamo.IdPrestamo = @IdPrestamo;

        SET @IdMovimientoPrestamo = SCOPE_IDENTITY();

        IF @SoloPagoCapital = 0
        BEGIN
            SET @PagaCuotaCompleta =
                CASE WHEN @ValorAbonar >= ROUND(@Capital + @Intereses + @PagoMora, 2) THEN 1 ELSE 0 END;

            EXEC dbo.CR_MovimientosPrestamosDetalle_Insertar
                @IdPrestamoDetalle = @IdPrestamoSiguienteCuota,
                @Abonar = @ValorAbonar,
                @SaldoCapital = @Capital,
                @SaldoInteres = @Intereses,
                @IdMovimientoPrestamo = @IdMovimientoPrestamo,
                @PagoMora = @PagoMora,
                @PagaCuotaCompleta = @PagaCuotaCompleta,
                @usuario = @Usuario,
                @Equipo = @Equipo,
                @HayError = @HayError OUTPUT,
                @Mensaje = @Mensaje OUTPUT;

            IF @HayError = 1
                THROW 51305, @Mensaje, 1;

            SET @ValorAbonar -= @Capital + @Intereses + @PagoMora;
        END;

        DECLARE cuotas CURSOR LOCAL FAST_FORWARD FOR
        SELECT detalle.IdPrestamoDetalle,
               detalle.SaldoCapital,
               detalle.InteresProyectado,
               mora.ValorMora
        FROM dbo.CR_PrestamosDetalle detalle
        CROSS APPLY dbo.fn_CR_PrestamosDetalle_MoraCuota(detalle.IdPrestamoDetalle) mora
        WHERE detalle.IdPrestamo = @IdPrestamo
          AND detalle.Cancelada = 0
          AND detalle.Eliminado = 0
        ORDER BY CASE WHEN @UsaTasaInteres = 0 THEN detalle.FechaCuota END,
                 CASE WHEN @UsaTasaInteres = 1 THEN detalle.FechaCuota END DESC;

        OPEN cuotas;
        FETCH NEXT FROM cuotas INTO @IdPrestamoDetalle, @SaldoCapital, @SaldoInteres, @ValorMoraIndividual;

        WHILE @@FETCH_STATUS = 0 AND @ValorAbonar > 0
        BEGIN
            IF @UsaTasaInteres = 1 AND @ValorMoraIndividual = 0
            BEGIN
                EXEC dbo.CR_MovimientosPrestamosDetalle_SoloCapital
                    @IdPrestamoDetalle = @IdPrestamoDetalle,
                    @Abonar = @ValorAbonar,
                    @SaldoCapital = @SaldoCapital,
                    @IdMovimientoPrestamo = @IdMovimientoPrestamo,
                    @usuario = @Usuario,
                    @Equipo = @Equipo,
                    @HayError = @HayError OUTPUT,
                    @Mensaje = @Mensaje OUTPUT;

                IF @HayError = 1
                    THROW 51306, @Mensaje, 1;

                SET @ValorAbonar = CASE
                                       WHEN @ValorAbonar > @SaldoCapital
                                           THEN @ValorAbonar - @SaldoCapital
                                       ELSE 0
                                   END;
            END
            ELSE
            BEGIN
                IF @UsaTasaInteres = 1
                    SET @SaldoInteres = 0;

                SET @PagaCuotaCompleta =
                    CASE
                        WHEN @ValorAbonar >= @SaldoCapital + @SaldoInteres + @ValorMoraIndividual
                            THEN 1
                        ELSE 0
                    END;

                EXEC dbo.CR_MovimientosPrestamosDetalle_Insertar
                    @IdPrestamoDetalle = @IdPrestamoDetalle,
                    @Abonar = @ValorAbonar,
                    @SaldoCapital = @SaldoCapital,
                    @SaldoInteres = @SaldoInteres,
                    @IdMovimientoPrestamo = @IdMovimientoPrestamo,
                    @PagoMora = @ValorMoraIndividual,
                    @PagaCuotaCompleta = @PagaCuotaCompleta,
                    @usuario = @Usuario,
                    @Equipo = @Equipo,
                    @HayError = @HayError OUTPUT,
                    @Mensaje = @Mensaje OUTPUT;

                IF @HayError = 1
                    THROW 51307, @Mensaje, 1;

                SET @ValorAbonar -= @SaldoCapital + @SaldoInteres + @ValorMoraIndividual;
            END;

            FETCH NEXT FROM cuotas INTO @IdPrestamoDetalle, @SaldoCapital, @SaldoInteres, @ValorMoraIndividual;
        END;

        CLOSE cuotas;
        DEALLOCATE cuotas;

        UPDATE prestamo
        SET SaldoCapital = COALESCE(
            (
                SELECT SUM(detalle.SaldoCapital)
                FROM dbo.CR_PrestamosDetalle detalle
                WHERE detalle.IdPrestamo = prestamo.IdPrestamo
                  AND detalle.Eliminado = 0
            ),
            0
        )
        FROM dbo.CR_Prestamos prestamo
        WHERE prestamo.IdPrestamo = @IdPrestamo;

        UPDATE movimiento
        SET MontoCapital = totales.Capital,
            MontoInteres = totales.Interes,
            MontoMora = totales.Mora,
            MontoTotal = totales.Capital + totales.Interes + totales.Mora,
            SaldoCapitalFinal = COALESCE(
                (
                    SELECT SUM(detalle.SaldoCapital)
                    FROM dbo.CR_PrestamosDetalle detalle
                    WHERE detalle.IdPrestamo = @IdPrestamo
                      AND detalle.Cancelada = 0
                      AND detalle.Eliminado = 0
                ),
                0
            )
        FROM dbo.CR_MovimientosPrestamos movimiento
        CROSS APPLY
        (
            SELECT COALESCE(SUM(detalle.MontoCapital), 0) AS Capital,
                   COALESCE(SUM(detalle.MontoInteres), 0) AS Interes,
                   COALESCE(SUM(detalle.MontoMora), 0) AS Mora
            FROM dbo.CR_MovimientosPrestamosDetalle detalle
            WHERE detalle.IdMovimientoPrestamo = movimiento.IdMovimientoPrestamo
              AND detalle.Eliminado = 0
        ) totales
        WHERE movimiento.IdMovimientoPrestamo = @IdMovimientoPrestamo;

        UPDATE detalle
        SET FechaPagoPrestamo = @FechaContabilizacion
        FROM dbo.CR_PrestamosDetalle detalle
        INNER JOIN dbo.CR_MovimientosPrestamosDetalle movimientoDetalle
            ON movimientoDetalle.IdPrestamoDetalle = detalle.IdPrestamoDetalle
        WHERE movimientoDetalle.IdMovimientoPrestamo = @IdMovimientoPrestamo
          AND movimientoDetalle.Eliminado = 0
          AND detalle.Cancelada = 1;

        DECLARE @IdEstadoCancelado INT;
        SELECT @IdEstadoCancelado = estado.IdEstadoPrestamo
        FROM dbo.CR_EstadosPrestamos estado
        WHERE estado.Cancelado = 1;

        UPDATE dbo.CR_Prestamos
        SET IdEstadoPrestamo = @IdEstadoCancelado
        WHERE IdPrestamo = @IdPrestamo
          AND SaldoCapital <= 0;

        UPDATE dbo.CR_TiposMovimientosPrestamos
        SET Correlativo = Correlativo + 1
        WHERE IdTipoMovimientoPrestamo = @IdTipoMovimiento;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF CURSOR_STATUS('local', 'cuotas') >= 0
            CLOSE cuotas;
        IF CURSOR_STATUS('local', 'cuotas') > -3
            DEALLOCATE cuotas;
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        SET @HayError = 1;
        SET @Mensaje = LEFT(ERROR_MESSAGE(), 200);
    END CATCH;

    SELECT @HayError AS HayError,
           @Mensaje AS Mensaje;
END;
GO
