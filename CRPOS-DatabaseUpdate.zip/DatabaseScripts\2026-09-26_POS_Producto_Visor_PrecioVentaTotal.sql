SET NOCOUNT ON;
GO

DECLARE @Definicion NVARCHAR(MAX) = OBJECT_DEFINITION(OBJECT_ID(N'dbo.POS_Producto_Visor'));

IF @Definicion IS NULL
    THROW 51000, 'No existe dbo.POS_Producto_Visor.', 1;

IF CHARINDEX(N'valorisv.ValorISV', @Definicion) = 0
BEGIN
    IF CHARINDEX(N'valorisv.Descripcion AS TipoISV,', @Definicion) = 0
        THROW 51000, 'No se encontro TipoISV en POS_Producto_Visor.', 1;

    SET @Definicion = REPLACE(
        @Definicion,
        N'valorisv.Descripcion AS TipoISV,',
        N'valorisv.Descripcion AS TipoISV,' + CHAR(13) + CHAR(10) +
        N'           valorisv.ValorISV,');

    SET @Definicion = REPLACE(@Definicion, N'CREATE PROCEDURE', N'ALTER PROCEDURE');
    EXEC sys.sp_executesql @Definicion;
END;

IF CHARINDEX(N'valorisv.ValorISV', OBJECT_DEFINITION(OBJECT_ID(N'dbo.POS_Producto_Visor'))) = 0
    THROW 51000, 'No se pudo agregar ValorISV a POS_Producto_Visor.', 1;
GO
