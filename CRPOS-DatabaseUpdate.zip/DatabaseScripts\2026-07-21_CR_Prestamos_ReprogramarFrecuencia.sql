/*
    Reprograma la frecuencia de un préstamo activo desde la fecha actual.
    Conserva cuotas pagadas y movimientos; reemplaza únicamente cuotas pendientes sin abonos.
*/
SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;

DECLARE @IdFrecuenciaDiaria INT;

SELECT TOP (1) @IdFrecuenciaDiaria = frecuencia.IdFrecuenciaPagoPrestamo
FROM dbo.CR_FrecuenciasPagosPrestamos frecuencia WITH (UPDLOCK, HOLDLOCK)
WHERE (LOWER(LTRIM(RTRIM(frecuencia.Codigo))) = 'd' AND frecuencia.Cantidad = 1)
   OR UPPER(LTRIM(RTRIM(frecuencia.Nombre))) = 'DIARIO'
ORDER BY CASE WHEN UPPER(LTRIM(RTRIM(frecuencia.Nombre))) = 'DIARIO' THEN 0 ELSE 1 END,
         frecuencia.IdFrecuenciaPagoPrestamo;

IF @IdFrecuenciaDiaria IS NULL
BEGIN
    SELECT @IdFrecuenciaDiaria = COALESCE(MAX(frecuencia.IdFrecuenciaPagoPrestamo), 0) + 1
    FROM dbo.CR_FrecuenciasPagosPrestamos frecuencia WITH (UPDLOCK, HOLDLOCK);

    INSERT INTO dbo.CR_FrecuenciasPagosPrestamos
    (
        IdFrecuenciaPagoPrestamo, Nombre, Cantidad, Codigo,
        CocienteAnual, EsMes, SustantivoFrecuencia
    )
    VALUES
    (@IdFrecuenciaDiaria, 'DIARIO', 1, 'd', 360, 0, 'DIAS');
END
ELSE
BEGIN
    UPDATE dbo.CR_FrecuenciasPagosPrestamos
    SET Nombre = 'DIARIO',
        Cantidad = 1,
        Codigo = 'd',
        CocienteAnual = 360,
        EsMes = 0,
        SustantivoFrecuencia = 'DIAS'
    WHERE IdFrecuenciaPagoPrestamo = @IdFrecuenciaDiaria;
END;

COMMIT TRANSACTION;
GO

;WITH EmpresasObjetivo AS
(
    SELECT empresa.IdEmpresa
    FROM dbo.AD_Empresas empresa
    WHERE empresa.Activo = 1
      AND empresa.Eliminado = 0
      AND empresa.AplicaCR = 1

    UNION

    SELECT local.IdEmpresa
    FROM dbo.AD_EmpresaLocal local
    WHERE local.Activo = 1
      AND local.AplicaCR = 1
)
INSERT INTO dbo.SG_Autorizaciones
(
    IdEmpresa, Codigo, Nombre, CajaRural, PuntoVenta, Activo,
    Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizado
)
SELECT empresa.IdEmpresa, '00007', 'REPROGRAMAR FRECUENCIA DE PRESTAMO', 1, 0, 1,
       'SA', GETDATE(), HOST_NAME(), 0, NULL
FROM EmpresasObjetivo empresa
WHERE empresa.IdEmpresa IS NOT NULL
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.SG_Autorizaciones autorizacion
      WHERE autorizacion.IdEmpresa = empresa.IdEmpresa
        AND LTRIM(RTRIM(autorizacion.Codigo)) = '00007'
  );

;WITH EmpresasObjetivo AS
(
    SELECT empresa.IdEmpresa
    FROM dbo.AD_Empresas empresa
    WHERE empresa.Activo = 1
      AND empresa.Eliminado = 0
      AND empresa.AplicaCR = 1

    UNION

    SELECT local.IdEmpresa
    FROM dbo.AD_EmpresaLocal local
    WHERE local.Activo = 1
      AND local.AplicaCR = 1
)
UPDATE autorizacion
SET Nombre = 'REPROGRAMAR FRECUENCIA DE PRESTAMO',
    CajaRural = 1,
    PuntoVenta = 0,
    Activo = 1,
    Usuario = 'SA',
    FechaHora = GETDATE(),
    NombreEquipo = HOST_NAME(),
    Sincronizado = 0
FROM dbo.SG_Autorizaciones autorizacion
INNER JOIN EmpresasObjetivo empresa
    ON empresa.IdEmpresa = autorizacion.IdEmpresa
WHERE LTRIM(RTRIM(autorizacion.Codigo)) = '00007';

INSERT INTO dbo.SG_AutorizacionesUsuarios
(
    IdEmpresa, IdAutorizacion, IdUsuario, Eliminado, Usuario,
    FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizado
)
SELECT destino.IdEmpresa, destino.IdAutorizacion, usuarioBase.IdUsuario, 0,
       'SA', GETDATE(), HOST_NAME(), 0, NULL
FROM dbo.SG_Autorizaciones destino
INNER JOIN dbo.SG_Autorizaciones autorizacionBase
    ON autorizacionBase.IdEmpresa = destino.IdEmpresa
   AND LTRIM(RTRIM(autorizacionBase.Codigo)) = '00002'
INNER JOIN dbo.SG_AutorizacionesUsuarios usuarioBase
    ON usuarioBase.IdEmpresa = autorizacionBase.IdEmpresa
   AND usuarioBase.IdAutorizacion = autorizacionBase.IdAutorizacion
   AND usuarioBase.Eliminado = 0
WHERE LTRIM(RTRIM(destino.Codigo)) = '00007'
  AND NOT EXISTS
  (
      SELECT 1
      FROM dbo.SG_AutorizacionesUsuarios existente
      WHERE existente.IdEmpresa = destino.IdEmpresa
        AND existente.IdAutorizacion = destino.IdAutorizacion
        AND existente.IdUsuario = usuarioBase.IdUsuario
        AND existente.Eliminado = 0
  );
GO

IF OBJECT_ID(N'dbo.CR_PrestamosReprogramaciones', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.CR_PrestamosReprogramaciones
    (
        IdPrestamoReprogramacion INT IDENTITY(1, 1) NOT NULL
            CONSTRAINT PK_CR_PrestamosReprogramaciones PRIMARY KEY,
        IdEmpresa INT NOT NULL,
        IdPrestamo INT NOT NULL,
        IdFrecuenciaAnterior INT NOT NULL,
        IdFrecuenciaNueva INT NOT NULL,
        FechaEfectiva DATE NOT NULL,
        SaldoCapital DECIMAL(18, 2) NOT NULL,
        CuotasPendientesAnteriores INT NOT NULL,
        CuotasVencidasAnteriores INT NOT NULL,
        PermitioCuotasVencidas BIT NOT NULL,
        CuotasNuevas INT NOT NULL,
        InteresPendienteAnterior DECIMAL(18, 2) NOT NULL,
        InteresProyectadoNuevo DECIMAL(18, 2) NOT NULL,
        Motivo VARCHAR(500) NOT NULL,
        JustificacionAutorizacion VARCHAR(1000) NOT NULL,
        Usuario VARCHAR(50) NOT NULL,
        FechaHora DATETIME NOT NULL
            CONSTRAINT DF_CR_PrestamosReprogramaciones_FechaHora DEFAULT(GETDATE()),
        NombreEquipo VARCHAR(200) NOT NULL
    );
END;
GO

IF COL_LENGTH(N'dbo.CR_PrestamosReprogramaciones', N'CuotasVencidasAnteriores') IS NULL
    ALTER TABLE dbo.CR_PrestamosReprogramaciones
        ADD CuotasVencidasAnteriores INT NOT NULL
            CONSTRAINT DF_CR_PrestamosReprogramaciones_CuotasVencidas DEFAULT(0) WITH VALUES;
GO

IF COL_LENGTH(N'dbo.CR_PrestamosReprogramaciones', N'PermitioCuotasVencidas') IS NULL
    ALTER TABLE dbo.CR_PrestamosReprogramaciones
        ADD PermitioCuotasVencidas BIT NOT NULL
            CONSTRAINT DF_CR_PrestamosReprogramaciones_PermitioVencidas DEFAULT(0) WITH VALUES;
GO

IF NOT EXISTS
(
    SELECT 1
    FROM sys.indexes
    WHERE object_id = OBJECT_ID(N'dbo.CR_PrestamosReprogramaciones')
      AND name = N'IX_CR_PrestamosReprogramaciones_PrestamoFecha'
)
    CREATE INDEX IX_CR_PrestamosReprogramaciones_PrestamoFecha
        ON dbo.CR_PrestamosReprogramaciones(IdEmpresa, IdPrestamo, FechaHora DESC);
GO

IF OBJECT_ID(N'dbo.CR_Prestamos_ReprogramarFrecuencia', N'P') IS NULL
    EXEC(N'CREATE PROCEDURE dbo.CR_Prestamos_ReprogramarFrecuencia AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.CR_Prestamos_ReprogramarFrecuencia
    @IdEmpresa INT,
    @IdPrestamo INT,
    @IdFrecuenciaPagoNueva INT,
    @Motivo VARCHAR(500),
    @Usuario VARCHAR(50),
    @NombreEquipo VARCHAR(200),
    @JustificacionAutorizacion VARCHAR(1000) = NULL,
    @PermitirCuotasVencidas BIT = 0,
    @Aplicar BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @HayError BIT = 0,
            @Mensaje NVARCHAR(2048) = N'Vista previa generada correctamente.',
            @FechaEfectiva DATE = CAST(GETDATE() AS DATE),
            @FrecuenciaAnterior VARCHAR(100),
            @FrecuenciaNueva VARCHAR(100),
            @IdFrecuenciaPagoAnterior INT,
            @SaldoCapital DECIMAL(18, 2),
            @CuotasPendientesAnteriores INT = 0,
            @CuotasVencidasAnteriores INT = 0,
            @CuotasNuevas INT = 0,
            @CuotasHistoricas INT = 0,
            @FechaPrimeraCuotaNueva DATE,
            @FechaUltimaCuotaNueva DATE,
            @InteresPendienteAnterior DECIMAL(18, 2) = 0,
            @InteresProyectadoNuevo DECIMAL(18, 2) = 0;

    BEGIN TRY
        IF @IdEmpresa IS NULL OR @IdEmpresa <= 0
           OR @IdPrestamo IS NULL OR @IdPrestamo <= 0
           OR @IdFrecuenciaPagoNueva IS NULL OR @IdFrecuenciaPagoNueva <= 0
            THROW 51201, 'Los identificadores de la reprogramación no son válidos.', 1;

        IF NULLIF(LTRIM(RTRIM(@Motivo)), '') IS NULL OR LEN(LTRIM(RTRIM(@Motivo))) < 10
            THROW 51202, 'Debe ingresar un motivo de al menos 10 caracteres.', 1;

        IF NULLIF(LTRIM(RTRIM(@Usuario)), '') IS NULL
           OR NULLIF(LTRIM(RTRIM(@NombreEquipo)), '') IS NULL
            THROW 51203, 'No se pudo identificar al usuario o al equipo.', 1;

        BEGIN TRANSACTION;

        DECLARE @IdTipoPrestamo INT,
                @IdTipoCalculoPrestamo INT,
                @TasaInteres DECIMAL(5, 2),
                @ValorFijoInteres DECIMAL(5, 2),
                @TasaMora DECIMAL(5, 2),
                @FechaFinAnterior DATE;

        SELECT @IdTipoPrestamo = prestamo.IdTipoPrestamo,
               @IdTipoCalculoPrestamo = prestamo.IdTipoCalculoPrestamo,
               @TasaInteres = prestamo.TasaInteres,
               @ValorFijoInteres = prestamo.ValorFijoInteres,
               @TasaMora = prestamo.TasaMora,
               @IdFrecuenciaPagoAnterior = prestamo.IdFrecuenciaPago,
               @SaldoCapital = prestamo.SaldoCapital,
               @FrecuenciaAnterior = frecuencia.Nombre
        FROM dbo.CR_Prestamos prestamo WITH (UPDLOCK, HOLDLOCK)
        INNER JOIN dbo.CR_EstadosPrestamos estado
            ON estado.IdEstadoPrestamo = prestamo.IdEstadoPrestamo
        INNER JOIN dbo.CR_FrecuenciasPagosPrestamos frecuencia
            ON frecuencia.IdFrecuenciaPagoPrestamo = prestamo.IdFrecuenciaPago
        WHERE prestamo.IdEmpresa = @IdEmpresa
          AND prestamo.IdPrestamo = @IdPrestamo
          AND prestamo.Eliminado = 0
          AND estado.EsActivo = 1;

        IF @IdTipoPrestamo IS NULL OR COALESCE(@SaldoCapital, 0) <= 0
            THROW 51204, 'El préstamo no existe, no está activo o no tiene saldo pendiente.', 1;

        DECLARE @CantidadNueva INT,
                @CodigoNuevo CHAR(1);

        SELECT @CantidadNueva = frecuencia.Cantidad,
               @CodigoNuevo = LOWER(frecuencia.Codigo),
               @FrecuenciaNueva = frecuencia.Nombre
        FROM dbo.CR_FrecuenciasPagosPrestamos frecuencia
        WHERE frecuencia.IdFrecuenciaPagoPrestamo = @IdFrecuenciaPagoNueva
          AND frecuencia.Cantidad > 0
          AND frecuencia.CocienteAnual > 0
          AND LOWER(frecuencia.Codigo) IN ('d', 'm', 'y');

        IF @CantidadNueva IS NULL
            THROW 51205, 'La nueva frecuencia de pago no es válida.', 1;

        IF @IdFrecuenciaPagoAnterior = @IdFrecuenciaPagoNueva
            THROW 51206, 'La frecuencia seleccionada es igual a la frecuencia actual.', 1;

        -- Bloquea cuotas pendientes para impedir que un abono concurra con la reprogramación.
        SELECT @CuotasPendientesAnteriores = COUNT(*),
               @FechaFinAnterior = MAX(detalle.FechaCuota),
               @InteresPendienteAnterior = COALESCE(SUM(
                   COALESCE(detalle.SaldoInteres,
                            detalle.InteresProyectado - COALESCE(detalle.InteresCobrado, 0))), 0)
        FROM dbo.CR_PrestamosDetalle detalle WITH (UPDLOCK, HOLDLOCK)
        WHERE detalle.IdEmpresa = @IdEmpresa
          AND detalle.IdPrestamo = @IdPrestamo
          AND detalle.Cancelada = 0
          AND detalle.Eliminado = 0;

        IF @CuotasPendientesAnteriores = 0
            THROW 51207, 'El préstamo no tiene cuotas pendientes para reprogramar.', 1;

        SELECT @CuotasVencidasAnteriores = COUNT(*)
        FROM dbo.CR_PrestamosDetalle detalle
        WHERE detalle.IdEmpresa = @IdEmpresa
          AND detalle.IdPrestamo = @IdPrestamo
          AND detalle.Cancelada = 0
          AND detalle.Eliminado = 0
          AND detalle.FechaCuota < @FechaEfectiva;

        IF @PermitirCuotasVencidas = 0 AND EXISTS
        (
            SELECT 1
            FROM dbo.CR_PrestamosDetalle detalle
            WHERE detalle.IdEmpresa = @IdEmpresa
              AND detalle.IdPrestamo = @IdPrestamo
              AND detalle.Cancelada = 0
              AND detalle.Eliminado = 0
              AND detalle.FechaCuota < @FechaEfectiva
        )
            THROW 51208, 'No se puede reprogramar: el préstamo tiene cuotas vencidas.', 1;

        IF EXISTS
        (
            SELECT 1
            FROM dbo.CR_PrestamosDetalle detalle
            INNER JOIN dbo.CR_MovimientosPrestamosDetalle movimiento
                ON movimiento.IdPrestamoDetalle = detalle.IdPrestamoDetalle
               AND movimiento.Eliminado = 0
            WHERE detalle.IdEmpresa = @IdEmpresa
              AND detalle.IdPrestamo = @IdPrestamo
              AND detalle.Cancelada = 0
              AND detalle.Eliminado = 0
        )
            THROW 51209, 'No se puede reprogramar: una cuota pendiente ya recibió un abono parcial.', 1;

        DECLARE @NumeroCuotasNuevo INT = 0,
                @FechaBase DATE = @FechaEfectiva,
                @FechaCandidata DATE;

        WHILE @NumeroCuotasNuevo <= 1200
        BEGIN
            SET @FechaCandidata = CASE @CodigoNuevo
                                      WHEN 'd' THEN DATEADD(DAY, @CantidadNueva, @FechaBase)
                                      WHEN 'm' THEN DATEADD(MONTH, @CantidadNueva, @FechaBase)
                                      ELSE DATEADD(YEAR, @CantidadNueva, @FechaBase)
                                  END;

            IF @FechaCandidata > @FechaFinAnterior
                BREAK;

            SET @NumeroCuotasNuevo += 1;
            SET @FechaBase = @FechaCandidata;
        END;

        IF @NumeroCuotasNuevo = 0
            SET @NumeroCuotasNuevo = 1;

        IF @NumeroCuotasNuevo > 1200
            THROW 51210, 'La frecuencia seleccionada produciría más de 1200 cuotas. Seleccione otra frecuencia.', 1;

        DECLARE @DetalleNuevo TABLE
        (
            IdPrestamoDetalle INT,
            NumeroCuota INT,
            FechaCuota DATE,
            MontoCapitalBase DECIMAL(10, 2),
            InteresProyectado DECIMAL(10, 2),
            MontoCuota DECIMAL(11, 2),
            SaldoCapital DECIMAL(10, 2),
            InteresCobrado DECIMAL(10, 2),
            MoraCuota DECIMAL(10, 2),
            AbonoCapital BIT,
            CuotaVencida BIT
        );

        INSERT INTO @DetalleNuevo
        EXEC dbo.CR_PrestamosDetalle_Proyeccion
            @IdTipoPrestamo = @IdTipoPrestamo,
            @IdTipoCalculoPrestamo = @IdTipoCalculoPrestamo,
            @IdFrecuenciaPago = @IdFrecuenciaPagoNueva,
            @TasaInteres = @TasaInteres,
            @ValorFijoInteres = @ValorFijoInteres,
            @TasaMora = @TasaMora,
            @MontoPrestamo = @SaldoCapital,
            @NumeroCuotas = @NumeroCuotasNuevo,
            @FechaInicial = @FechaEfectiva,
            @FechaPrimerCuota = @FechaEfectiva,
            @CambioFechaPrimerCuota = 0;

        DECLARE @CapitalProyectado DECIMAL(18, 2);

        SELECT @CuotasNuevas = COUNT(*),
               @CapitalProyectado = SUM(detalle.MontoCapitalBase),
               @FechaPrimeraCuotaNueva = MIN(detalle.FechaCuota),
               @FechaUltimaCuotaNueva = MAX(detalle.FechaCuota),
               @InteresProyectadoNuevo = COALESCE(SUM(detalle.InteresProyectado), 0)
        FROM @DetalleNuevo detalle;

        IF @CuotasNuevas = 0 OR @CapitalProyectado <> @SaldoCapital
            THROW 51211, 'La nueva proyección no coincide con el saldo pendiente del préstamo.', 1;

        SELECT @CuotasHistoricas = COUNT(*)
        FROM dbo.CR_PrestamosDetalle detalle
        WHERE detalle.IdEmpresa = @IdEmpresa
          AND detalle.IdPrestamo = @IdPrestamo
          AND detalle.Cancelada = 1
          AND detalle.Eliminado = 0;

        IF @Aplicar = 1
        BEGIN
            IF NULLIF(LTRIM(RTRIM(@JustificacionAutorizacion)), '') IS NULL
               OR NOT EXISTS
               (
                   SELECT 1
                   FROM dbo.SG_AutorizacionesLogs registro
                   INNER JOIN dbo.SG_Autorizaciones autorizacion
                       ON autorizacion.IdEmpresa = registro.IdEmpresa
                      AND autorizacion.IdAutorizacion = registro.IdAutorizacion
                   WHERE registro.IdEmpresa = @IdEmpresa
                     AND LTRIM(RTRIM(autorizacion.Codigo)) = '00007'
                     AND autorizacion.Activo = 1
                     AND registro.FechaHora >= DATEADD(MINUTE, -10, GETDATE())
                     AND registro.Justificacion = LTRIM(RTRIM(@JustificacionAutorizacion))
               )
                THROW 51212, 'La reprogramación requiere una autorización válida y registrada.', 1;

            UPDATE interesMora
            SET Eliminado = 1,
                Sincronizado = 0
            FROM dbo.CR_PrestamosDetalle_InteresesMora interesMora
            INNER JOIN dbo.CR_PrestamosDetalle detalle
                ON detalle.IdPrestamoDetalle = interesMora.IdPrestamoDetalle
            WHERE detalle.IdEmpresa = @IdEmpresa
              AND detalle.IdPrestamo = @IdPrestamo
              AND detalle.Cancelada = 0
              AND detalle.Eliminado = 0
              AND interesMora.Eliminado = 0;

            UPDATE detalle
            SET Eliminado = 1,
                Sincronizado = 0,
                FechaHoraSincronizacion = NULL
            FROM dbo.CR_PrestamosDetalle detalle
            WHERE detalle.IdEmpresa = @IdEmpresa
              AND detalle.IdPrestamo = @IdPrestamo
              AND detalle.Cancelada = 0
              AND detalle.Eliminado = 0;

            DECLARE @NumeroCuotaBase INT;

            SELECT @NumeroCuotaBase = COALESCE(MAX(detalle.NumeroCuota), 0)
            FROM dbo.CR_PrestamosDetalle detalle
            WHERE detalle.IdEmpresa = @IdEmpresa
              AND detalle.IdPrestamo = @IdPrestamo
              AND detalle.Eliminado = 0;

            INSERT INTO dbo.CR_PrestamosDetalle
            (
                IdEmpresa, IdPrestamo, NumeroCuota, FechaCuota,
                FechaPagoPrestamo, MontoCapitalBase, InteresProyectado,
                SaldoCapital, InteresCobrado, SaldoInteres, MoraCuota,
                MoraCobrada, AbonoCapital, CuotaVencida, Cancelada,
                Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado,
                FechaHoraSincronizacion
            )
            SELECT @IdEmpresa, @IdPrestamo, @NumeroCuotaBase + detalle.NumeroCuota,
                   detalle.FechaCuota, NULL, detalle.MontoCapitalBase,
                   detalle.InteresProyectado, detalle.MontoCapitalBase, 0,
                   detalle.InteresProyectado, 0, 0, 0, 0, 0, 0,
                   @Usuario, GETDATE(), @NombreEquipo, 0, NULL
            FROM @DetalleNuevo detalle;

            UPDATE dbo.CR_Prestamos
            SET IdFrecuenciaPago = @IdFrecuenciaPagoNueva,
                NumeroCuotas = @CuotasHistoricas + @CuotasNuevas,
                FechaFin = @FechaUltimaCuotaNueva,
                Usuario = @Usuario,
                FechaHora = GETDATE(),
                NombreEquipo = @NombreEquipo,
                Sincronizado = 0,
                FechaHoraSincronizacion = NULL
            WHERE IdEmpresa = @IdEmpresa
              AND IdPrestamo = @IdPrestamo;

            INSERT INTO dbo.CR_PrestamosReprogramaciones
            (
                IdEmpresa, IdPrestamo, IdFrecuenciaAnterior, IdFrecuenciaNueva,
                FechaEfectiva, SaldoCapital, CuotasPendientesAnteriores,
                CuotasVencidasAnteriores, PermitioCuotasVencidas,
                CuotasNuevas, InteresPendienteAnterior, InteresProyectadoNuevo,
                Motivo, JustificacionAutorizacion, Usuario, NombreEquipo
            )
            VALUES
            (
                @IdEmpresa, @IdPrestamo, @IdFrecuenciaPagoAnterior,
                @IdFrecuenciaPagoNueva, @FechaEfectiva, @SaldoCapital,
                @CuotasPendientesAnteriores, @CuotasVencidasAnteriores,
                CASE WHEN @CuotasVencidasAnteriores > 0 AND @PermitirCuotasVencidas = 1 THEN 1 ELSE 0 END,
                @CuotasNuevas,
                @InteresPendienteAnterior, @InteresProyectadoNuevo,
                LTRIM(RTRIM(@Motivo)), LTRIM(RTRIM(@JustificacionAutorizacion)),
                @Usuario, @NombreEquipo
            );

            SET @Mensaje = N'Frecuencia reprogramada correctamente desde '
                + CONVERT(NVARCHAR(10), @FechaEfectiva, 103) + N'.';

            IF @CuotasVencidasAnteriores > 0
                SET @Mensaje += N' Se reproyectaron '
                    + CONVERT(NVARCHAR(20), @CuotasVencidasAnteriores)
                    + N' cuota(s) vencida(s) mediante carga inicial autorizada.';
        END;

        COMMIT TRANSACTION;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        SET @HayError = 1;
        SET @Mensaje = ERROR_MESSAGE();
    END CATCH;

    SELECT @HayError AS HayError,
           @Mensaje AS Mensaje,
           @FechaEfectiva AS FechaEfectiva,
           @FrecuenciaAnterior AS FrecuenciaAnterior,
           @FrecuenciaNueva AS FrecuenciaNueva,
           @SaldoCapital AS SaldoCapital,
           @CuotasPendientesAnteriores AS CuotasPendientesAnteriores,
           @CuotasVencidasAnteriores AS CuotasVencidasAnteriores,
           CAST(CASE WHEN @CuotasVencidasAnteriores > 0 AND @PermitirCuotasVencidas = 1 THEN 1 ELSE 0 END AS BIT) AS PermitioCuotasVencidas,
           @CuotasNuevas AS CuotasNuevas,
           @FechaPrimeraCuotaNueva AS FechaPrimeraCuotaNueva,
           @FechaUltimaCuotaNueva AS FechaUltimaCuotaNueva,
           @InteresPendienteAnterior AS InteresPendienteAnterior,
           @InteresProyectadoNuevo AS InteresProyectadoNuevo;
END;
GO
