SET ANSI_NULLS ON;
GO
SET QUOTED_IDENTIFIER ON;
GO

IF COL_LENGTH('dbo.CR_AsientosDet', 'Eliminado') IS NULL
BEGIN
    ALTER TABLE dbo.CR_AsientosDet
        ADD Eliminado BIT NOT NULL
            CONSTRAINT DF_CR_AsientosDet_Eliminado DEFAULT (0) WITH VALUES;
END;
GO

IF OBJECT_ID('dbo.CR_Asientos_EditarDetalles', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.CR_Asientos_EditarDetalles AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.CR_Asientos_EditarDetalles
    @IdEmpresa INT,
    @IdAsiento INT,
    @Fecha DATE,
    @NumeroReferencia VARCHAR(MAX),
    @Sinopsis VARCHAR(MAX),
    @Detalles XML,
    @IdUsuario INT,
    @NombreEquipo VARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;
    SET XACT_ABORT ON;

    DECLARE @Usuario VARCHAR(50);
    DECLARE @TotalDebito NUMERIC(18, 8);
    DECLARE @TotalCredito NUMERIC(18, 8);
    DECLARE @DetallesActivos INT;

    SELECT TOP (1) @Usuario = u.NombreUsuario
    FROM dbo.SG_Usuarios u
    INNER JOIN dbo.SG_Perfiles p ON p.IdPerfil = u.IdPerfil
    WHERE u.IdUsuario = @IdUsuario
      AND u.Activo = 1
      AND u.Eliminado = 0
      AND p.Activo = 1
      AND p.Eliminado = 0
      AND (u.IdEmpresa = @IdEmpresa OR u.IdEmpresa IS NULL)
      AND (UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%ADMINISTRADOR%'
           OR UPPER(LTRIM(RTRIM(p.Perfil))) LIKE '%SOPORTE%');

    IF @Usuario IS NULL
    BEGIN
        SELECT CAST(1 AS BIT) AS HayError,
               'Solo un usuario Administrador o Soporte puede modificar detalles contables.' AS Mensaje;
        RETURN;
    END;

    DECLARE @Detalle TABLE
    (
        IdAsientoDetalle INT NOT NULL,
        IdCuentaContable INT NOT NULL,
        Debito NUMERIC(18, 8) NOT NULL,
        Credito NUMERIC(18, 8) NOT NULL,
        Sinopsis VARCHAR(MAX) NULL
    );

    INSERT INTO @Detalle (IdAsientoDetalle, IdCuentaContable, Debito, Credito, Sinopsis)
    SELECT n.value('(@IdAsientoDetalle)[1]', 'int'),
           n.value('(@IdCuentaContable)[1]', 'int'),
           n.value('(@Debito)[1]', 'numeric(18,8)'),
           n.value('(@Credito)[1]', 'numeric(18,8)'),
           NULLIF(n.value('(@Sinopsis)[1]', 'varchar(max)'), '')
    FROM @Detalles.nodes('/Detalles/Detalle') x(n);

    SELECT @TotalDebito = ISNULL(SUM(Debito), 0),
           @TotalCredito = ISNULL(SUM(Credito), 0),
           @DetallesActivos = COUNT(*)
    FROM @Detalle;

    IF @DetallesActivos < 2
       OR @TotalDebito <> @TotalCredito
       OR @TotalDebito <= 0
       OR EXISTS (SELECT 1 FROM @Detalle WHERE IdCuentaContable <= 0 OR Debito < 0 OR Credito < 0 OR (Debito = 0 AND Credito = 0) OR (Debito > 0 AND Credito > 0))
       OR EXISTS (SELECT IdAsientoDetalle FROM @Detalle WHERE IdAsientoDetalle > 0 GROUP BY IdAsientoDetalle HAVING COUNT(*) > 1)
    BEGIN
        SELECT CAST(1 AS BIT) AS HayError,
               'Los detalles deben incluir al menos dos registros validos y mantener debitos y creditos balanceados.' AS Mensaje;
        RETURN;
    END;

    BEGIN TRY
        BEGIN TRANSACTION;

        IF NOT EXISTS
        (
            SELECT 1
            FROM dbo.CR_Asientos WITH (UPDLOCK, HOLDLOCK)
            WHERE IdAsiento = @IdAsiento
              AND IdEmpresa = @IdEmpresa
              AND Anulado = 0
              AND Mayorizado = 0
              AND Eliminado = 0
        )
            RAISERROR('El asiento no existe, esta anulado o ya fue mayorizado.', 16, 1);

        IF EXISTS
        (
            SELECT 1
            FROM @Detalle x
            WHERE x.IdAsientoDetalle > 0
              AND NOT EXISTS
              (
                  SELECT 1
                  FROM dbo.CR_AsientosDet d
                  WHERE d.IdAsientoDetalle = x.IdAsientoDetalle
                    AND d.IdAsiento = @IdAsiento
                    AND d.IdEmpresa = @IdEmpresa
                    AND ISNULL(d.Eliminado, 0) = 0
              )
        )
            RAISERROR('Uno de los detalles ya no pertenece al asiento o fue deshabilitado.', 16, 1);

        UPDATE d
        SET d.IdCuentaContable = x.IdCuentaContable,
            d.Debito = x.Debito,
            d.Credito = x.Credito,
            d.Sinopsis = x.Sinopsis,
            d.Usuario = @Usuario,
            d.FechaHora = GETDATE(),
            d.NombreEquipo = @NombreEquipo,
            d.Sincronizado = 0,
            d.FechaHoraSincronizacion = NULL
        FROM dbo.CR_AsientosDet d
        INNER JOIN @Detalle x ON x.IdAsientoDetalle = d.IdAsientoDetalle
        WHERE x.IdAsientoDetalle > 0;

        INSERT INTO dbo.CR_AsientosDet
        (
            IdEmpresa, IdAsiento, IdCuentaContable, Debito, Credito, Sinopsis,
            Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion, Eliminado
        )
        SELECT @IdEmpresa, @IdAsiento, x.IdCuentaContable, x.Debito, x.Credito, x.Sinopsis,
               @Usuario, GETDATE(), @NombreEquipo, 0, NULL, 0
        FROM @Detalle x
        WHERE x.IdAsientoDetalle = 0;

        UPDATE d
        SET d.Eliminado = 1,
            d.Usuario = @Usuario,
            d.FechaHora = GETDATE(),
            d.NombreEquipo = @NombreEquipo,
            d.Sincronizado = 0,
            d.FechaHoraSincronizacion = NULL
        FROM dbo.CR_AsientosDet d
        WHERE d.IdAsiento = @IdAsiento
          AND d.IdEmpresa = @IdEmpresa
          AND ISNULL(d.Eliminado, 0) = 0
          AND NOT EXISTS (SELECT 1 FROM @Detalle x WHERE x.IdAsientoDetalle = d.IdAsientoDetalle);

        UPDATE dbo.CR_Asientos
        SET FechaAsiento = @Fecha,
            NumeroReferencia = NULLIF(LTRIM(RTRIM(@NumeroReferencia)), ''),
            Debito = @TotalDebito,
            Credito = @TotalCredito,
            Sinopsis = NULLIF(LTRIM(RTRIM(@Sinopsis)), ''),
            Usuario = @Usuario,
            FechaHora = GETDATE(),
            NombreEquipo = @NombreEquipo,
            Sincronizado = 0,
            FechaHoraSincronizacion = NULL
        WHERE IdAsiento = @IdAsiento
          AND IdEmpresa = @IdEmpresa;

        COMMIT TRANSACTION;

        SELECT CAST(0 AS BIT) AS HayError,
               'Asiento contable actualizado correctamente.' AS Mensaje;
    END TRY
    BEGIN CATCH
        IF XACT_STATE() <> 0
            ROLLBACK TRANSACTION;

        SELECT CAST(1 AS BIT) AS HayError,
               ERROR_MESSAGE() AS Mensaje;
    END CATCH;
END;
GO

IF OBJECT_ID('dbo.POS_AsientosDetVisor', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.POS_AsientosDetVisor AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.POS_AsientosDetVisor
    @IdEmpresa INT,
    @IdAsiento INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT A.IdAsientoDetalle,
           B.CuentaContable,
           A.Debito,
           A.Credito,
           A.Debito - A.Credito AS Diferencia,
           ISNULL(A.Sinopsis, '') AS Sinopsis,
           B.Nombre
    FROM dbo.CR_AsientosDet A
    INNER JOIN dbo.CR_CuentasContables B ON A.IdCuentaContable = B.IdCuentaContable
    WHERE A.IdEmpresa = @IdEmpresa
      AND A.IdAsiento = @IdAsiento
      AND ISNULL(A.Eliminado, 0) = 0;
END;
GO

IF OBJECT_ID('dbo.CR_Asientos_Mayorizar', 'P') IS NULL
    EXEC('CREATE PROCEDURE dbo.CR_Asientos_Mayorizar AS BEGIN SET NOCOUNT ON; END');
GO

ALTER PROCEDURE dbo.CR_Asientos_Mayorizar
    @IdEmpresa INT,
    @Anio INT,
    @Mes INT,
    @Usuario VARCHAR(50),
    @NombreEquipo VARCHAR(200)
AS
BEGIN
    DECLARE @Mensaje VARCHAR(MAX) = '';
    DECLARE @Error BIT = 0;

    IF EXISTS
    (
        SELECT 1
        FROM dbo.CR_AsientosMayorizacion cam
        WHERE cam.IdEmpresa = @IdEmpresa
          AND cam.Anio = @Anio
          AND cam.Mes = @Mes
          AND cam.Eliminado = 0
    )
    BEGIN
        SET @Error = 1;
        SET @Mensaje = 'Ya existe una mayorizacion en ese mes y año.';
    END
    ELSE
    BEGIN
        DECLARE @Asientos TABLE
        (
            ID INT IDENTITY,
            IdCuentaContable INT,
            IdCuentaPadre INT,
            Saldo NUMERIC(18, 6)
        );
        DECLARE @SaldosCuentas TABLE
        (
            ID INT IDENTITY,
            IdCuentaContable INT,
            Saldo NUMERIC(18, 6)
        );

        INSERT INTO @Asientos
        SELECT ccc.IdCuentaContable,
               ccc.IdCuentaPadre,
               CASE WHEN ccc.TipoSaldo = 'D'
                    THEN SUM(cad.Debito) - SUM(cad.Credito)
                    ELSE SUM(cad.Credito) - SUM(cad.Debito)
               END
        FROM dbo.CR_Asientos ca
        INNER JOIN dbo.CR_AsientosDet cad ON ca.IdEmpresa = cad.IdEmpresa AND ca.IdAsiento = cad.IdAsiento
        INNER JOIN dbo.CR_CuentasContables ccc ON ccc.IdEmpresa = cad.IdEmpresa AND ccc.IdCuentaContable = cad.IdCuentaContable
        WHERE ca.IdEmpresa = @IdEmpresa
          AND ca.Anulado = 0
          AND ca.Eliminado = 0
          AND ISNULL(cad.Eliminado, 0) = 0
          AND YEAR(ca.FechaAsiento) = @Anio
          AND MONTH(ca.FechaAsiento) = @Mes
        GROUP BY ccc.IdCuentaContable, ccc.IdCuentaPadre, ccc.TipoSaldo
        UNION ALL
        SELECT ccc.IdCuentaContable, ccc.IdCuentaPadre, 0.000000
        FROM dbo.CR_CuentasContables ccc
        WHERE ccc.IdEmpresa = @IdEmpresa;

        ;WITH RESUMEN AS
        (
            SELECT IdCuentaContable, IdCuentaPadre, SUM(Saldo) AS Saldo
            FROM @Asientos
            GROUP BY IdCuentaContable, IdCuentaPadre
        ),
        SALDOS AS
        (
            SELECT IdCuentaContable, IdCuentaContable AS IdCuentaPadre, Saldo
            FROM RESUMEN
            UNION ALL
            SELECT A.IdCuentaContable, B.IdCuentaPadre, A.Saldo
            FROM RESUMEN A
            INNER JOIN SALDOS B ON A.IdCuentaPadre = B.IdCuentaContable
        )
        INSERT INTO @SaldosCuentas
        SELECT R.IdCuentaContable, D.Saldo
        FROM RESUMEN R
        INNER JOIN
        (
            SELECT IdCuentaPadre, SUM(Saldo) AS Saldo
            FROM SALDOS
            GROUP BY IdCuentaPadre
        ) D ON R.IdCuentaContable = D.IdCuentaPadre
        WHERE D.Saldo <> 0;

        INSERT INTO dbo.CR_AsientosMayorizacion
        (
            IdEmpresa, IdCuentaContable, Anio, Mes, SaldoAnterior, SaldoActual, Saldo,
            Eliminado, Usuario, FechaHora, NombreEquipo, Sincronizado, FechaHoraSincronizacion
        )
        SELECT @IdEmpresa,
               ISNULL(A.IdCuentaContable, B.IdCuentaContable),
               @Anio,
               @Mes,
               ISNULL(B.Saldo, 0),
               ISNULL(A.Saldo, 0),
               ISNULL(A.Saldo, 0) + ISNULL(B.Saldo, 0),
               0,
               @Usuario,
               GETDATE(),
               @NombreEquipo,
               0,
               NULL
        FROM @SaldosCuentas A
        FULL OUTER JOIN
        (
            SELECT *
            FROM dbo.CR_AsientosMayorizacion cam
            WHERE cam.IdEmpresa = @IdEmpresa
              AND cam.Anio = @Anio
              AND cam.Mes = (@Mes - 1)
              AND cam.Eliminado = 0
        ) B ON A.IdCuentaContable = B.IdCuentaContable;

        SET @Mensaje = 'Mayorizacion generada correctamente.';
    END;

    SELECT @Mensaje AS Mensaje,
           @Error AS HayError;
END;
GO
